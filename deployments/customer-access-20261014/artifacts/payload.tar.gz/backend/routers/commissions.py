import json
import re
from datetime import date, datetime, timedelta, timezone
from typing import Annotated, Literal, Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator
from sqlalchemy import func, or_, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db
from dependencies.auth import get_admin_user, get_current_user, get_finance_user, normalize_system_role
from models.commissions import (
    CommissionAgreement,
    CommissionEntry,
    CommissionStatusEvent,
    CustomerCommissionAttribution,
    SalesPartner,
)
from models.customers import Customers
from models.employees import Employees
from models.management_decisions import BusinessLine, CustomerEngagement, ProductCatalog
from models.payments import Payments
from models.subscriptions import Subscriptions
from schemas.auth import UserResponse
from services.commissions import (
    DEFAULT_DECAY,
    apply_bulk_customer_attributions,
    assign_customer_commission_owner,
    commission_data_quality,
    preview_bulk_customer_attributions,
    preview_customer_commission_owner,
    preview_payment_commission,
    scan_commissions,
    transfer_partner_attributions_to_direct,
    utcnow,
    validate_commission_entry_confirmation,
    validate_commission_entry_reversal,
)
from services.partner_portal import build_partner_customer_status_rows, partner_status_summary
from services.finance_period_lock import ensure_profit_months_open


router = APIRouter(prefix="/api/v1/commissions", tags=["commissions"])
PARTNER_TYPES = {"agency", "partner", "employee", "direct"}
PARTNER_STATUSES = {"active", "suspended", "terminated", "settled"}
ENTRY_TRANSITIONS = {
    "pending_confirmation": {"confirmed", "reversed"},
    "confirmed": {"payable", "reversed"},
    "payable": {"paid"},
}
PROFIT_COMMISSION_STATUSES = {"confirmed", "payable", "paid"}


def actor_name(user: UserResponse) -> str:
    return user.name or user.email or str(user.id)


def _partner_payload(row: SalesPartner) -> dict:
    return {
        "id": row.id, "partner_code": row.partner_code, "name": row.name,
        "partner_type": row.partner_type, "employee_id": row.employee_id, "status": row.status,
        "joined_at": row.joined_at, "stopped_at": row.stopped_at,
        "contact_name": row.contact_name, "contact_phone": row.contact_phone,
        "contact_email": row.contact_email, "notes": row.notes,
        "created_at": row.created_at, "updated_at": row.updated_at,
    }


def _agreement_payload(row: CommissionAgreement) -> dict:
    try:
        decay = json.loads(row.activity_decay_json)
    except (TypeError, json.JSONDecodeError):
        decay = DEFAULT_DECAY
    return {
        "id": row.id, "partner_id": row.partner_id, "version": row.version,
        "business_line_id": row.business_line_id, "product_id": row.product_id,
        "first_order_rate": row.first_order_rate, "renewal_rate": row.renewal_rate,
        "activity_decay": decay, "refund_guard_days": row.refund_guard_days,
        "effective_from": row.effective_from, "effective_to": row.effective_to,
        "status": row.status, "notes": row.notes, "created_at": row.created_at,
        "calculation_version": row.calculation_version,
        "renewal_policy": row.renewal_policy,
    }


def _portal_partner_payload(row: SalesPartner) -> dict:
    """A partner-visible whitelist, separate from internal management remarks."""
    return {key: getattr(row, key) for key in (
        "id", "partner_code", "name", "partner_type", "status", "joined_at", "stopped_at",
    )}


def _portal_agreement_payload(row: CommissionAgreement) -> dict:
    payload = _agreement_payload(row)
    return {key: value for key, value in payload.items() if key != "notes"}


def _entry_period_payload(row: CommissionEntry) -> dict:
    try:
        snapshot = json.loads(row.snapshot_json or "{}")
    except (TypeError, json.JSONDecodeError):
        snapshot = {}
    if not isinstance(snapshot, dict):
        snapshot = {}
    return {
        "calculation_version": snapshot.get("calculation_version", "legacy_v1"),
        **{key: snapshot.get(key) for key in (
            "service_period_start", "service_period_end", "first_service_start", "commission_mode", "allocation_basis",
        )},
    }


async def _validate_partner_login(db: AsyncSession, employee_id: int, *, partner_id: int | None = None) -> Employees:
    # Serialize every bind/create for the same employee, including concurrent requests.
    employee = await db.scalar(select(Employees).where(Employees.id == employee_id).with_for_update()
                               .execution_options(populate_existing=True))
    if not employee:
        raise HTTPException(status_code=404, detail="关联登录账号不存在")
    if normalize_system_role(employee.role) != "sales_partner":
        raise HTTPException(status_code=409, detail="外部渠道必须关联“销售合伙人”角色的登录账号")
    if employee.status not in {"active", "probation"}:
        raise HTTPException(status_code=409, detail="只能绑定正常使用中的销售合伙人账号")
    linked = select(SalesPartner.id).where(
        SalesPartner.employee_id == employee_id,
        SalesPartner.partner_type.in_(("agency", "partner")),
    )
    if partner_id is not None:
        linked = linked.where(SalesPartner.id != partner_id)
    if await db.scalar(linked.limit(1)):
        raise HTTPException(status_code=409, detail="该登录账号已经关联其他渠道档案，请核对原档案，不可重复绑定")
    return employee


def _login_payload(employee: Employees | None) -> dict | None:
    return None if employee is None else {
        "id": employee.id, "name": employee.name, "email": employee.email,
        "status": employee.status, "employee_code": employee.employee_code,
    }


def _require_sales_partner(user: UserResponse) -> int:
    if normalize_system_role(user.role) != "sales_partner":
        raise HTTPException(status_code=403, detail="Sales partner access required")
    try:
        return int(user.id)
    except (TypeError, ValueError) as exc:
        raise HTTPException(status_code=403, detail="Sales partner account is not linked to an employee") from exc


async def _portal_partner_scope(
    user: UserResponse,
    db: AsyncSession,
    requested_partner_id: int | None,
) -> tuple[SalesPartner, list[SalesPartner], bool]:
    """Resolve a read-only partner scope without granting any commission writes."""
    role = normalize_system_role(user.role)
    if role == "sales_partner":
        if requested_partner_id is not None:
            raise HTTPException(status_code=403, detail="Sales partners cannot switch partner scope")
        employee_id = _require_sales_partner(user)
        partners = (await db.scalars(select(SalesPartner).where(
            SalesPartner.employee_id == employee_id,
            SalesPartner.partner_type.in_(("agency", "partner")),
        ).order_by(SalesPartner.id))).all()
        if not partners:
            raise HTTPException(status_code=409, detail="该登录账号尚未关联销售合伙人档案，请联系管理员完成关联")
        if len(partners) > 1:
            raise HTTPException(status_code=409, detail="该登录账号关联了多个销售合伙人档案，请联系管理员处理重复关联")
        return partners[0], [], False

    if role != "super_admin":
        raise HTTPException(status_code=403, detail="Partner portal access required")

    partners = list((await db.scalars(select(SalesPartner).where(
        SalesPartner.partner_type.in_(("agency", "partner")),
    ).order_by(SalesPartner.name, SalesPartner.id))).all())
    if not partners:
        raise HTTPException(status_code=409, detail="尚未建立销售合伙人档案")

    if requested_partner_id is None:
        selected = next((row for row in partners if row.status == "active"), partners[0])
    else:
        selected = next((row for row in partners if row.id == requested_partner_id), None)
        if selected is None:
            raise HTTPException(status_code=404, detail="销售合伙人不存在")
    return selected, partners, True


class PartnerInput(BaseModel):
    partner_code: str = Field(min_length=2, max_length=48)
    name: str = Field(min_length=1, max_length=160)
    partner_type: Literal["agency", "partner", "employee", "direct"] = "partner"
    employee_id: Optional[int] = Field(None, gt=0)
    joined_at: date
    contact_name: Optional[str] = Field(None, max_length=120)
    contact_phone: Optional[str] = Field(None, max_length=64)
    contact_email: Optional[str] = Field(None, max_length=160)
    notes: Optional[str] = Field(None, max_length=4000)

    @field_validator("partner_code")
    @classmethod
    def normalize_code(cls, value: str) -> str:
        value = value.strip().upper()
        if not re.fullmatch(r"[A-Z0-9][A-Z0-9_-]{1,47}", value):
            raise ValueError("渠道编号只能使用字母、数字、下划线或短横线")
        return value

    @model_validator(mode="after")
    def validate_employee(self):
        if self.partner_type == "employee" and not self.employee_id:
            raise ValueError("内部销售必须关联员工")
        return self


class AgreementInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    partner_id: int = Field(gt=0)
    business_line_id: Optional[int] = Field(None, gt=0)
    product_id: Optional[int] = Field(None, gt=0)
    first_order_rate: float = Field(ge=0, le=1)
    renewal_rate: float = Field(ge=0, le=1)
    renewal_policy: Literal["fixed"] = "fixed"
    activity_decay: dict[int, float] = Field(default_factory=lambda: {0: 1.0, 6: 1.0})
    refund_guard_days: int = Field(default=30, ge=0, le=180)
    effective_from: date
    notes: Optional[str] = Field(None, max_length=4000)

    @field_validator("activity_decay")
    @classmethod
    def validate_decay(cls, value: dict[int, float]) -> dict[int, float]:
        normalized = {int(month): float(rate) for month, rate in value.items()}
        if 0 not in normalized or 6 not in normalized:
            raise ValueError("活跃衰减必须包含 0 月和 6 月")
        if any(month < 0 or month > 24 or rate < 0 or rate > 1 for month, rate in normalized.items()):
            raise ValueError("活跃衰减月份或比例无效")
        ordered = [normalized[key] for key in sorted(normalized)]
        if any(ordered[index] < ordered[index + 1] for index in range(len(ordered) - 1)):
            raise ValueError("停滞时间越长，续费倍率不能升高")
        if any(rate != 1.0 for rate in normalized.values()):
            raise ValueError("新协议使用固定续费比例，活跃倍率必须为100%")
        return normalized


class AttributionInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    customer_id: int = Field(gt=0)
    partner_id: int = Field(gt=0)
    engagement_id: Optional[int] = Field(None, gt=0)
    effective_from: date
    source_note: Optional[str] = Field(None, max_length=4000)
    commission_mode: Literal["first_month_then_renewal", "renewal_only", "none"] = "first_month_then_renewal"
    commission_start_date: date
    first_service_start: Optional[date] = None
    history_basis: Optional[str] = Field(None, max_length=4000)

    @model_validator(mode="after")
    def validate_commission_period(self):
        self.history_basis = (self.history_basis or "").strip() or None
        if self.commission_start_date < self.effective_from:
            raise ValueError("计佣开始日期不能早于归属生效日期")
        if self.commission_mode == "first_month_then_renewal" and self.first_service_start is None:
            raise ValueError("请填写首次服务开始日期，明确首月与续费边界")
        if self.commission_mode == "renewal_only" and not self.history_basis:
            raise ValueError("仅续费模式必须填写历史首月已完成的依据")
        return self


class PartnerLoginInput(BaseModel):
    model_config = ConfigDict(extra="forbid")
    employee_id: int = Field(gt=0)


class BulkAttributionApplyInput(BaseModel):
    preview_token: str = Field(min_length=64, max_length=64)


class PartnerStatusInput(BaseModel):
    status: Literal["active", "suspended", "terminated", "settled"]
    effective_date: date
    reason: str = Field(min_length=2, max_length=1000)


class EntryTransitionInput(BaseModel):
    to_status: Literal["confirmed", "payable", "paid", "reversed"]
    reason: Optional[str] = Field(None, max_length=1000)
    payout_reference: Optional[str] = Field(None, max_length=160)


@router.get("/dashboard")
async def dashboard(
    month: Optional[str] = Query(None, pattern=r"^\d{4}-(0[1-9]|1[0-2])$"),
    _user: UserResponse = Depends(get_finance_user),
    db: AsyncSession = Depends(get_db),
):
    entry_query = select(CommissionEntry)
    if month:
        entry_query = entry_query.where(CommissionEntry.service_month == month)
    entries = (await db.scalars(entry_query.order_by(CommissionEntry.occurred_at.desc(), CommissionEntry.id.desc()))).all()
    partners = (await db.scalars(select(SalesPartner).order_by(SalesPartner.id.desc()))).all()
    employee_ids = {row.employee_id for row in partners if row.employee_id}
    linked_employees = (await db.scalars(select(Employees).where(Employees.id.in_(employee_ids)))).all() if employee_ids else []
    employee_map = {row.id: row for row in linked_employees}
    agreements = (await db.scalars(select(CommissionAgreement).order_by(CommissionAgreement.partner_id, CommissionAgreement.version.desc()))).all()
    attributions = (await db.scalars(select(CustomerCommissionAttribution).order_by(CustomerCommissionAttribution.id.desc()))).all()
    customer_ids = {row.customer_id for row in attributions} | {row.customer_id for row in entries}
    customers = (await db.scalars(select(Customers).where(Customers.id.in_(customer_ids)))).all() if customer_ids else []
    customer_map = {row.id: row.business_name for row in customers}
    partner_map = {row.id: row.name for row in partners}
    quality = await commission_data_quality(db)
    currencies: dict[str, dict[str, float]] = {}
    for entry in entries:
        bucket = currencies.setdefault(entry.currency, {"pending": 0, "confirmed_expense": 0, "payable": 0, "paid": 0})
        if entry.status == "pending_confirmation": bucket["pending"] += entry.commission_amount
        if entry.status in {"confirmed", "payable", "paid"}: bucket["confirmed_expense"] += entry.commission_amount
        if entry.status == "payable": bucket["payable"] += entry.commission_amount
        if entry.status == "paid": bucket["paid"] += entry.commission_amount
    return {
        "summary": {
            "partner_count": len(partners),
            "active_partner_count": sum(row.status == "active" for row in partners),
            "pending_count": sum(row.status == "pending_confirmation" for row in entries),
            "currencies": {code: {key: round(value, 2) for key, value in values.items()} for code, values in currencies.items()},
            "accounting_rule": "收入按实收总额记录；仅已确认佣金进入渠道佣金费用；发放仅冲减应付，不重复计费",
            "quality": {key: value for key, value in quality.items() if key != "issues"},
        },
        "quality_issues": quality["issues"],
        "partners": [{**_partner_payload(row), "login_account": _login_payload(employee_map.get(row.employee_id))} for row in partners],
        "agreements": [_agreement_payload(row) for row in agreements],
        "attributions": [{
            "id": row.id, "customer_id": row.customer_id, "customer_name": customer_map.get(row.customer_id),
            "engagement_id": row.engagement_id, "partner_id": row.partner_id,
            "partner_name": partner_map.get(row.partner_id), "attribution_role": row.attribution_role,
            "effective_from": row.effective_from, "effective_to": row.effective_to,
            "is_active": row.is_active, "source_note": row.source_note,
            "commission_mode": row.commission_mode, "commission_start_date": row.commission_start_date,
            "first_service_start": row.first_service_start, "history_basis": row.history_basis,
        } for row in attributions],
        "entries": [{
            "id": row.id, "partner_id": row.partner_id, "partner_name": partner_map.get(row.partner_id),
            "customer_id": row.customer_id, "customer_name": customer_map.get(row.customer_id),
            "payment_id": row.payment_id, "refund_id": row.refund_id, "original_entry_id": row.original_entry_id,
            "entry_type": row.entry_type, "status": row.status, "service_month": row.service_month,
            "occurred_at": row.occurred_at, "currency": row.currency,
            "gross_receipt_amount": row.gross_receipt_amount, "eligible_service_amount": row.eligible_service_amount,
            "contract_rate": row.contract_rate, "inactivity_months": row.inactivity_months,
            "activity_multiplier": row.activity_multiplier, "commission_amount": row.commission_amount,
            "confirmed_at": row.confirmed_at, "payable_at": row.payable_at,
            "paid_at": row.paid_at, "payout_reference": row.payout_reference,
            **_entry_period_payload(row),
        } for row in entries],
    }


@router.get("/assignment-options")
async def assignment_options(
    _user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Safe selector data for customer intake; agreement rates stay finance-only."""
    partners = (await db.scalars(select(SalesPartner).where(
        SalesPartner.status == "active"
    ).order_by(SalesPartner.partner_type, SalesPartner.name))).all()
    return {
        "items": [{
            "id": row.id,
            "partner_code": row.partner_code,
            "name": row.name,
            "partner_type": row.partner_type,
        } for row in partners],
        "automatic_rule": "优先匹配已建档的内部销售；未匹配时归属公司直营",
    }


@router.get("/my-dashboard")
async def my_partner_dashboard(
    user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
    partner_id: Annotated[Optional[int], Query(gt=0)] = None,
):
    """Read-only, partner-scoped portal data. Never returns company-wide finance."""
    partner, available_partners, owner_readonly = await _portal_partner_scope(user, db, partner_id)
    agreements = (await db.scalars(select(CommissionAgreement).where(
        CommissionAgreement.partner_id == partner.id,
    ).order_by(CommissionAgreement.version.desc()))).all()
    attributions = (await db.scalars(select(CustomerCommissionAttribution).where(
        CustomerCommissionAttribution.partner_id == partner.id,
    ).order_by(CustomerCommissionAttribution.is_active.desc(), CustomerCommissionAttribution.effective_from.desc()))).all()
    entries = (await db.scalars(select(CommissionEntry).where(
        CommissionEntry.partner_id == partner.id,
    ).order_by(CommissionEntry.occurred_at.desc(), CommissionEntry.id.desc()))).all()

    customer_ids = {row.customer_id for row in attributions} | {row.customer_id for row in entries}
    scope_attributions = (await db.scalars(select(CustomerCommissionAttribution).where(
        CustomerCommissionAttribution.customer_id.in_(customer_ids),
        CustomerCommissionAttribution.attribution_role == "primary",
    ))).all() if customer_ids else []
    customers = (await db.scalars(select(Customers).where(Customers.id.in_(customer_ids)))).all() if customer_ids else []
    engagements = (await db.scalars(select(CustomerEngagement).where(CustomerEngagement.customer_id.in_(customer_ids)))).all() if customer_ids else []
    subscriptions = (await db.scalars(select(Subscriptions).where(Subscriptions.customer_id.in_(customer_ids)))).all() if customer_ids else []
    payments = (await db.scalars(select(Payments).where(
        Payments.customer_id.in_(customer_ids),
        Payments.amount_paid > 0,
    ))).all() if customer_ids else []
    line_ids = {row.business_line_id for row in agreements if row.business_line_id} | {row.business_line_id for row in engagements if row.business_line_id}
    product_ids = {row.product_id for row in agreements if row.product_id} | {row.product_id for row in engagements if row.product_id}
    lines = (await db.scalars(select(BusinessLine).where(BusinessLine.id.in_(line_ids)))).all() if line_ids else []
    products = (await db.scalars(select(ProductCatalog).where(ProductCatalog.id.in_(product_ids)))).all() if product_ids else []
    customer_map = {row.id: row for row in customers}
    line_map = {row.id: row.name for row in lines}
    line_recurring_map = {row.id: row.is_recurring for row in lines}
    product_map = {row.id: row.name for row in products}

    currencies: dict[str, dict[str, float]] = {}
    for entry in entries:
        bucket = currencies.setdefault(entry.currency, {"pending": 0.0, "confirmed": 0.0, "payable": 0.0, "paid": 0.0})
        if entry.status == "pending_confirmation": bucket["pending"] += entry.commission_amount
        if entry.status in {"confirmed", "payable", "paid"}: bucket["confirmed"] += entry.commission_amount
        if entry.status == "payable": bucket["payable"] += entry.commission_amount
        if entry.status == "paid": bucket["paid"] += entry.commission_amount

    customer_status_rows = build_partner_customer_status_rows(
        attributions=list(attributions),
        customer_map=customer_map,
        engagements=list(engagements),
        subscriptions=list(subscriptions),
        payments=list(payments),
        business_line_map=line_map,
        business_line_recurring_map=line_recurring_map,
        product_map=product_map,
        scope_attributions=list(scope_attributions),
    )
    status_summary = partner_status_summary(customer_status_rows)

    return {
        "portal_mode": "owner_readonly" if owner_readonly else "partner",
        "available_partners": [{
            "id": row.id,
            "partner_code": row.partner_code,
            "name": row.name,
            "status": row.status,
        } for row in available_partners],
        "partner": _portal_partner_payload(partner),
        "summary": {
            "active_customer_count": len({row["customer_id"] for row in customer_status_rows if row["is_active"]}),
            "ledger_count": len(entries),
            "currencies": currencies,
            **status_summary,
            "status_updated_at": utcnow(),
        },
        "agreements": [{
            **_portal_agreement_payload(row),
            "business_line_name": line_map.get(row.business_line_id) if row.business_line_id else "全部业务线",
            "product_name": product_map.get(row.product_id) if row.product_id else "全部产品",
        } for row in agreements],
        "customers": customer_status_rows,
        "entries": [{
            "id": row.id,
            "customer_id": row.customer_id,
            "customer_name": customer_map.get(row.customer_id).business_name if customer_map.get(row.customer_id) else f"客户 #{row.customer_id}",
            "engagement_name": next((item["engagement_name"] for item in customer_status_rows if item["engagement_id"] == row.engagement_id and item["is_active"]), None) if row.engagement_id else None,
            "entry_type": row.entry_type,
            "status": row.status,
            "service_month": row.service_month,
            "occurred_at": row.occurred_at,
            "currency": row.currency,
            "eligible_service_amount": row.eligible_service_amount,
            "contract_rate": row.contract_rate,
            "inactivity_months": row.inactivity_months,
            "activity_multiplier": row.activity_multiplier,
            "commission_amount": row.commission_amount,
            "paid_at": row.paid_at,
            "payout_reference": row.payout_reference,
            **_entry_period_payload(row),
        } for row in entries],
    }


@router.get("/options")
async def options(
    _user: UserResponse = Depends(get_finance_user),
    db: AsyncSession = Depends(get_db),
):
    employees = (await db.scalars(select(Employees).where(Employees.status.in_(("active", "probation"))).order_by(Employees.name))).all()
    customers = (await db.scalars(select(Customers).order_by(Customers.business_name))).all()
    lines = (await db.scalars(select(BusinessLine).where(BusinessLine.is_active.is_(True)).order_by(BusinessLine.id))).all()
    products = (await db.scalars(select(ProductCatalog).where(ProductCatalog.is_active.is_(True)).order_by(ProductCatalog.name))).all()
    engagements = (await db.scalars(select(CustomerEngagement).order_by(CustomerEngagement.customer_id, CustomerEngagement.id))).all()
    return {
        "employees": [{"id": row.id, "name": row.name, "employee_code": row.employee_code, "role": row.role} for row in employees],
        "customers": [{"id": row.id, "name": row.business_name, "code": row.customer_code} for row in customers],
        "business_lines": [{"id": row.id, "name": row.name, "code": row.code} for row in lines],
        "products": [{"id": row.id, "name": row.name, "business_line_id": row.business_line_id} for row in products],
        "engagements": [{"id": row.id, "customer_id": row.customer_id, "package_name": row.package_name, "status": row.status} for row in engagements],
        "default_decay": DEFAULT_DECAY,
    }


@router.post("/partners", status_code=status.HTTP_201_CREATED)
async def create_partner(
    payload: PartnerInput,
    user: UserResponse = Depends(get_finance_user),
    db: AsyncSession = Depends(get_db),
):
    if payload.partner_type == "direct":
        raise HTTPException(status_code=409, detail="公司直营由系统自动建立，不能手工新增")
    if await db.scalar(select(SalesPartner.id).where(SalesPartner.partner_code == payload.partner_code)):
        raise HTTPException(status_code=409, detail="渠道编号已存在")
    if payload.employee_id:
        if payload.partner_type in {"agency", "partner"}:
            await _validate_partner_login(db, payload.employee_id)
        elif not await db.get(Employees, payload.employee_id):
            raise HTTPException(status_code=404, detail="关联员工不存在")
    row = SalesPartner(**payload.model_dump(), status="active", created_by_id=str(user.id), created_by_name=actor_name(user))
    db.add(row)
    try:
        await db.commit()
    except IntegrityError as exc:
        await db.rollback()
        raise HTTPException(status_code=409, detail="渠道编号或登录绑定已存在，请刷新后核对") from exc
    await db.refresh(row)
    return _partner_payload(row)


@router.get("/partner-login-options")
async def partner_login_options(
    _user: UserResponse = Depends(get_finance_user),
    db: AsyncSession = Depends(get_db),
):
    linked_ids = select(SalesPartner.employee_id).where(
        SalesPartner.employee_id.is_not(None),
        SalesPartner.partner_type.in_(("agency", "partner")),
    )
    employees = (await db.scalars(select(Employees).where(
        Employees.role == "sales_partner", Employees.status.in_(("active", "probation")),
        Employees.id.not_in(linked_ids),
    ).order_by(Employees.name, Employees.id))).all()
    return {"items": [_login_payload(row) for row in employees]}


@router.get("/unbound-partners")
async def unbound_partners(
    _user: UserResponse = Depends(get_finance_user),
    db: AsyncSession = Depends(get_db),
):
    rows = (await db.scalars(select(SalesPartner).where(
        SalesPartner.partner_type.in_(("agency", "partner")),
        SalesPartner.employee_id.is_(None), SalesPartner.status.in_(("active", "suspended")),
    ).order_by(SalesPartner.name, SalesPartner.id))).all()
    return {"items": [{"id": row.id, "partner_code": row.partner_code, "name": row.name,
                       "partner_type": row.partner_type, "contact_email": row.contact_email} for row in rows]}


@router.post("/partners/{partner_id}/login-account")
async def bind_partner_login(
    partner_id: int,
    payload: PartnerLoginInput,
    user: UserResponse = Depends(get_finance_user),
    db: AsyncSession = Depends(get_db),
):
    # Same lock order as creation: employee first, then its target partner.
    employee = await _validate_partner_login(db, payload.employee_id, partner_id=partner_id)
    partner = await db.scalar(select(SalesPartner).where(SalesPartner.id == partner_id).with_for_update()
                              .execution_options(populate_existing=True))
    if not partner:
        raise HTTPException(status_code=404, detail="渠道不存在")
    if partner.partner_type not in {"agency", "partner"}:
        raise HTTPException(status_code=409, detail="只有外部代理或合伙人可以绑定渠道登录账号")
    if partner.status in {"terminated", "settled"}:
        raise HTTPException(status_code=409, detail="已终止或结清的渠道不能新增登录绑定")
    if partner.employee_id not in {None, employee.id}:
        raise HTTPException(status_code=409, detail="该渠道已绑定另一账号，不能直接替换登录归属")
    if partner.employee_id is None:
        partner.employee_id = employee.id
        note = f"{utcnow().isoformat()} 登录账号绑定 {employee.id}；操作人 {actor_name(user)}"
        partner.notes = "\n".join(filter(None, [partner.notes, note]))
        try:
            await db.commit()
        except IntegrityError as exc:
            await db.rollback()
            raise HTTPException(status_code=409, detail="登录账号已被其他渠道绑定，请刷新后核对") from exc
        await db.refresh(partner)
    return {**_partner_payload(partner), "login_account": _login_payload(employee)}


@router.post("/partners/{partner_id}/status")
async def change_partner_status(
    partner_id: int,
    payload: PartnerStatusInput,
    user: UserResponse = Depends(get_finance_user),
    db: AsyncSession = Depends(get_db),
):
    partner = await db.get(SalesPartner, partner_id)
    if not partner:
        raise HTTPException(status_code=404, detail="渠道不存在")
    if partner.partner_type == "direct":
        raise HTTPException(status_code=409, detail="公司直营是系统归属，不能暂停或停止合作")
    if payload.effective_date < partner.joined_at:
        raise HTTPException(status_code=400, detail="生效日期不能早于加入日期")
    partner.status = payload.status
    partner.stopped_at = payload.effective_date if payload.status in {"terminated", "settled"} else None
    partner.notes = "\n".join(filter(None, [partner.notes, f"{payload.effective_date} {payload.status}: {payload.reason}"]))
    transferred = 0
    if payload.status in {"terminated", "settled"}:
        transferred = await transfer_partner_attributions_to_direct(
            db,
            partner_id=partner.id,
            stopped_at=payload.effective_date,
            actor_id=str(user.id),
            actor_name=actor_name(user),
        )
    await db.commit()
    return {**_partner_payload(partner), "transferred_to_direct": transferred}


@router.post("/agreements", status_code=status.HTTP_201_CREATED)
async def create_agreement(
    payload: AgreementInput,
    user: UserResponse = Depends(get_finance_user),
    db: AsyncSession = Depends(get_db),
):
    partner = await db.get(SalesPartner, payload.partner_id)
    if not partner:
        raise HTTPException(status_code=404, detail="渠道不存在")
    if partner.partner_type == "direct":
        raise HTTPException(status_code=409, detail="公司直营不产生外部佣金，无需配置分润协议")
    if partner.status in {"terminated", "settled"}:
        raise HTTPException(status_code=409, detail="已终止或已结清的渠道不能新增协议")
    if payload.product_id:
        product = await db.get(ProductCatalog, payload.product_id)
        if not product or (payload.business_line_id and product.business_line_id != payload.business_line_id):
            raise HTTPException(status_code=400, detail="产品与业务线不匹配")
    latest_version = await db.scalar(select(func.max(CommissionAgreement.version)).where(CommissionAgreement.partner_id == partner.id)) or 0
    existing = (await db.scalars(select(CommissionAgreement).where(
        CommissionAgreement.partner_id == partner.id,
        CommissionAgreement.status == "active",
        CommissionAgreement.business_line_id.is_(payload.business_line_id) if payload.business_line_id is None else CommissionAgreement.business_line_id == payload.business_line_id,
        CommissionAgreement.product_id.is_(payload.product_id) if payload.product_id is None else CommissionAgreement.product_id == payload.product_id,
        or_(CommissionAgreement.effective_to.is_(None), CommissionAgreement.effective_to >= payload.effective_from),
    ))).all()
    for row in existing:
        if row.effective_from >= payload.effective_from:
            raise HTTPException(status_code=409, detail="该范围已存在同日或更晚生效的协议，请调整生效日期")
        row.effective_to = payload.effective_from - timedelta(days=1)
        row.status = "expired"
    row = CommissionAgreement(
        partner_id=payload.partner_id, version=latest_version + 1,
        business_line_id=payload.business_line_id, product_id=payload.product_id,
        first_order_rate=payload.first_order_rate, renewal_rate=payload.renewal_rate,
        activity_decay_json=json.dumps(payload.activity_decay, sort_keys=True),
        refund_guard_days=payload.refund_guard_days, effective_from=payload.effective_from,
        status="active", notes=payload.notes, created_by_id=str(user.id), created_by_name=actor_name(user),
        calculation_version="service_month_v2", renewal_policy="fixed",
    )
    db.add(row)
    await db.commit()
    await db.refresh(row)
    await scan_commissions(db)
    return _agreement_payload(row)


@router.get("/attributions/bulk-preview")
async def bulk_attribution_preview(
    _user: UserResponse = Depends(get_finance_user),
    db: AsyncSession = Depends(get_db),
):
    return await preview_bulk_customer_attributions(db)


@router.post("/attributions/bulk-apply")
async def bulk_attribution_apply(
    payload: BulkAttributionApplyInput,
    user: UserResponse = Depends(get_finance_user),
    db: AsyncSession = Depends(get_db),
):
    try:
        result = await apply_bulk_customer_attributions(
            db,
            preview_token=payload.preview_token,
            actor_id=str(user.id),
            actor_name=actor_name(user),
        )
        await db.commit()
        return result
    except ValueError as exc:
        await db.rollback()
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    except Exception:
        await db.rollback()
        raise


@router.post("/attributions", status_code=status.HTTP_201_CREATED)
async def create_attribution(
    payload: AttributionInput,
    user: UserResponse = Depends(get_finance_user),
    db: AsyncSession = Depends(get_db),
):
    customer = await db.get(Customers, payload.customer_id)
    partner = await db.get(SalesPartner, payload.partner_id)
    if not customer or not partner:
        raise HTTPException(status_code=404, detail="客户或渠道不存在")
    if partner.status != "active":
        raise HTTPException(status_code=409, detail="只能归属给正常合作中的渠道")
    if payload.engagement_id:
        engagement = await db.get(CustomerEngagement, payload.engagement_id)
        if not engagement or engagement.customer_id != payload.customer_id:
            raise HTTPException(status_code=400, detail="项目不属于所选客户")
    try:
        row = await assign_customer_commission_owner(
            db,
            **payload.model_dump(),
            actor_id=str(user.id),
            actor_name=actor_name(user),
        )
    except ValueError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    await db.commit()
    await db.refresh(row)
    await scan_commissions(db)
    return {"id": row.id, "customer_id": row.customer_id, "partner_id": row.partner_id, "effective_from": row.effective_from}


@router.post("/attributions/preview")
async def attribution_preview(
    payload: AttributionInput,
    _user: UserResponse = Depends(get_finance_user),
    db: AsyncSession = Depends(get_db),
):
    """Read-only impact preview; saving reruns the same service guard."""
    customer = await db.get(Customers, payload.customer_id)
    partner = await db.get(SalesPartner, payload.partner_id)
    if not customer or not partner:
        raise HTTPException(status_code=404, detail="客户或渠道不存在")
    if partner.status != "active":
        raise HTTPException(status_code=409, detail="只能归属给正常合作中的渠道")
    if payload.engagement_id:
        engagement = await db.get(CustomerEngagement, payload.engagement_id)
        if not engagement or engagement.customer_id != payload.customer_id:
            raise HTTPException(status_code=400, detail="项目不属于所选客户")
    try:
        return await preview_customer_commission_owner(db, **payload.model_dump())
    except ValueError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc


@router.get("/payments/{payment_id}/preview")
async def payment_commission_preview(
    payment_id: int,
    _user: UserResponse = Depends(get_finance_user),
    db: AsyncSession = Depends(get_db),
):
    payment = await db.get(Payments, payment_id)
    if not payment:
        raise HTTPException(status_code=404, detail="收款记录不存在")
    try:
        return {**await preview_payment_commission(db, payment), "currency": (payment.currency or "USD").upper()}
    except ValueError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc


@router.post("/scan")
async def run_scan(
    _user: UserResponse = Depends(get_finance_user),
    db: AsyncSession = Depends(get_db),
):
    return await scan_commissions(db)


@router.post("/entries/{entry_id}/transition")
async def transition_entry(
    entry_id: int,
    payload: EntryTransitionInput,
    user: UserResponse = Depends(get_finance_user),
    db: AsyncSession = Depends(get_db),
):
    reference = await db.get(CommissionEntry, entry_id)
    if not reference:
        raise HTTPException(status_code=404, detail="佣金记录不存在")
    # Match ownership changes and scanner lock order: customer -> payment -> entry.
    # A classification change cannot pass its preview concurrently with confirmation.
    await db.scalar(select(Customers).where(Customers.id == reference.customer_id).with_for_update())
    await db.scalar(select(Payments).where(Payments.id == reference.payment_id).with_for_update())
    entry = await db.scalar(select(CommissionEntry).where(CommissionEntry.id == entry_id)
                            .with_for_update().execution_options(populate_existing=True))
    if not entry:
        raise HTTPException(status_code=404, detail="佣金记录不存在")
    if payload.to_status not in ENTRY_TRANSITIONS.get(entry.status, set()):
        raise HTTPException(status_code=409, detail=f"不允许从 {entry.status} 变更为 {payload.to_status}")
    if payload.to_status == "confirmed":
        try:
            await validate_commission_entry_confirmation(db, entry)
        except ValueError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
    if payload.to_status == "reversed":
        try:
            await validate_commission_entry_reversal(db, entry)
        except ValueError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
    changes_profit_inclusion = (
        (entry.status in PROFIT_COMMISSION_STATUSES)
        != (payload.to_status in PROFIT_COMMISSION_STATUSES)
    )
    if changes_profit_inclusion:
        await ensure_profit_months_open(
            db,
            [entry.occurred_at, entry.service_month],
            action="变更佣金状态",
        )
    if payload.to_status == "reversed" and not (payload.reason or "").strip():
        raise HTTPException(status_code=400, detail="作废必须填写原因")
    agreement = await db.get(CommissionAgreement, entry.agreement_id)
    if payload.to_status == "confirmed" and agreement and entry.entry_type == "first_order":
        guard_ends = entry.occurred_at + timedelta(days=agreement.refund_guard_days)
        if guard_ends.tzinfo is None:
            guard_ends = guard_ends.replace(tzinfo=timezone.utc)
        if utcnow() < guard_ends:
            raise HTTPException(status_code=409, detail=f"首单仍在 {agreement.refund_guard_days} 天退款观察期，{guard_ends.date()} 后可确认")
    if payload.to_status == "paid" and not (payload.payout_reference or "").strip():
        raise HTTPException(status_code=400, detail="标记已发放必须填写付款流水号或凭证编号")
    partner = await db.get(SalesPartner, entry.partner_id)
    if payload.to_status in {"payable", "paid"} and partner and partner.status == "suspended":
        raise HTTPException(status_code=409, detail="该渠道当前暂停结算，请恢复合作或完成复核后再进入应付/发放")
    previous = entry.status
    entry.status = payload.to_status
    now = utcnow()
    if payload.to_status == "confirmed": entry.confirmed_at = now
    if payload.to_status == "payable": entry.payable_at = now
    if payload.to_status == "paid":
        entry.paid_at = now
        entry.payout_reference = payload.payout_reference.strip()
    db.add(CommissionStatusEvent(
        commission_entry_id=entry.id, from_status=previous, to_status=entry.status,
        reason=(payload.reason or "").strip() or None, actor_id=str(user.id), actor_name=actor_name(user),
    ))
    await db.commit()
    return {"id": entry.id, "status": entry.status, "message": "佣金状态已更新，历史快照未改写"}

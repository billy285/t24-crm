import logging
from typing import Any, Dict, Optional

from sqlalchemy import func, or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from models.customer_ai_copies import Customer_ai_copies

from services.customer_scope import apply_customer_scope, ensure_customer_access

from services.customer_record_audit import record_customer_change

logger = logging.getLogger(__name__)


class Customer_ai_copiesService:
    """Service layer for saved customer AI copy drafts."""

    def __init__(self, db: AsyncSession):
        self.db = db

    async def create(self, data: Dict[str, Any], user_id: Optional[str] = None) -> Customer_ai_copies:
        try:
            if user_id:
                data["user_id"] = user_id
            obj = Customer_ai_copies(**data)
            self.db.add(obj)
            await self.db.commit()
            await self.db.refresh(obj)
            return obj
        except Exception as e:
            await self.db.rollback()
            logger.error("Error creating customer_ai_copies: %s", e)
            raise

    async def get_by_id(self, obj_id: int, scope_user: Optional[Any] = None) -> Optional[Customer_ai_copies]:
        query = apply_customer_scope(select(Customer_ai_copies).where(Customer_ai_copies.id == obj_id), Customer_ai_copies, scope_user)
        result = await self.db.execute(query)
        return result.scalar_one_or_none()

    async def get_list(
        self,
        skip: int = 0,
        limit: int = 50,
        query_dict: Optional[Dict[str, Any]] = None,
        sort: Optional[str] = None,
        search: Optional[str] = None,
        scope_user: Optional[Any] = None,
    ) -> Dict[str, Any]:
        query = select(Customer_ai_copies)
        count_query = select(func.count(Customer_ai_copies.id))
        query = apply_customer_scope(query, Customer_ai_copies, scope_user)
        count_query = apply_customer_scope(count_query, Customer_ai_copies, scope_user)

        if query_dict:
            for field, value in query_dict.items():
                if hasattr(Customer_ai_copies, field):
                    query = query.where(getattr(Customer_ai_copies, field) == value)
                    count_query = count_query.where(getattr(Customer_ai_copies, field) == value)

        keyword = (search or "").strip()
        if keyword:
            like_keyword = f"%{keyword}%"
            search_filter = or_(
                Customer_ai_copies.title.ilike(like_keyword),
                Customer_ai_copies.content.ilike(like_keyword),
                Customer_ai_copies.extra_requirements.ilike(like_keyword),
            )
            query = query.where(search_filter)
            count_query = count_query.where(search_filter)

        count_result = await self.db.execute(count_query)
        total = count_result.scalar() or 0

        if sort:
            if sort.startswith("-"):
                field_name = sort[1:]
                if hasattr(Customer_ai_copies, field_name):
                    query = query.order_by(getattr(Customer_ai_copies, field_name).desc())
            elif hasattr(Customer_ai_copies, sort):
                query = query.order_by(getattr(Customer_ai_copies, sort))
        else:
            query = query.order_by(Customer_ai_copies.id.desc())

        result = await self.db.execute(query.offset(skip).limit(limit))
        return {"items": result.scalars().all(), "total": total, "skip": skip, "limit": limit}

    async def update(self, obj_id: int, update_data: Dict[str, Any], scope_user: Optional[Any] = None) -> Optional[Customer_ai_copies]:
        try:
            obj = await self.get_by_id(obj_id, scope_user=scope_user)
            if not obj:
                return None
            if scope_user is not None:
                await ensure_customer_access(self.db, scope_user, obj.customer_id, write=True, module="materials")
            record_customer_change(self.db, scope_user, obj, "materials", changes=update_data)
            for key, value in update_data.items():
                if hasattr(obj, key) and key != "user_id":
                    setattr(obj, key, value)
            await self.db.commit()
            await self.db.refresh(obj)
            return obj
        except Exception as e:
            await self.db.rollback()
            logger.error("Error updating customer_ai_copies %s: %s", obj_id, e)
            raise

    async def delete(self, obj_id: int, scope_user: Optional[Any] = None) -> bool:
        try:
            obj = await self.get_by_id(obj_id, scope_user=scope_user)
            if not obj:
                return False
            if scope_user is not None:
                await ensure_customer_access(self.db, scope_user, obj.customer_id, write=True, module="materials", action="delete")
            record_customer_change(self.db, scope_user, obj, "materials", deleted=True)
            await self.db.delete(obj)
            await self.db.commit()
            return True
        except Exception as e:
            await self.db.rollback()
            logger.error("Error deleting customer_ai_copies %s: %s", obj_id, e)
            raise

import logging
from typing import Optional, Dict, Any, List

from core.mask_crypto import decrypt_text, encrypt_text, key_prefix
from fastapi import HTTPException
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from models.media_accounts import Media_accounts
from services.customer_scope import apply_customer_scope, ensure_customer_access

from services.customer_record_audit import record_customer_change

logger = logging.getLogger(__name__)


def has_media_account_password(value: Optional[str]) -> bool:
    return isinstance(value, str) and bool(value.strip())


def encrypt_media_account_password(value: Optional[str]) -> Optional[str]:
    if value is None:
        return None
    raw = str(value).strip()
    if not raw:
        return None
    if raw.startswith(key_prefix):
        return raw
    return encrypt_text(raw)


def decrypt_media_account_password(value: Optional[str]) -> str:
    if not has_media_account_password(value):
        return ""
    raw = str(value)
    if not raw.startswith(key_prefix):
        return raw
    try:
        return decrypt_text(raw)
    except Exception as exc:  # pragma: no cover - defensive
        logger.warning("Failed to decrypt media account password: %s", exc)
        return ""


def guard_media_password_write(data: Dict[str, Any], scope_user) -> Dict[str, Any]:
    """Customer collaboration never grants credential management."""
    safe = dict(data)
    if scope_user is not None and str(getattr(scope_user, "role", "")).lower() != "super_admin":
        if has_media_account_password(safe.get("login_password")):
            raise HTTPException(status_code=403, detail="仅老板可以设置媒体账号密码")
        # Hidden fields posted by old editors must not clear existing secrets.
        safe.pop("login_password", None)
    return safe


def guard_media_password_query(query_dict, sort):
    if query_dict is not None and not isinstance(query_dict, dict):
        raise HTTPException(status_code=400, detail="Query must be a JSON object")
    if (query_dict and "login_password" in query_dict) or str(sort or "").strip().lstrip("+-") == "login_password":
        raise HTTPException(status_code=400, detail="账号密码不支持筛选或排序")


def normalize_media_account_payload(
    data: Dict[str, Any],
    *,
    preserve_existing_password: bool = False,
) -> Dict[str, Any]:
    normalized = dict(data)
    if "login_password" not in normalized:
        return normalized

    password_value = normalized.get("login_password")
    if password_value is None:
        if preserve_existing_password:
            normalized.pop("login_password", None)
        return normalized

    encrypted = encrypt_media_account_password(password_value)
    if encrypted is None:
        if preserve_existing_password:
            normalized.pop("login_password", None)
        else:
            normalized["login_password"] = None
        return normalized

    normalized["login_password"] = encrypted
    return normalized


# ------------------ Service Layer ------------------
class Media_accountsService:
    """Service layer for Media_accounts operations"""

    def __init__(self, db: AsyncSession):
        self.db = db

    async def create(self, data: Dict[str, Any], user_id: Optional[str] = None, scope_user: Optional[Any] = None) -> Optional[Media_accounts]:
        """Create a new media_accounts"""
        try:
            data = normalize_media_account_payload(guard_media_password_write(data, scope_user))
            if user_id:
                data['user_id'] = user_id
            obj = Media_accounts(**data)
            self.db.add(obj)
            await self.db.commit()
            await self.db.refresh(obj)
            logger.info(f"Created media_accounts with id: {obj.id}")
            return obj
        except Exception as e:
            await self.db.rollback()
            logger.error(f"Error creating media_accounts: {str(e)}")
            raise

    async def check_ownership(self, obj_id: int, user_id: str) -> bool:
        """Backward-compatible record existence check.

        ``user_id`` is retained as creator/audit attribution only. API access is
        enforced through the linked customer's visibility scope.
        """
        try:
            obj = await self.get_by_id(obj_id)
            return obj is not None
        except Exception as e:
            logger.error(f"Error checking ownership for media_accounts {obj_id}: {str(e)}")
            return False

    async def get_by_id(
        self,
        obj_id: int,
        user_id: Optional[str] = None,
        scope_user: Optional[Any] = None,
    ) -> Optional[Media_accounts]:
        """Get a media account if its linked customer is visible to the user."""
        try:
            query = select(Media_accounts).where(Media_accounts.id == obj_id)
            query = apply_customer_scope(query, Media_accounts, scope_user)
            result = await self.db.execute(query)
            return result.scalar_one_or_none()
        except Exception as e:
            logger.error(f"Error fetching media_accounts {obj_id}: {str(e)}")
            raise

    async def get_list(
        self, 
        skip: int = 0, 
        limit: int = 20, 
        user_id: Optional[str] = None,
        scope_user: Optional[Any] = None,
        query_dict: Optional[Dict[str, Any]] = None,
        sort: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Get media accounts constrained by linked-customer visibility."""
        guard_media_password_query(query_dict, sort)
        try:
            query = select(Media_accounts)
            count_query = select(func.count(Media_accounts.id))
            query = apply_customer_scope(query, Media_accounts, scope_user)
            count_query = apply_customer_scope(count_query, Media_accounts, scope_user)
            
            if query_dict:
                for field, value in query_dict.items():
                    if hasattr(Media_accounts, field):
                        query = query.where(getattr(Media_accounts, field) == value)
                        count_query = count_query.where(getattr(Media_accounts, field) == value)
            
            count_result = await self.db.execute(count_query)
            total = count_result.scalar()

            if sort:
                if sort.startswith('-'):
                    field_name = sort[1:]
                    if hasattr(Media_accounts, field_name):
                        query = query.order_by(getattr(Media_accounts, field_name).desc())
                else:
                    if hasattr(Media_accounts, sort):
                        query = query.order_by(getattr(Media_accounts, sort))
            else:
                query = query.order_by(Media_accounts.id.desc())

            result = await self.db.execute(query.offset(skip).limit(limit))
            items = result.scalars().all()

            return {
                "items": items,
                "total": total,
                "skip": skip,
                "limit": limit,
            }
        except Exception as e:
            logger.error(f"Error fetching media_accounts list: {str(e)}")
            raise

    async def update(
        self,
        obj_id: int,
        update_data: Dict[str, Any],
        user_id: Optional[str] = None,
        scope_user: Optional[Any] = None,
    ) -> Optional[Media_accounts]:
        """Update a media account within the caller's customer scope."""
        update_data = guard_media_password_write(update_data, scope_user)
        try:
            obj = await self.get_by_id(obj_id, scope_user=scope_user)
            if not obj:
                logger.warning(f"Media_accounts {obj_id} not found for update")
                return None
            await ensure_customer_access(self.db, scope_user, obj.customer_id, write=True, module="materials")
            update_data = normalize_media_account_payload(update_data, preserve_existing_password=True)
            record_customer_change(self.db, scope_user, obj, "materials", changes=update_data)
            for key, value in update_data.items():
                if hasattr(obj, key) and key != 'user_id':
                    setattr(obj, key, value)

            await self.db.commit()
            await self.db.refresh(obj)
            logger.info(f"Updated media_accounts {obj_id}")
            return obj
        except Exception as e:
            await self.db.rollback()
            logger.error(f"Error updating media_accounts {obj_id}: {str(e)}")
            raise

    async def delete(
        self,
        obj_id: int,
        user_id: Optional[str] = None,
        scope_user: Optional[Any] = None,
    ) -> bool:
        """Delete a media account within the caller's customer scope."""
        try:
            obj = await self.get_by_id(obj_id, scope_user=scope_user)
            if not obj:
                logger.warning(f"Media_accounts {obj_id} not found for deletion")
                return False
            await ensure_customer_access(self.db, scope_user, obj.customer_id, write=True, module="materials", action="delete")
            record_customer_change(self.db, scope_user, obj, "materials", deleted=True)
            await self.db.delete(obj)
            await self.db.commit()
            logger.info(f"Deleted media_accounts {obj_id}")
            return True
        except Exception as e:
            await self.db.rollback()
            logger.error(f"Error deleting media_accounts {obj_id}: {str(e)}")
            raise

    async def get_by_field(self, field_name: str, field_value: Any) -> Optional[Media_accounts]:
        """Get media_accounts by any field"""
        try:
            if not hasattr(Media_accounts, field_name):
                raise ValueError(f"Field {field_name} does not exist on Media_accounts")
            result = await self.db.execute(
                select(Media_accounts).where(getattr(Media_accounts, field_name) == field_value)
            )
            return result.scalar_one_or_none()
        except Exception as e:
            logger.error(f"Error fetching media_accounts by {field_name}: {str(e)}")
            raise

    async def list_by_field(
        self, field_name: str, field_value: Any, skip: int = 0, limit: int = 20
    ) -> List[Media_accounts]:
        """Get list of media_accountss filtered by field"""
        try:
            if not hasattr(Media_accounts, field_name):
                raise ValueError(f"Field {field_name} does not exist on Media_accounts")
            result = await self.db.execute(
                select(Media_accounts)
                .where(getattr(Media_accounts, field_name) == field_value)
                .offset(skip)
                .limit(limit)
                .order_by(Media_accounts.id.desc())
            )
            return result.scalars().all()
        except Exception as e:
            logger.error(f"Error fetching media_accountss by {field_name}: {str(e)}")
            raise

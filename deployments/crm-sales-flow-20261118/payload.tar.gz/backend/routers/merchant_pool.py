import csv
import io
import json
import re
from datetime import datetime, timezone
from typing import Any, Literal, Optional
from urllib.parse import urlsplit

from fastapi import APIRouter, Depends, File, HTTPException, Query, UploadFile, status
from openpyxl import load_workbook
from pydantic import BaseModel, Field, ValidationError, field_validator, model_validator
from sqlalchemy import and_, case, func, or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db
from dependencies.auth import get_current_user
from models.customers import Customers
from models.merchant_pool import MerchantPool
from models.merchant_ai_analyses import MerchantAiAnalyses
from models.sales_leads import SalesLeads
from models.sales_intelligence import SalesLeadProfiles
from models.employees import Employees
from schemas.auth import UserResponse
from services.phone_numbers import normalize_phone_country, parse_phone_number, phone_match_key
from services.merchant_row_locks import lock_merchant_rows
from services.merchant_industries import merchant_industry_facets, merchant_industry_filter, normalize_merchant_industry
from services.merchant_identity import has_concrete_name_and_address
from services.prospect_verification import inherit_pool_quality, quality_for, quality_for_many, quality_status_expression, source_metadata_from_raw, unpack
from services.sales_contact_protection import ensure_phone_contact_allowed
from services.sales_workflow_locks import lock_sales_workflow
from services.sales_labels import sales_label_filter, target_labels
from services.sales_timezones import (GROUP_ZONES, STATE_CODES, STATE_NAMES, address_timezone_evidence,
                                      import_address_timezone, resolve_contact_timezone, sql_matches_contact_zones)


router = APIRouter(prefix="/api/v1/merchant-pool", tags=["merchant-pool"])

ADMIN_ROLES = {"admin", "super_admin"}
POOL_ROLES = ADMIN_ROLES | {"sales_manager"}
ISOLATED_STATUSES = {"no_phone", "duplicate", "existing_customer", "closed"}
ARCHIVED_STATUS = "archived"
CLOSED_MARKERS = {"closed", "permanently_closed", "关闭", "已关闭", "停业", "暂停营业"}


def _role(user: UserResponse) -> str:
    return str(user.role or "").strip().lower()


def _employee_id(user: UserResponse) -> int:
    try:
        return int(user.id)
    except (TypeError, ValueError):
        raise HTTPException(status_code=403, detail="当前账号未关联有效员工")


def _ensure_pool_role(user: UserResponse) -> None:
    if _role(user) not in POOL_ROLES:
        raise HTTPException(status_code=403, detail="只有销售主管或管理员可以访问待清洗商家池")


def _ensure_admin_role(user: UserResponse) -> None:
    if _role(user) not in ADMIN_ROLES:
        raise HTTPException(status_code=403, detail="只有系统管理员可以清理商家池数据")


def _normalize_phone(value: Optional[str], country: Optional[str] = None) -> str:
    return phone_match_key(value, country) or ""


def _normalize_text(value: Optional[str]) -> str:
    return re.sub(r"[\W_]+", "", (value or "").casefold(), flags=re.UNICODE)


def _normalize_website(value: Optional[str]) -> str:
    website = (value or "").strip().casefold()
    url_match = re.search(r"https?://[^\s\]\)]+", website, re.I)
    if url_match:
        website = url_match.group().rstrip(".,;:")
    if not website:
        return ""
    parsed = urlsplit(website if "://" in website else f"https://{website}")
    host = (parsed.hostname or "").removeprefix("www.")
    path = re.sub(r"/+", "/", parsed.path or "").rstrip("/")
    return f"{host}{path}" if host else ""


def _is_closed(value: Optional[str]) -> bool:
    normalized = (value or "").strip().casefold()
    return normalized in CLOSED_MARKERS


class MerchantRecord(BaseModel):
    business_name: str = Field(min_length=1, max_length=200)
    contact_name: Optional[str] = None
    phone: Optional[str] = None
    industry: Optional[str] = None
    country: Optional[str] = None
    state: Optional[str] = None
    city: Optional[str] = None
    address: Optional[str] = None
    website: Optional[str] = None
    rating: Optional[float] = Field(default=None, ge=0, le=5)
    google_business_url: Optional[str] = None
    google_rating: Optional[float] = Field(default=None, ge=0, le=5)
    google_review_count: Optional[int] = Field(default=None, ge=0)
    yelp_url: Optional[str] = None
    yelp_rating: Optional[float] = Field(default=None, ge=0, le=5)
    yelp_review_count: Optional[int] = Field(default=None, ge=0)
    social_profiles: Optional[str] = None
    recent_negative_reviews: Optional[str] = None
    content_update_summary: Optional[str] = None
    content_last_updated_at: Optional[datetime] = None
    source_record_id: Optional[str] = None
    business_status: Optional[str] = None
    collected_at: Optional[datetime] = None

    @field_validator("business_name")
    @classmethod
    def strip_business_name(cls, value: str) -> str:
        return value.strip()

    @field_validator("industry")
    @classmethod
    def normalize_industry(cls, value: Optional[str]) -> Optional[str]:
        return normalize_merchant_industry(value)


class MerchantImportRequest(BaseModel):
    data_source: str = Field(default="api", min_length=1, max_length=50)
    default_industry: Optional[str] = Field(default=None, max_length=100)
    # Keep the original keys so later enrichment can inspect imported evidence.
    records: list[dict[str, Any]] = Field(min_length=1, max_length=2000)


class MerchantUpdate(BaseModel):
    business_name: Optional[str] = None
    contact_name: Optional[str] = None
    phone: Optional[str] = None
    industry: Optional[str] = None
    country: Optional[str] = None
    state: Optional[str] = None
    city: Optional[str] = None
    address: Optional[str] = None
    website: Optional[str] = None
    rating: Optional[float] = Field(default=None, ge=0, le=5)
    google_business_url: Optional[str] = None
    google_rating: Optional[float] = Field(default=None, ge=0, le=5)
    google_review_count: Optional[int] = Field(default=None, ge=0)
    yelp_url: Optional[str] = None
    yelp_rating: Optional[float] = Field(default=None, ge=0, le=5)
    yelp_review_count: Optional[int] = Field(default=None, ge=0)
    social_profiles: Optional[str] = None
    recent_negative_reviews: Optional[str] = None
    content_update_summary: Optional[str] = None
    content_last_updated_at: Optional[datetime] = None
    data_source: Optional[str] = None
    business_status: Optional[str] = None

    @field_validator("industry")
    @classmethod
    def normalize_industry(cls, value: Optional[str]) -> Optional[str]:
        return normalize_merchant_industry(value)


class ConvertToLeadRequest(BaseModel):
    assigned_sales_id: Optional[int] = None


class BulkConvertToLeadRequest(BaseModel):
    merchant_ids: list[int] = Field(min_length=1, max_length=200)
    assigned_sales_id: int


class BulkMerchantIdsRequest(BaseModel):
    merchant_ids: list[int] = Field(min_length=1, max_length=200)


class BulkIndustryUpdateRequest(BulkMerchantIdsRequest):
    industry: str = Field(min_length=1, max_length=100)

    @field_validator("industry")
    @classmethod
    def strip_industry(cls, value: str) -> str:
        value = value.strip()
        if not value:
            raise ValueError("行业不能为空")
        return normalize_merchant_industry(value) or "__unclassified__"


class MerchantResponse(BaseModel):
    id: int
    business_name: str
    contact_name: Optional[str] = None
    phone: Optional[str] = None
    industry: Optional[str] = None
    country: Optional[str] = None
    state: Optional[str] = None
    city: Optional[str] = None
    address: Optional[str] = None
    timezone: Optional[str] = None
    timezone_group: str = "unknown"
    timezone_basis: str = "unknown"
    timezone_needs_confirmation: bool = True
    website: Optional[str] = None
    rating: Optional[float] = None
    google_business_url: Optional[str] = None
    google_rating: Optional[float] = None
    google_review_count: Optional[int] = None
    yelp_url: Optional[str] = None
    yelp_rating: Optional[float] = None
    yelp_review_count: Optional[int] = None
    social_profiles: Optional[str] = None
    recent_negative_reviews: Optional[str] = None
    content_update_summary: Optional[str] = None
    content_last_updated_at: Optional[datetime] = None
    data_source: str
    source_record_id: Optional[str] = None
    collected_at: datetime
    business_status: Optional[str] = None
    pool_status: str
    isolation_reason: Optional[str] = None
    duplicate_of_id: Optional[int] = None
    existing_customer_id: Optional[int] = None
    converted_lead_id: Optional[int] = None
    current_lead_id: Optional[int] = None
    created_at: datetime
    updated_at: datetime
    prospect_source: dict = Field(default_factory=dict)
    prospect_quality: dict = Field(default_factory=dict)
    sales_labels: list[dict] = Field(default_factory=list)

    @field_validator("industry")
    @classmethod
    def normalize_industry(cls, value: Optional[str]) -> Optional[str]:
        return normalize_merchant_industry(value)

    @model_validator(mode="before")
    @classmethod
    def imported_contact_timezone(cls, value):
        if isinstance(value, MerchantPool):
            evidence = address_timezone_evidence(value.raw_payload)
            if evidence:
                fields = {name: getattr(value, name) for name in cls.model_fields if hasattr(value, name)}
                fields.update(resolve_contact_timezone(**{key: fields[key] for key in ("country", "state", "city", "address")},
                                                      address_evidence=evidence))
                return fields
        return value

    @model_validator(mode="after")
    def computed_contact_timezone(self):
        if self.timezone_basis == "unknown":
            for key, value in resolve_contact_timezone(
                country=self.country, state=self.state, city=self.city, address=self.address,
            ).items():
                setattr(self, key, value)
        return self

    class Config:
        from_attributes = True


class MerchantIndustryFacet(BaseModel):
    value: str
    label: str
    count: int


class MerchantListResponse(BaseModel):
    items: list[MerchantResponse]
    total: int
    skip: int
    limit: int
    industry_facets: list[MerchantIndustryFacet] = Field(default_factory=list)
    facet_total: int = 0
    quality_facets: dict[str, int] = Field(default_factory=dict)


CSV_HEADERS = {
    "商家名称": "business_name", "商家": "business_name", "商户名称": "business_name", "企业名称": "business_name", "店铺名称": "business_name", "名称": "business_name", "business_name": "business_name", "business name": "business_name", "name": "business_name", "title": "business_name",
    "联系人": "contact_name", "联系人姓名": "contact_name", "负责人": "contact_name", "contact_name": "contact_name", "contact name": "contact_name", "contact": "contact_name",
    "电话": "phone", "电话/网站": "phone", "电话网站": "phone", "联系电话": "phone", "电话号码": "phone", "手机": "phone", "手机号": "phone", "phone": "phone", "phone_number": "phone", "phone number": "phone", "telephone": "phone", "tel": "phone",
    "行业": "industry", "地区/行业": "industry", "地区行业": "industry", "类别": "industry", "分类": "industry", "商家类别": "industry", "industry": "industry", "category": "industry", "primary category": "industry",
    "地区": "region", "location": "region", "region": "region",
    "国家": "country", "国家地区": "country", "country": "country", "州": "state", "省": "state", "州省": "state", "state": "state", "province": "state",
    "城市": "city", "city": "city", "地址": "address", "详细地址": "address", "营业地址": "address", "address": "address", "full address": "address",
    "网站": "website", "官网": "website", "官网链接": "website", "网站链接": "website", "website": "website", "url": "website", "web site": "website", "domain": "website",
    "评分": "rating", "公开评分": "rating", "谷歌评分": "rating", "星级": "rating", "rating": "rating", "来源记录id": "source_record_id", "来源id": "source_record_id", "source_record_id": "source_record_id", "place id": "source_record_id",
    "营业状态": "business_status", "商家状态": "business_status", "状态": "business_status", "business_status": "business_status", "business status": "business_status", "status": "business_status",
    "采集时间": "collected_at", "抓取时间": "collected_at", "更新时间": "collected_at", "collected_at": "collected_at", "collected at": "collected_at",
    "google商家链接": "google_business_url", "google地图链接": "google_business_url", "google maps url": "google_business_url", "google_business_url": "google_business_url",
    "google评分": "google_rating", "Google评分": "google_rating", "google rating": "google_rating", "google_rating": "google_rating", "google评论数": "google_review_count", "google评论数量": "google_review_count", "google review count": "google_review_count", "google_review_count": "google_review_count",
    "yelp链接": "yelp_url", "yelp url": "yelp_url", "yelp_url": "yelp_url", "yelp评分": "yelp_rating", "yelp rating": "yelp_rating", "yelp_rating": "yelp_rating",
    "yelp评论数": "yelp_review_count", "yelp评论数量": "yelp_review_count", "yelp review count": "yelp_review_count", "yelp_review_count": "yelp_review_count",
    "社交平台": "social_profiles", "社媒": "social_profiles", "social_profiles": "social_profiles", "social profiles": "social_profiles", "近期差评": "recent_negative_reviews", "差评摘要": "recent_negative_reviews", "recent_negative_reviews": "recent_negative_reviews",
    "内容更新情况": "content_update_summary", "内容更新": "content_update_summary", "content_update_summary": "content_update_summary", "内容最近更新时间": "content_last_updated_at", "content更新时间": "content_last_updated_at", "content_last_updated_at": "content_last_updated_at",
}


def _normalize_header(value: Any) -> str:
    """Make spreadsheet headers tolerant of spaces, punctuation, and casing."""
    return re.sub(r"[\s_/\-()（）:：]+", "", str(value or "").strip().casefold())


HEADER_LOOKUP = {_normalize_header(header): field for header, field in CSV_HEADERS.items()}

IMPORT_TEMPLATE_HEADERS = ("商家名称", "商家电话", "商家位置", "地区", "来源")
IMPORT_TEMPLATE_FIELDS = ("business_name", "phone", "address", "region", "data_source")
IMPORT_OPTIONAL_HEADERS = {"行业": "industry", "来源URL": "source_url", "来源日期": "source_date", "核验类型": "verification_type", "IANA时区": "source_timezone"}


def _validate_import_template_headers(headers: list[Any]) -> list[str]:
    normalized = [str(value or "").strip() for value in headers]
    while normalized and not normalized[-1]:
        normalized.pop()
    extra = normalized[len(IMPORT_TEMPLATE_HEADERS):]
    if normalized[:len(IMPORT_TEMPLATE_HEADERS)] != list(IMPORT_TEMPLATE_HEADERS) or len(extra) != len(set(extra)) or any(value not in IMPORT_OPTIONAL_HEADERS for value in extra):
        expected = "、".join(IMPORT_TEMPLATE_HEADERS)
        actual = "、".join(value or "空列" for value in normalized) or "未读取到表头"
        raise HTTPException(
            status_code=400,
            detail=f"导入模板不符合要求。第一行必须依次为：{expected}（前五列固定）；可追加行业、来源URL、来源日期、核验类型、IANA时区。当前为：{actual}。请下载模板后重新填写。",
        )
    return normalized


def _map_import_row(row: dict[Any, Any]) -> tuple[dict[str, Any], list[str]]:
    mapped: dict[str, Any] = {}
    unknown_headers: list[str] = []
    for key, value in row.items():
        original_key = str(key or "").strip()
        if not original_key:
            continue
        normalized_key = _normalize_header(original_key)
        field = HEADER_LOOKUP.get(normalized_key)
        if not field:
            unknown_headers.append(original_key)
            continue
        if value is not None and str(value).strip() != "":
            clean_value = str(value).strip() if not isinstance(value, datetime) else value
            # Some source sheets combine two visible columns into one header.
            # Route a URL to website and the other value to phone instead of
            # shifting the rest of the row into the wrong fields.
            if normalized_key in {"电话网站", "电话官网"}:
                text = str(clean_value)
                if re.search(r"(?:https?://|www\.|[\w.-]+\.(?:com|net|org|co|us)(?:/|$))", text, re.I):
                    mapped["website"] = clean_value
                else:
                    mapped["phone"] = clean_value
            elif normalized_key in {"googlerating", "google评分"}:
                mapped["rating"] = clean_value
                mapped["google_rating"] = clean_value
            else:
                mapped[field] = clean_value
    return mapped, unknown_headers


def _parse_import_values(mapped: dict[str, Any]) -> dict[str, Any]:
    if mapped.get("website"):
        website_text = str(mapped["website"]).strip()
        url_match = re.search(r"https?://[^\s\]\)]+", website_text, re.I)
        if url_match:
            mapped["website"] = url_match.group().rstrip(".,;:")

    if mapped.get("region"):
        parts = [part.strip() for part in re.split(r"[,，]", str(mapped.pop("region"))) if part.strip()]
        # Resolve only an explicit country. A trailing two-letter token can be
        # a state/province; never turn an international place into a US record.
        country = None
        if len(parts) >= 3 or (parts and len(parts[-1]) != 2) or (parts and parts[-1].upper() in {"US", "USA"}):
            country = normalize_phone_country(parts[-1]) if parts else None
        if country:
            mapped.setdefault("country", country)
            parts.pop()
        if mapped.get("country") and len(parts) >= 2:
            mapped.setdefault("state", parts.pop().upper())
        elif mapped.get("country") == "US" and len(parts) == 1:
            # Public leads may identify a state without a city. Preserve that
            # distinction so a missing city cannot become a fabricated one.
            state = STATE_CODES.get(parts[0].upper(), parts[0].upper())
            if state in STATE_NAMES:
                mapped.setdefault("state", state)
                parts.pop()
        if parts:
            mapped.setdefault("city", ", ".join(parts))

    for field in ("rating", "google_rating", "yelp_rating"):
        if mapped.get(field) not in (None, ""):
            # Source tables often use "★4.6" or "待核验". Keep the useful
            # number and leave an unverified rating blank instead of rejecting
            # the entire merchant row.
            rating_text = str(mapped[field]).replace(",", "").strip()
            match = re.search(r"[⭐★]\s*(\d+(?:\.\d+)?)", rating_text)
            if not match:
                match = re.match(r"\s*(\d+(?:\.\d+)?)", rating_text)
            mapped[field] = float(match.group(1)) if match else None
    for field in ("google_review_count", "yelp_review_count"):
        if mapped.get(field) not in (None, ""):
            match = re.search(r"\d+(?:\.\d+)?", str(mapped[field]).replace(",", ""))
            mapped[field] = int(float(match.group())) if match else None
    return mapped


def _decode_csv(content: bytes) -> str:
    for encoding in ("utf-8-sig", "utf-8", "gb18030"):
        try:
            return content.decode(encoding)
        except UnicodeDecodeError:
            continue
    raise HTTPException(status_code=400, detail="无法识别文件编码，请另存为 UTF-8 CSV 后重试")


async def _manager_scope(db: AsyncSession, user: UserResponse):
    if _role(user) in ADMIN_ROLES:
        return None
    # A supervisor only sees pool records they imported themselves.
    return MerchantPool.created_by_id == _employee_id(user)


async def _resolve_sales_assignee(
    db: AsyncSession, assigned_sales_id: Optional[int], user: UserResponse
) -> tuple[Optional[int], Optional[str], Optional[int]]:
    """Validate assignment once so bulk and single conversion follow identical rules."""
    manager_id = _employee_id(user) if _role(user) == "sales_manager" else None
    if assigned_sales_id is None:
        return None, None, manager_id
    employee = (await db.execute(
        select(Employees).where(
            Employees.id == assigned_sales_id,
            Employees.role == "sales",
            Employees.status.in_(["active", "probation"]),
        )
    )).scalar_one_or_none()
    if not employee:
        raise HTTPException(status_code=400, detail="只能分配给在职电话销售账号")
    if _role(user) == "sales_manager" and employee.supervisor != (user.name or ""):
        raise HTTPException(status_code=403, detail="只能分配给自己的直属销售")
    return int(employee.id), employee.name, manager_id


async def _create_sales_lead_from_merchant(
    db: AsyncSession,
    merchant: MerchantPool,
    user: UserResponse,
    assigned_sales_id: Optional[int],
    assigned_sales_name: Optional[str],
    team_manager_id: Optional[int],
) -> SalesLeads:
    await lock_sales_workflow(db)
    from services.sales_dossiers import next_sales_lead_id
    quality = await quality_for(db, "pool", merchant.id)
    if quality["status"] in {"invalid_phone", "not_target", "closed"}:
        raise HTTPException(status_code=409, detail="该记录已核验为号码无效、非目标或停业，不能分配；请先由有权限的人员重新核验")
    # Importing or assigning a fresh pool record must not bypass a previous
    # merchant request to stop contact, even if the old lead was deleted.
    await ensure_phone_contact_allowed(db, merchant.phone, merchant.country)
    lead = SalesLeads(
        id=await next_sales_lead_id(db),
        business_name=merchant.business_name,
        contact_name=merchant.contact_name,
        phone=merchant.phone or "",
        industry=normalize_merchant_industry(merchant.industry),
        country=merchant.country,
        state=merchant.state,
        city=merchant.city,
        address=merchant.address,
        website=merchant.website,
        source=f"merchant_pool:{merchant.data_source}",
        merchant_pool_id=merchant.id,
        assigned_sales_id=assigned_sales_id,
        assigned_sales_name=assigned_sales_name,
        team_manager_id=team_manager_id,
        created_by_id=_employee_id(user),
        created_by_name=user.name,
    )
    latest_analysis = (await db.execute(
        select(MerchantAiAnalyses)
        .where(MerchantAiAnalyses.merchant_id == merchant.id)
        .order_by(MerchantAiAnalyses.generated_at.desc())
        .limit(1)
    )).scalar_one_or_none()
    if latest_analysis:
        lead.analysis_snapshot = latest_analysis.analysis_json
    db.add(lead)
    await db.flush()
    evidence = address_timezone_evidence(merchant.raw_payload)
    if evidence:
        db.add(SalesLeadProfiles(lead_id=lead.id, revision=1, payload_json=json.dumps(
            {"prospect_source": {"address_timezone": evidence}}, ensure_ascii=False)))
    await inherit_pool_quality(db, merchant, lead, user)
    merchant.pool_status = "converted"
    merchant.converted_lead_id = lead.id
    merchant.isolation_reason = "已人工确认并转入独立电话销售线索库"
    return lead


async def _match_customer(db: AsyncSession, record: MerchantRecord) -> tuple[Optional[int], Optional[str]]:
    customers = (await db.execute(select(Customers))).scalars().all()
    phone = _normalize_phone(record.phone, record.country)
    name = _normalize_text(record.business_name)
    address = _normalize_text(record.address)
    website = _normalize_website(record.website)
    for customer in customers:
        if phone and phone == _normalize_phone(customer.phone, customer.country):
            return customer.id, "电话已存在于正式客户"
        if website and website == _normalize_website(customer.website):
            return customer.id, "网站已存在于正式客户"
        if has_concrete_name_and_address(record) and has_concrete_name_and_address(customer) and name == _normalize_text(customer.business_name) and address == _normalize_text(customer.address):
            return customer.id, "商家名称和地址已存在于正式客户"
    return None, None


async def _match_pool_duplicate(
    db: AsyncSession, record: MerchantRecord, exclude_id: Optional[int] = None
) -> tuple[Optional[int], Optional[str]]:
    # Historical rows still reserve the merchant identity. Otherwise an archived
    # or converted prospect can be imported again and pollute the sales pool.
    query = select(MerchantPool)
    if exclude_id is not None:
        query = query.where(MerchantPool.id != exclude_id)
    rows = (await db.execute(query)).scalars().all()
    available_ids = {row.id for row in rows}
    phone = _normalize_phone(record.phone, record.country)
    name = _normalize_text(record.business_name)
    address = _normalize_text(record.address)
    website = _normalize_website(record.website)
    for row in rows:
        duplicate_id = row.duplicate_of_id if row.duplicate_of_id in available_ids else row.id
        status_hint = {
            "converted": "（该商家已转入电话销售线索）",
            ARCHIVED_STATUS: "（该商家已有归档记录）",
        }.get(row.pool_status, "")
        if phone and phone == _normalize_phone(row.phone, row.country):
            return duplicate_id, f"电话与商家池历史记录重复{status_hint}"
        if website and website == _normalize_website(row.website):
            return duplicate_id, f"网站与商家池历史记录重复{status_hint}"
        if has_concrete_name_and_address(record) and has_concrete_name_and_address(row) and name == _normalize_text(row.business_name) and address == _normalize_text(row.address):
            return duplicate_id, f"商家名称和地址与商家池历史记录重复{status_hint}"
    return None, None


async def _classify_record(
    db: AsyncSession, record: MerchantRecord, exclude_id: Optional[int] = None
) -> tuple[str, Optional[str], Optional[int], Optional[int]]:
    customer_id, customer_reason = await _match_customer(db, record)
    if customer_id:
        return "existing_customer", customer_reason, None, customer_id
    duplicate_id, duplicate_reason = await _match_pool_duplicate(db, record, exclude_id)
    if duplicate_id:
        return "duplicate", duplicate_reason, duplicate_id, None
    phone = parse_phone_number(record.phone, record.country)
    if not phone.is_valid:
        return "no_phone", phone.reason or "电话需补齐后才能分配", None, None
    if _is_closed(record.business_status):
        return "closed", "商家状态为已关闭或停业", None, None
    return "pending", None, None, None


async def _classify_record_with_reference_lock(
    db: AsyncSession, record: MerchantRecord, exclude_id: Optional[int] = None
) -> tuple[str, Optional[str], Optional[int], Optional[int]]:
    # All classification writers serialize references with import undo. Do not
    # flush pending edits before their new reference has been rechecked.
    with db.no_autoflush:
        await lock_merchant_rows(db, [])
        classification = await _classify_record(db, record, exclude_id)
        duplicate_id = classification[2]
        if duplicate_id:
            references = await lock_merchant_rows(db, [duplicate_id])
            duplicate = references[0] if references else None
            classification = await _classify_record(db, record, exclude_id)
            current_reference = classification[2]
            if current_reference and (not duplicate or duplicate.id != current_reference):
                await db.rollback()
                raise HTTPException(status_code=409, detail="商家资料刚被其他操作更新，本次操作尚未写入，请重试")
    return classification


async def _store_record(
    db: AsyncSession,
    record: MerchantRecord,
    data_source: str,
    user: UserResponse,
    raw_record: Optional[dict[str, Any]] = None,
) -> MerchantPool:
    from services.merchant_imports import import_source_metadata
    from services.prospect_verification import initial_prospect_quality
    raw = dict(raw_record or record.model_dump(mode="json"))
    metadata_values = {field: raw.get(field) or raw.get(header) for header, field in IMPORT_OPTIONAL_HEADERS.items()}
    raw["prospect_source"] = import_source_metadata(metadata_values)
    evidence = import_address_timezone(metadata_values.get("source_timezone"), record, raw["prospect_source"].get("source_url"))
    if evidence:
        raw["prospect_source"]["address_timezone"] = evidence
    raw["prospect_quality"] = initial_prospect_quality()
    pool_status, reason, duplicate_id, customer_id = await _classify_record_with_reference_lock(db, record)
    collected_at = record.collected_at or datetime.now(timezone.utc)
    merchant = MerchantPool(
        **record.model_dump(exclude={"collected_at"}),
        data_source=data_source.strip() or "api",
        collected_at=collected_at,
        pool_status=pool_status,
        isolation_reason=reason,
        duplicate_of_id=duplicate_id,
        existing_customer_id=customer_id,
        raw_payload=json.dumps(raw, ensure_ascii=False, default=str),
        created_by_id=_employee_id(user),
        created_by_name=user.name,
    )
    db.add(merchant)
    await db.flush()
    return merchant


@router.get("/stats")
async def get_merchant_pool_stats(
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    _ensure_pool_role(current_user)
    query = select(MerchantPool.pool_status, func.count(MerchantPool.id)).group_by(MerchantPool.pool_status)
    scope = await _manager_scope(db, current_user)
    if scope is not None:
        query = query.where(scope)
    counts = {status: count for status, count in (await db.execute(query)).all()}
    return {
        "total": sum(count for status, count in counts.items() if status != ARCHIVED_STATUS),
        "pending": counts.get("pending", 0),
        "isolated": sum(counts.get(item, 0) for item in ISOLATED_STATUSES),
        "converted": counts.get("converted", 0),
        "duplicates": counts.get("duplicate", 0),
        "archived": counts.get(ARCHIVED_STATUS, 0),
    }


@router.get("", response_model=MerchantListResponse)
async def list_merchant_pool(
    search: Optional[str] = None,
    pool_status: Optional[str] = None,
    region: Optional[str] = None,
    timezone_group: Optional[Literal["eastern", "central", "mountain", "pacific", "alaska", "hawaii", "unknown"]] = None,
    industry: Optional[str] = None,
    source: Optional[str] = None,
    label_id: int | None = None,
    label_ids: str | None = None,
    provider_confirmed: bool | None = None,
    quality_status: Optional[Literal["pending", "valid", "invalid_phone", "not_target", "closed"]] = None,
    batch_id: Optional[str] = Query(None, min_length=1, max_length=36),
    rating_min: Optional[float] = Query(None, ge=0, le=5),
    skip: int = Query(0, ge=0),
    limit: int = Query(20, ge=1, le=200),
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    _ensure_pool_role(current_user)
    # The pool retains the original collection evidence. For converted records,
    # display/filter the current lead only when the caller can still read it.
    # A former manager's original import is not a grant to its latest dossier.
    from routers.sales_leads import _scope_condition
    lead_scope = await _scope_condition(db, current_user)
    join_on = SalesLeads.id == MerchantPool.converted_lead_id
    if lead_scope is not None:
        join_on = and_(join_on, lead_scope)
    current_fields = ("business_name", "contact_name", "phone", "industry", "country",
                      "state", "city", "address", "website")
    current = {field: case((SalesLeads.id.is_not(None), getattr(SalesLeads, field)),
                           else_=getattr(MerchantPool, field)) for field in current_fields}
    # Profile and address evidence are only evaluated for a visible current lead.
    # An original address correction invalidates the evidence for the former address.
    profile_join = SalesLeadProfiles.lead_id == SalesLeads.id
    address_fields = {key: current[key] for key in ("country", "state", "city", "address")}
    conditions = []
    scope = await _manager_scope(db, current_user)
    if scope is not None:
        conditions.append(scope)
    if batch_id:
        # Reuse the import receipt's authorization; membership is never inferred
        # from filenames or supplied by the client. This only narrows a read.
        from services.merchant_imports import get_batch
        batch = await get_batch(db, current_user, batch_id)
        if batch.status != "committed":
            raise HTTPException(409, "该导入批次尚未入池或已撤销")
        batch_ids = [row["merchant_id"] for row in json.loads(batch.result_json)
                     if isinstance(row, dict) and isinstance(row.get("merchant_id"), int)]
        conditions.append(MerchantPool.id.in_(batch_ids))
    if search:
        term = f"%{search.strip()}%"
        conditions.append(or_(*(current[field].ilike(term) for field in ("business_name", "phone", "website")),
                              MerchantPool.business_name.ilike(term), MerchantPool.phone.ilike(term),
                              MerchantPool.website.ilike(term)))
    if pool_status:
        conditions.append(MerchantPool.pool_status == pool_status)
    if region:
        region_values = [value.strip() for value in region.split(",") if value.strip()]
        if len(region_values) > 1:
            conditions.append(or_(*(
                func.upper(func.trim(current["state"])) == value.upper()
                for value in region_values
            )))
        elif region_values:
            term = f"%{region_values[0]}%"
            conditions.append(or_(current["country"].ilike(term), current["state"].ilike(term), current["city"].ilike(term)))
    if source:
        conditions.append(MerchantPool.data_source == source)
    can_read_labels = or_(MerchantPool.converted_lead_id.is_(None), SalesLeads.id.is_not(None))
    filters = {label_id} if label_id is not None else set()
    if label_ids:
        if not re.fullmatch(r"[0-9]{1,12}(,[0-9]{1,12}){0,19}", label_ids):
            raise HTTPException(422, "最多选择 20 个标签筛选")
        filters.update(map(int, label_ids.split(",")))
    if filters:
        conditions.append(can_read_labels)
        conditions.extend(sales_label_filter(item, merchant_id=MerchantPool.id, lead_id=SalesLeads.id,
                                             provider_confirmed=provider_confirmed) for item in sorted(filters))
    if rating_min is not None:
        conditions.append(MerchantPool.rating >= rating_min)
    if timezone_group:
        selected_zones = GROUP_ZONES.get(timezone_group) or frozenset().union(*GROUP_ZONES.values())
        matches = sql_matches_contact_zones(address_fields, selected_zones, source_payload=MerchantPool.raw_payload,
                                            profile_payload=SalesLeadProfiles.payload_json)
        conditions.append(~matches if timezone_group == "unknown" else matches)
    if not pool_status:
        conditions.append(MerchantPool.pool_status != ARCHIVED_STATUS)

    # One group-by computes both facets and the selected total. Applying the
    # industry and verification filters to these bins preserves both facets
    # without re-resolving every merchant's timezone for three separate counts.
    dialect = db.get_bind().dialect.name
    pool_quality = quality_status_expression("pool", MerchantPool.id, dialect)
    lead_quality = quality_status_expression("lead", SalesLeads.id, dialect, default=None)
    quality_expression = func.coalesce(lead_quality, pool_quality)
    grouped = (select(current["industry"], quality_expression, func.count(MerchantPool.id))
               .select_from(MerchantPool).outerjoin(SalesLeads, join_on))
    if timezone_group:
        grouped = grouped.outerjoin(SalesLeadProfiles, profile_join)
    bins = (await db.execute(grouped.where(*conditions).group_by(current["industry"], quality_expression))).all()
    facets = merchant_industry_facets([(value, count) for value, status, count in bins
                                      if not quality_status or status == quality_status])
    quality_facets = dict.fromkeys(("pending", "valid", "invalid_phone", "not_target", "closed"), 0)
    normalized = normalize_merchant_industry(industry)
    total = 0
    for value, status, count in bins:
        if industry and normalize_merchant_industry(value) != normalized:
            continue
        if status in quality_facets:
            quality_facets[status] += count
        if not quality_status or quality_status == status:
            total += count

    if industry:
        conditions.append(merchant_industry_filter(current["industry"], industry))
    if quality_status:
        conditions.append(quality_expression == quality_status)
    query = (select(MerchantPool, SalesLeads, SalesLeadProfiles.payload_json)
             .select_from(MerchantPool).outerjoin(SalesLeads, join_on).outerjoin(SalesLeadProfiles, profile_join)
             .where(*conditions).order_by(MerchantPool.id.desc()).offset(skip).limit(limit))
    rows = (await db.execute(query)).all()
    quality_by_id = await quality_for_many(db, "pool", [row[0].id for row in rows])
    visible_lead_quality = await quality_for_many(db, "lead", [lead.id for _, lead, *_ in rows if lead is not None])
    visible_merchants, visible_leads = await target_labels(
        db, [merchant.id for merchant, lead, _ in rows if merchant.converted_lead_id is None or lead is not None],
        [lead.id for _, lead, _ in rows if lead is not None])
    items = []
    for original, lead, profile_payload in rows:
        item = MerchantResponse.model_validate(original).model_dump()
        if lead is not None:
            item.update({field: getattr(lead, field) for field in current_fields})
            item["updated_at"] = lead.updated_at
            item["current_lead_id"] = lead.id
        item.update(resolve_contact_timezone(**{field: item[field] for field in address_fields},
                    profile_timezone=unpack(profile_payload).get("timezone"),
                    address_evidence=address_timezone_evidence(original.raw_payload)))
        item["prospect_source"] = source_metadata_from_raw(original.raw_payload, record=original)
        quality = visible_lead_quality.get(lead.id) if lead is not None else None
        item["prospect_quality"] = quality if quality and quality["revision"] else quality_by_id[original.id]
        item["sales_labels"] = visible_merchants.get(original.id, []) + (
            visible_leads.get(lead.id, []) if lead is not None else [])
        items.append(item)
    return {"items": items, "total": total, "skip": skip, "limit": limit,
            "industry_facets": facets, "facet_total": sum(facet["count"] for facet in facets),
            "quality_facets": quality_facets}


@router.post("/import")
async def import_merchant_records(
    payload: MerchantImportRequest,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    _ensure_pool_role(current_user)
    created = []
    errors = []
    counts: dict[str, int] = {"pending": 0, "no_phone": 0, "duplicate": 0, "existing_customer": 0, "closed": 0}
    for index, raw_record in enumerate(payload.records, start=1):
        try:
            mapped = dict(raw_record)
            if not mapped.get("industry") and payload.default_industry:
                mapped["industry"] = payload.default_industry
            record = MerchantRecord.model_validate(_parse_import_values(mapped))
            merchant = await _store_record(db, record, payload.data_source, current_user, raw_record=raw_record)
        except (ValidationError, TypeError, ValueError) as exc:
            if isinstance(exc, ValidationError):
                detail = exc.errors()[0]
                field = ".".join(str(part) for part in detail.get("loc", ()))
                reason = f"{field}：{detail.get('msg', '格式不正确')}"
            else:
                reason = str(exc)
            errors.append({"row": index, "reason": reason})
            continue
        created.append(merchant)
        counts[merchant.pool_status] = counts.get(merchant.pool_status, 0) + 1
    if not created:
        example = "；".join(f"第{item['row']}行 {item['reason']}" for item in errors[:3])
        raise HTTPException(status_code=400, detail=f"没有可导入的数据。{example or '请检查商家名称和数据格式'}")
    await db.commit()
    return {
        "total": len(created), "counts": counts, "errors": errors,
        "items": [MerchantResponse.model_validate(item).model_dump() for item in created],
    }


@router.post("/import-csv")
async def import_merchant_csv(
    file: UploadFile = File(...),
    data_source: str = Query("csv"),
    default_industry: Optional[str] = Query(None, max_length=100),
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    _ensure_pool_role(current_user)
    filename = (file.filename or "").lower()
    if not filename.endswith((".csv", ".xlsx")):
        raise HTTPException(status_code=400, detail="请上传 CSV 或 Excel（.xlsx）文件")
    content = await file.read()
    if filename.endswith(".xlsx"):
        try:
            workbook = load_workbook(io.BytesIO(content), read_only=True, data_only=True)
            worksheet = workbook.active
            rows = list(worksheet.iter_rows(values_only=True))
            if not rows:
                raise HTTPException(status_code=400, detail="Excel 文件没有可导入的数据")
            headers = list(rows[0])
            data_rows = [list(values) for values in rows[1:] if any(value not in (None, "") for value in values)]
        except HTTPException:
            raise
        except Exception as exc:
            raise HTTPException(status_code=400, detail=f"Excel 文件读取失败：{exc}")
    else:
        text = _decode_csv(content)
        try:
            dialect = csv.Sniffer().sniff(text[:4096], delimiters=",\t;|")
        except csv.Error:
            dialect = csv.excel
        rows = list(csv.reader(io.StringIO(text), dialect=dialect))
        if not rows:
            raise HTTPException(status_code=400, detail="CSV 文件没有可导入的数据")
        headers = rows[0]
        data_rows = [values for values in rows[1:] if any(str(value or "").strip() for value in values)]
    headers = _validate_import_template_headers(headers)
    fields = [*IMPORT_TEMPLATE_FIELDS, *(IMPORT_OPTIONAL_HEADERS[header] for header in headers[5:])]
    if len(data_rows) > 2000:
        raise HTTPException(status_code=400, detail="单次最多导入 2000 条商家记录")
    created = []
    errors = []
    counts: dict[str, int] = {"pending": 0, "no_phone": 0, "duplicate": 0, "existing_customer": 0, "closed": 0}
    for index, values in enumerate(data_rows, start=2):
        if len(values) != len(headers):
            errors.append({"row": index, "reason": f"必须正好填写 {len(headers)} 列"})
            continue
        row = dict(zip(headers, values))
        mapped = {
            field: str(value).strip()
            for field, value in zip(fields, values)
            if value is not None and str(value).strip()
        }
        row_source = str(mapped.pop("data_source", "")).strip() or data_source
        try:
            if len(row_source) > 50:
                raise ValueError("来源最多填写 50 个字符")
            if not mapped.get("industry") and default_industry:
                mapped["industry"] = default_industry
            record = MerchantRecord.model_validate(_parse_import_values(mapped))
            merchant = await _store_record(db, record, row_source, current_user, raw_record=row)
            created.append(merchant)
            counts[merchant.pool_status] = counts.get(merchant.pool_status, 0) + 1
        except HTTPException:
            # A reference-lock conflict rolls back the transaction. Do not
            # report earlier in-memory rows as successfully imported.
            raise
        except Exception as exc:
            errors.append({"row": index, "reason": str(exc)})
    if not created:
        await db.rollback()
        example = "；".join(f"第{item['row']}行 {item['reason']}" for item in errors[:3])
        raise HTTPException(status_code=400, detail=f"没有可导入的数据。{example or '请在模板中至少填写一条商家记录'}")
    await db.commit()
    return {
        "total": len(created), "counts": counts, "errors": errors,
        "template_headers": headers,
    }


@router.put("/{merchant_id}", response_model=MerchantResponse)
async def update_merchant_pool_record(
    merchant_id: int,
    payload: MerchantUpdate,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    _ensure_pool_role(current_user)
    await lock_merchant_rows(db, [])
    query = select(MerchantPool).where(MerchantPool.id == merchant_id)
    scope = await _manager_scope(db, current_user)
    if scope is not None:
        query = query.where(scope)
    merchant = (await db.execute(query)).scalar_one_or_none()
    if not merchant:
        raise HTTPException(status_code=404, detail="商家池记录不存在或不在权限范围内")
    if merchant.pool_status in {"converted", ARCHIVED_STATUS} or merchant.converted_lead_id:
        raise HTTPException(status_code=409, detail="已转线索或已归档的记录不能修改，请在对应记录中处理")
    updates = payload.model_dump(exclude_unset=True)
    for key, value in updates.items():
        setattr(merchant, key, value)
    record = MerchantRecord.model_validate({
        "business_name": merchant.business_name, "contact_name": merchant.contact_name, "phone": merchant.phone,
        "industry": merchant.industry, "country": merchant.country, "state": merchant.state, "city": merchant.city,
        "address": merchant.address, "website": merchant.website, "rating": merchant.rating,
        "google_business_url": merchant.google_business_url, "google_rating": merchant.google_rating,
        "google_review_count": merchant.google_review_count, "yelp_url": merchant.yelp_url,
        "yelp_rating": merchant.yelp_rating, "yelp_review_count": merchant.yelp_review_count,
        "social_profiles": merchant.social_profiles, "recent_negative_reviews": merchant.recent_negative_reviews,
        "content_update_summary": merchant.content_update_summary, "content_last_updated_at": merchant.content_last_updated_at,
        "source_record_id": merchant.source_record_id, "business_status": merchant.business_status,
        "collected_at": merchant.collected_at,
    })
    merchant.pool_status, merchant.isolation_reason, merchant.duplicate_of_id, merchant.existing_customer_id = await _classify_record_with_reference_lock(
        db, record, merchant.id
    )
    merchant.updated_at = datetime.now(timezone.utc)
    await db.commit()
    await db.refresh(merchant)
    return merchant


@router.post("/{merchant_id}/archive", response_model=MerchantResponse)
async def archive_merchant_pool_record(
    merchant_id: int,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    _ensure_admin_role(current_user)
    merchant = (await db.execute(select(MerchantPool).where(MerchantPool.id == merchant_id))).scalar_one_or_none()
    if not merchant:
        raise HTTPException(status_code=404, detail="商家池记录不存在")
    if merchant.pool_status == "converted" or merchant.converted_lead_id:
        raise HTTPException(status_code=409, detail="已转入电话销售线索的商家不能归档，请在线索库处理")
    if merchant.pool_status == ARCHIVED_STATUS:
        return merchant

    merchant.pool_status = ARCHIVED_STATUS
    merchant.isolation_reason = f"管理员归档：{current_user.name or current_user.email or '系统管理员'}"
    merchant.duplicate_of_id = None
    merchant.existing_customer_id = None
    merchant.updated_at = datetime.now(timezone.utc)
    await db.commit()
    await db.refresh(merchant)
    return merchant


@router.delete("/{merchant_id}")
async def delete_merchant_pool_record(
    merchant_id: int,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    _ensure_admin_role(current_user)
    await lock_merchant_rows(db, [merchant_id])
    merchant = (await db.execute(select(MerchantPool).where(MerchantPool.id == merchant_id))).scalar_one_or_none()
    if not merchant:
        raise HTTPException(status_code=404, detail="商家池记录不存在")
    if merchant.pool_status == "converted" or merchant.converted_lead_id:
        raise HTTPException(status_code=409, detail="已转入电话销售线索的商家不能永久删除")
    from services.prospect_verification import ensure_quality_history_retained
    await ensure_quality_history_retained(db, 'pool', [merchant_id])

    await db.delete(merchant)
    await db.commit()
    return {"message": "商家池记录已删除", "id": merchant_id}


@router.post("/{merchant_id}/convert-to-lead")
async def convert_to_sales_lead(
    merchant_id: int,
    payload: ConvertToLeadRequest,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    _ensure_pool_role(current_user)
    await lock_merchant_rows(db, [])
    query = select(MerchantPool).where(MerchantPool.id == merchant_id)
    scope = await _manager_scope(db, current_user)
    if scope is not None:
        query = query.where(scope)
    merchant = (await db.execute(query.with_for_update())).scalar_one_or_none()
    if not merchant:
        raise HTTPException(status_code=404, detail="商家池记录不存在或不在权限范围内")
    if merchant.pool_status != "pending":
        raise HTTPException(status_code=400, detail="只有通过清洗的待处理商家可以转入销售线索")

    assigned_id, assigned_name, manager_id = await _resolve_sales_assignee(
        db, payload.assigned_sales_id, current_user
    )
    lead = await _create_sales_lead_from_merchant(
        db, merchant, current_user, assigned_id, assigned_name, manager_id
    )
    await db.commit()
    return {"message": "已转入电话销售线索库", "lead_id": lead.id, "merchant_id": merchant.id}


@router.post("/bulk-convert-to-lead")
async def bulk_convert_to_sales_leads(
    payload: BulkConvertToLeadRequest,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Move a manager-approved batch into one salesperson's private lead library."""
    _ensure_pool_role(current_user)
    await lock_merchant_rows(db, [])
    merchant_ids = list(dict.fromkeys(payload.merchant_ids))
    assigned_id, assigned_name, manager_id = await _resolve_sales_assignee(
        db, payload.assigned_sales_id, current_user
    )
    query = select(MerchantPool).where(MerchantPool.id.in_(merchant_ids))
    scope = await _manager_scope(db, current_user)
    if scope is not None:
        query = query.where(scope)
    merchants = (await db.execute(query.with_for_update())).scalars().all()
    merchant_by_id = {merchant.id: merchant for merchant in merchants}

    missing_ids = [merchant_id for merchant_id in merchant_ids if merchant_id not in merchant_by_id]
    invalid = [merchant for merchant in merchants if merchant.pool_status != "pending"]
    if missing_ids:
        raise HTTPException(status_code=404, detail=f"有 {len(missing_ids)} 条商家记录不存在或不在您的权限范围内")
    if invalid:
        raise HTTPException(
            status_code=400,
            detail=f"有 {len(invalid)} 条记录不是待清洗可用状态，无法重复分配",
        )
    quality_by_id = await quality_for_many(db, "pool", merchant_ids)
    blocked_ids = [merchant_id for merchant_id in merchant_ids
                   if quality_by_id[merchant_id]["status"] in {"invalid_phone", "not_target", "closed"}]
    if blocked_ids:
        raise HTTPException(status_code=409, detail=f"有 {len(blocked_ids)} 条记录已核验为号码无效、非目标或停业，整批未分配；请先重新核验")

    leads = []
    for merchant_id in merchant_ids:
        leads.append(await _create_sales_lead_from_merchant(
            db, merchant_by_id[merchant_id], current_user, assigned_id, assigned_name, manager_id
        ))
    await db.commit()
    return {
        "message": f"已将 {len(leads)} 条可用商家分配给 {assigned_name}",
        "assigned_sales_id": assigned_id,
        "assigned_sales_name": assigned_name,
        "converted_count": len(leads),
        "lead_ids": [lead.id for lead in leads],
    }


@router.post("/bulk-update-industry")
async def bulk_update_merchant_industry(
    payload: BulkIndustryUpdateRequest,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Apply one reviewed industry label to selected non-final pool records."""
    _ensure_pool_role(current_user)
    merchant_ids = list(dict.fromkeys(payload.merchant_ids))
    await lock_merchant_rows(db, merchant_ids)
    query = select(MerchantPool).where(MerchantPool.id.in_(merchant_ids))
    scope = await _manager_scope(db, current_user)
    if scope is not None:
        query = query.where(scope)
    merchants = (await db.execute(query)).scalars().all()
    merchant_by_id = {merchant.id: merchant for merchant in merchants}
    missing_ids = [merchant_id for merchant_id in merchant_ids if merchant_id not in merchant_by_id]
    if missing_ids:
        raise HTTPException(status_code=404, detail=f"有 {len(missing_ids)} 条记录不存在或不在您的权限范围内")

    locked = [merchant for merchant in merchants if merchant.pool_status in {"converted", ARCHIVED_STATUS} or merchant.converted_lead_id]
    if locked:
        raise HTTPException(status_code=409, detail="已转线索或已归档的记录不能批量修改行业")

    updated_at = datetime.now(timezone.utc)
    industry = normalize_merchant_industry(payload.industry)
    changed = [merchant for merchant in merchants if merchant.industry != industry]
    for merchant in changed:
        merchant.industry = industry
        merchant.updated_at = updated_at
    await db.commit()
    return {"message": f"已更新 {len(changed)} 条商家的行业", "updated_count": len(changed),
            "selected_count": len(merchants), "industry": industry}


@router.post("/bulk-delete")
async def bulk_delete_merchant_pool_records(
    payload: BulkMerchantIdsRequest,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Permanently remove selected pool records without touching leads or customers."""
    _ensure_admin_role(current_user)
    merchant_ids = list(dict.fromkeys(payload.merchant_ids))
    await lock_merchant_rows(db, merchant_ids)
    merchants = (await db.execute(
        select(MerchantPool).where(MerchantPool.id.in_(merchant_ids))
    )).scalars().all()
    merchant_by_id = {merchant.id: merchant for merchant in merchants}
    missing_ids = [merchant_id for merchant_id in merchant_ids if merchant_id not in merchant_by_id]
    if missing_ids:
        raise HTTPException(status_code=404, detail=f"有 {len(missing_ids)} 条商家记录不存在")

    locked = [merchant for merchant in merchants if merchant.pool_status == "converted" or merchant.converted_lead_id]
    if locked:
        raise HTTPException(status_code=409, detail="已转入电话销售线索的记录不能批量永久删除")
    from services.prospect_verification import ensure_quality_history_retained
    await ensure_quality_history_retained(db, 'pool', merchant_ids)

    for merchant in merchants:
        await db.delete(merchant)
    await db.commit()
    return {"message": f"已删除 {len(merchants)} 条商家池记录", "deleted_count": len(merchants)}

import"./ui-vendor-D4acpTaA.js";

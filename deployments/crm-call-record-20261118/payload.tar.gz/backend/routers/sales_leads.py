import hashlib
import json
import re
from datetime import date, datetime, timedelta, timezone
from typing import List, Literal, Optional
from uuid import UUID, uuid4
from zoneinfo import ZoneInfo

from fastapi import APIRouter, Body, Depends, HTTPException, Query, Response, status
from pydantic import BaseModel, Field, field_validator
from sqlalchemy import func, or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db
from dependencies.auth import get_current_user
from models.employees import Employees
from models.ringcentral_call_records import RingCentralCallRecords
from models.sales_leads import SalesLeads
from models.sales_intelligence import SalesContactDetails
from schemas.sales_intelligence import ContactDetails
from schemas.sales_communication import CALL_OUTCOMES, NO_CONVERSATION_EVIDENCE, SalesCallSelection, activity_selections
from routers.app_config import SALES_QUICK_NOTE_CONFIG, read_config_value, sales_quick_note_result
from models.sales_call_activities import SalesCallActivities
from models.sales_call_ai_analyses import SalesCallAiAnalyses
from models.sales_daily_dial_tasks import SalesDailyDialTasks
from models.sales_daily_quotas import SalesDailyQuotas
from models.sales_lead_conversion_logs import SalesLeadConversionLogs
from models.sales_lead_assignment_logs import SalesLeadAssignmentLogs
from models.sales_deal_controls import SalesHandoffChecklists, SalesQuoteRequests
from models.customers import Customers
from models.customer_contacts import Customer_contacts
from models.deals import Deals
from models.service_progresses import Service_progresses
from models.subscriptions import Subscriptions
from models.management_decisions import BusinessLine, CustomerEngagement
from schemas.auth import UserResponse
from schemas.aihub import ChatMessage, GenTxtRequest
from services.ai_config import humanize_ai_error, resolve_ai_runtime_config
from services.aihub import AIHubService
from services.deal_payment_sync import sync_payment_from_deal
from services.sales_task_assignment import lead_has_active_closer, sync_pending_daily_tasks
from services.sales_closing_queue import (ClosingAction, ClosingStage, POSITIVE, available_closing_managers, closing_list,
    closing_dial_target, management_actor, previous_interest, record_manual_interest, retain_legacy_interest, update_closing)
from services.merchant_industries import workbench_industry_group
from services.sales_industry_queue import DEFERRED, industry_stock, prepare_industry_batch
from services.sales_queue_policy import queue_context, contact_queue_context, queue_sort_key
from services.prospect_verification import quality_for, quality_for_many
from services.ringcentral_team import team_connection_statuses
from services.sales_conversion_reporting import conversion_counts, currency_totals, first_receipts, sales_conversions
from services.sales_industry_reporting import industry_breakdown
from services.sales_workflow_locks import lock_sales_workflow
from services.sales_lead_markers import marker_conditions, markers_for, update_markers
from services.sales_labels import lead_labels, sales_label_filter
from services.customer_codes import allocate_customer_code
from services.phone_numbers import parse_phone_number, phone_match_key
from services.sales_contact_protection import (
    contact_protection_summaries, ensure_lead_contact_allowed, ensure_phone_contact_allowed,
    lead_is_blocked, persist_lead_suppression, release_phone_suppression,
)
from schemas.sales_enrichment import SalesEnrichmentUpdate, SalesDialStartedInput
from models.sales_lead_enrichments import SalesLeadEnrichmentAudit, SalesDialAttempt
from services.sales_enrichment import (apply_enrichment, get_enrichment, enrichment_catalog,
    ensure_enrichment_editable, saved_dial_phone, enrichment_summaries)
from services.sales_lead_cycle import (
    automation_overview as sales_automation_overview,
    ensure_daily_batch,
    queue_category,
    run_sales_lead_cycle,
)


router = APIRouter(prefix="/api/v1/sales-leads", tags=["sales-leads"])

ADMIN_ROLES = {"admin", "super_admin"}
LEAD_ROLES = ADMIN_ROLES | {"sales", "sales_manager"}
SALES_EDITABLE_FIELDS = {
    "status",
    "notes",
    "next_follow_up_at",
    "last_contact_at",
    "do_not_contact",
    "do_not_contact_reason",
}
DEFAULT_DAILY_TARGET = 100
MAX_DAILY_TARGET = 300
BUSINESS_TIMEZONE = ZoneInfo("Asia/Shanghai")


def _provider_connected(activity: SalesCallActivities) -> bool:
    """Prefer provider truth, while preserving legacy manual-only records."""
    if activity.sync_status == "verified":
        return bool(activity.ringcentral_connected)
    return activity.outcome not in NO_CONVERSATION_EVIDENCE


def _ringcentral_result_label(result: Optional[str], connected: bool) -> str:
    """Keep provider results readable without replacing the provider fact."""
    if connected:
        return "已接通"
    normalized = (result or "").strip().lower()
    if any(value in normalized for value in ("no answer", "missed", "unanswered")):
        return "无人接听"
    if "busy" in normalized:
        return "忙线"
    if any(value in normalized for value in ("declined", "rejected")):
        return "对方拒接"
    if any(value in normalized for value in ("failed", "not connected", "network")):
        return "拨打失败"
    if any(value in normalized for value in ("cancel", "abandon")):
        return "已取消"
    return result or "未接通"

# These are suggestions, not forced schedules. Sales can always select a more
# appropriate time before saving the call result.
FOLLOW_UP_RULES = {
    "recorded": (None, "已保存沟通备注"),
    "no_answer": (1, "未接通：建议下一个工作日回拨"),
    "callback": (1, "待回访：建议在约定时间前再次确认"),
    "interested": (1, "有意向：建议 24 小时内跟进需求或报价"),
    "appointment": (1, "已预约：建议在预约前确认时间与参会人"),
    "not_now": (60, "暂时不需要：冷却 60 天后进入跨销售轮换池"),
    "existing_provider": (90, "已有服务商：冷却 90 天后进入跨销售轮换池"),
    "not_interested": (None, "无意向：不再自动安排回访"),
    "do_not_contact": (None, "禁止再联系：已从后续拨打任务排除"),
}


def _parse_optional_datetime(value: Optional[str]) -> Optional[datetime]:
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
        return parsed if parsed.tzinfo else parsed.replace(tzinfo=BUSINESS_TIMEZONE)
    except ValueError:
        return None


def _quote_product_type(package_name: Optional[str], selected_platforms: Optional[str]) -> str:
    raw = f"{package_name or ''} {selected_platforms or ''}".lower()
    categories = set()
    if any(value in raw for value in ["点餐", "ordering"]): categories.add("ordering_system")
    if any(value in raw for value in ["广告", "投放", "ads"]): categories.add("ads")
    if any(value in raw for value in ["官网", "网站", "website"]): categories.add("website")
    if any(value in raw for value in ["google", "facebook", "instagram", "yelp", "tiktok", "小红书", "商家管理"]): categories.add("social_media")
    if len(categories) > 1: return "combo"
    return next(iter(categories), "social_media")


def _role(user: UserResponse) -> str:
    return str(user.role or "").strip().lower()


def _employee_id(user: UserResponse) -> int:
    try:
        return int(user.id)
    except (TypeError, ValueError):
        raise HTTPException(status_code=403, detail="当前账号未关联有效员工")


def _ensure_lead_role(user: UserResponse) -> None:
    if _role(user) not in LEAD_ROLES:
        raise HTTPException(status_code=403, detail="无权访问电话销售中心")


async def _validate_manual_call_result(db: AsyncSession, payload: "SalesCallResultCreate") -> None:
    notes = (payload.notes or "").strip()
    if payload.outcome == "callback" and not payload.next_follow_up_at:
        raise HTTPException(status_code=400, detail="待回访必须设置下次跟进时间")
    if payload.outcome in {"interested", "appointment"} and (not notes or not payload.next_follow_up_at):
        raise HTTPException(status_code=400, detail="有意向或已预约必须填写跟进内容和下次跟进时间")
    if payload.outcome == "do_not_contact" and not notes:
        raise HTTPException(status_code=400, detail="禁止再联系必须填写商家要求或原因")
    if payload.outcome == "recorded":
        if payload.next_follow_up_at is not None:
            raise HTTPException(400, "另约回访时间请选择待回访结果")
        config = await read_config_value(db, SALES_QUICK_NOTE_CONFIG)
        protected_templates = {entry["id"] for entry in sales_quick_note_result(config.value)["templates"]
                               if entry.get("remind_do_not_contact")}
        if any(note.id in protected_templates for note in payload.quick_notes):
            raise HTTPException(400, "所选备注涉及停止联系，请确认本次结果或选择禁止再联系")


class SalesLeadCreate(BaseModel):
    business_name: str = Field(min_length=1, max_length=200)
    contact_name: Optional[str] = None
    phone: str = Field(min_length=3, max_length=60)
    industry: Optional[str] = None
    country: Optional[str] = None
    state: Optional[str] = None
    city: Optional[str] = None
    address: Optional[str] = None
    website: Optional[str] = None
    source: Optional[str] = None
    status: str = "new"
    assigned_sales_id: Optional[int] = None
    notes: Optional[str] = None
    next_follow_up_at: Optional[datetime] = None

    @field_validator("next_follow_up_at")
    @classmethod
    def normalize_follow_up_timestamp(cls, value: Optional[datetime]) -> Optional[datetime]:
        if value is None:
            return None
        return value.replace(tzinfo=timezone.utc) if value.tzinfo is None else value.astimezone(timezone.utc)


    @field_validator("business_name", "phone")
    @classmethod
    def strip_required_text(cls, value: str) -> str:
        return value.strip()


class SalesLeadUpdate(BaseModel):
    business_name: Optional[str] = None
    contact_name: Optional[str] = None
    phone: Optional[str] = None
    industry: Optional[str] = None
    country: Optional[str] = None
    state: Optional[str] = None
    city: Optional[str] = None
    address: Optional[str] = None
    website: Optional[str] = None
    source: Optional[str] = None
    status: Optional[str] = None
    assigned_sales_id: Optional[int] = None
    is_blacklisted: Optional[bool] = None
    do_not_contact: Optional[bool] = None
    do_not_contact_reason: Optional[str] = None
    notes: Optional[str] = None
    next_follow_up_at: Optional[datetime] = None

    @field_validator("next_follow_up_at")
    @classmethod
    def normalize_follow_up_timestamp(cls, value: Optional[datetime]) -> Optional[datetime]:
        if value is None:
            return None
        return value.replace(tzinfo=timezone.utc) if value.tzinfo is None else value.astimezone(timezone.utc)

    last_contact_at: Optional[datetime] = None


class SalesLeadResponse(BaseModel):
    id: int
    business_name: str
    contact_name: Optional[str] = None
    phone: str
    industry: Optional[str] = None
    country: Optional[str] = None
    state: Optional[str] = None
    city: Optional[str] = None
    address: Optional[str] = None
    website: Optional[str] = None
    source: Optional[str] = None
    merchant_pool_id: Optional[int] = None
    analysis_snapshot: Optional[str] = None
    status: str
    assigned_sales_id: Optional[int] = None
    assigned_sales_name: Optional[str] = None
    team_manager_id: Optional[int] = None
    is_blacklisted: bool
    do_not_contact: bool
    do_not_contact_reason: Optional[str] = None
    converted_customer_id: Optional[int] = None
    converted_at: Optional[datetime] = None
    notes: Optional[str] = None
    next_follow_up_at: Optional[datetime] = None
    last_contact_at: Optional[datetime] = None
    assigned_at: Optional[datetime] = None
    automation_state: str = "eligible"
    cooldown_until: Optional[datetime] = None
    contact_attempt_count: int = 0
    rotation_count: int = 0
    last_assigned_sales_id: Optional[int] = None
    last_recycle_reason: Optional[str] = None
    last_automation_at: Optional[datetime] = None
    created_by_id: Optional[int] = None
    created_by_name: Optional[str] = None
    created_at: datetime
    updated_at: datetime
    starred: bool = False
    priority: bool = False
    labels: list[dict] = Field(default_factory=list)

    class Config:
        from_attributes = True


class SalesLeadListResponse(BaseModel):
    items: List[SalesLeadResponse]
    total: int
    skip: int
    limit: int


class SalesAssigneeResponse(BaseModel):
    id: int
    name: str
    role: str
    supervisor: Optional[str] = None


class SalesDailyQuotaUpdate(BaseModel):
    sales_employee_id: int
    target_count: int = Field(ge=1, le=MAX_DAILY_TARGET)
    target_date: Optional[date] = None


class SalesCallResultCreate(SalesCallSelection):
    dial_attempt_id: Optional[int] = Field(default=None, ge=1)
    submission_id: Optional[UUID] = None
    enrichment: Optional[SalesEnrichmentUpdate] = None
    contact_details: Optional[ContactDetails] = None
    notes: Optional[str] = Field(default=None, max_length=4000)
    next_follow_up_at: Optional[datetime] = None

    @field_validator("next_follow_up_at")
    @classmethod
    def normalize_follow_up_timestamp(cls, value: Optional[datetime]) -> Optional[datetime]:
        if value is None:
            return None
        return value.replace(tzinfo=timezone.utc) if value.tzinfo is None else value.astimezone(timezone.utc)


class SalesCallAiGenerateRequest(BaseModel):
    transcript: str = Field(min_length=10, max_length=30000)
    transcript_source: str = Field(default="manual_transcript", max_length=50)


class SalesCallAiReviewRequest(BaseModel):
    analysis: dict
    needs_manager_intervention: bool = False


class SalesLeadConvertRequest(BaseModel):
    confirmation_notes: str = Field(min_length=3, max_length=1000)
    generate_service_board: bool = False


class RecoveryReasonRequest(BaseModel):
    reason: str = Field(min_length=3, max_length=1000)

    @field_validator("reason")
    @classmethod
    def validate_reason(cls, value):
        if len(value.strip()) < 3:
            raise ValueError("请填写至少三个字的真实操作原因")
        return value.strip()


class RecoveryExtensionRequest(RecoveryReasonRequest):
    requested_days: int = Field(default=3, ge=1, le=14)


class RecoveryReassignRequest(RecoveryReasonRequest):
    assigned_sales_id: int
    expected_owner_id: Optional[int] = None
    confirm_protected_transfer: bool = False
    handoff_summary: str = Field(default="", max_length=2000)


class RecoveryBatchRequest(RecoveryReasonRequest):
    lead_ids: list[int] = Field(min_length=1, max_length=200)
    action: str = Field(pattern="^(reclaim|reassign)$")
    assigned_sales_id: Optional[int] = Field(default=None, ge=1)
    confirm_protected_transfer: bool = False
    handoff_summary: str = Field(default="", max_length=2000)


class ContactProtectionReleaseRequest(RecoveryReasonRequest):
    phone: str = Field(min_length=3, max_length=64)
    resume_lead: bool = False


def _parse_json_dict(raw: Optional[str]) -> dict:
    try:
        parsed = json.loads(raw or "{}")
        return parsed if isinstance(parsed, dict) else {}
    except (TypeError, json.JSONDecodeError):
        return {}


def _call_ai_fallback(transcript: str, notes: Optional[str]) -> dict:
    compact = " ".join(transcript.split())
    interest = "中"
    if any(word in compact for word in ["报价", "预约", "合作", "预算", "发我"]):
        interest = "高"
    elif any(word in compact for word in ["不需要", "不要", "拒绝", "不用"]):
        interest = "低"
    rejection = "未明确"
    for word in ["没预算", "已有团队", "不需要", "太贵", "没时间"]:
        if word in compact:
            rejection = word
            break
    return {
        "call_summary": compact[:500] or "信息不足：未提供可分析的通话转写。",
        "real_needs": "请销售根据原始转写补充客户真实需求；当前无法可靠判断。",
        "rejection_reason": rejection,
        "interest_level": interest,
        "next_contact_time": None,
        "next_conversation_advice": "围绕客户明确提到的问题进行回访，不要补充通话中未出现的承诺。",
        "recommended_material": "根据客户行业与真实需求，从已审核案例或报价单中人工选择。",
        "needs_manager_intervention": interest == "高" or rejection == "太贵",
        "source_notice": "此为保守模板，依据通话转写和销售备注生成；请人工复核。",
        "sales_notes": notes or "",
    }


def _extract_ai_json(raw: str) -> dict:
    start, end = raw.find("{"), raw.rfind("}")
    if start < 0 or end < start:
        return {}
    try:
        value = json.loads(raw[start:end + 1])
        return value if isinstance(value, dict) else {}
    except json.JSONDecodeError:
        return {}


async def _direct_report_ids(db: AsyncSession, user: UserResponse) -> list[int]:
    result = await db.execute(
        select(Employees.id).where(
            Employees.role == "sales",
            Employees.supervisor == (user.name or ""),
            Employees.status.in_(["active", "probation"]),
        )
    )
    return [int(value) for value in result.scalars().all()]


async def _scope_condition(db: AsyncSession, user: UserResponse):
    role = _role(user)
    if role in ADMIN_ROLES:
        return None

    current_id = _employee_id(user)
    if role == "sales":
        return SalesLeads.assigned_sales_id == current_id

    report_ids = await _direct_report_ids(db, user)
    visible_ids = list({current_id, *report_ids})
    return or_(
        SalesLeads.team_manager_id == current_id,
        SalesLeads.assigned_sales_id.in_(visible_ids),
    )


async def _get_scoped_lead(db: AsyncSession, lead_id: int, user: UserResponse) -> SalesLeads:
    query = select(SalesLeads).where(SalesLeads.id == lead_id)
    scope = await _scope_condition(db, user)
    if scope is not None:
        query = query.where(scope)
    lead = (await db.execute(query.execution_options(populate_existing=True))).scalar_one_or_none()
    if not lead:
        raise HTTPException(status_code=404, detail="线索不存在或不在您的权限范围内")
    return lead


async def _resolve_assignee(
    db: AsyncSession, assignee_id: Optional[int], user: UserResponse
) -> tuple[Optional[int], Optional[str], Optional[int]]:
    if assignee_id is None:
        return None, None, _employee_id(user) if _role(user) == "sales_manager" else None

    employee = (
        await db.execute(
            select(Employees).where(
                Employees.id == assignee_id,
                Employees.role == "sales",
                Employees.status.in_(["active", "probation"]),
            )
        )
    ).scalar_one_or_none()
    if not employee:
        raise HTTPException(status_code=400, detail="只能分配给在职电话销售")

    role = _role(user)
    if role == "sales_manager" and employee.supervisor != (user.name or ""):
        raise HTTPException(status_code=403, detail="只能分配给自己的直属销售")

    manager_id = _employee_id(user) if role == "sales_manager" else None
    return int(employee.id), employee.name, manager_id


async def _resolve_workbench_salesperson(
    db: AsyncSession, user: UserResponse, sales_employee_id: Optional[int]
) -> Employees:
    role = _role(user)
    current_id = _employee_id(user)
    target_id = sales_employee_id or (current_id if role == "sales" else None)
    if target_id is None:
        raise HTTPException(status_code=400, detail="请选择需要查看的电话销售")
    if role == "sales" and target_id != current_id:
        raise HTTPException(status_code=403, detail="销售只能查看自己的每日任务")
    employee = (await db.execute(select(Employees).where(Employees.id == target_id, Employees.role == "sales"))).scalar_one_or_none()
    if not employee:
        raise HTTPException(status_code=404, detail="电话销售账号不存在")
    if role == "sales_manager" and employee.supervisor != (user.name or ""):
        raise HTTPException(status_code=403, detail="只能查看直属销售的每日任务")
    return employee


async def _daily_quota(db: AsyncSession, sales_employee_id: int, target_date: date) -> int:
    quota = (await db.execute(
        select(SalesDailyQuotas).where(
            SalesDailyQuotas.sales_employee_id == sales_employee_id,
            SalesDailyQuotas.target_date == target_date,
        )
    )).scalar_one_or_none()
    return int(quota.target_count) if quota else DEFAULT_DAILY_TARGET


async def _ensure_daily_batch(
    db: AsyncSession, sales_employee_id: int, target_date: date, quota: int
) -> None:
    await ensure_daily_batch(db, sales_employee_id, target_date, quota)


def _lead_status_from_outcome(outcome: str) -> str:
    return {
        "no_answer": "contacted",
        "callback": "follow_up",
        "interested": "interested",
        "appointment": "appointment",
        "not_now": "contacted",
        "existing_provider": "contacted",
        "not_interested": "lost",
        "do_not_contact": "blocked",
    }[outcome]


def _suggest_follow_up(outcome: str, now: datetime) -> tuple[Optional[datetime], str]:
    days, label = FOLLOW_UP_RULES[outcome]
    return (now + timedelta(days=days) if days is not None else None), label


def _apply_automation_outcome(lead: SalesLeads, outcome: str, now: datetime, next_follow_up_at: Optional[datetime], *, preserve_interest=False) -> Optional[datetime]:
    """Apply deterministic retry/cooling rules while keeping every call activity immutable."""
    lead.last_contact_at = now
    lead.last_automation_at = now
    if outcome == "no_answer":
        attempts = int(lead.contact_attempt_count or 0) + 1
        lead.contact_attempt_count = attempts
        if attempts >= 3 and not preserve_interest:
            old_id = lead.assigned_sales_id
            lead.last_assigned_sales_id = old_id
            lead.assigned_sales_id = None
            lead.assigned_sales_name = None
            lead.assigned_at = None
            lead.rotation_count = int(lead.rotation_count or 0) + 1
            lead.cooldown_until = now + timedelta(days=30)
            lead.next_follow_up_at = lead.cooldown_until
            lead.automation_state = "cooling"
            lead.last_recycle_reason = "同一销售连续3次未接通，冷却30天后由其他销售轮换"
            return lead.cooldown_until
        retry_days = 2 if attempts == 1 else 7
        lead.next_follow_up_at = now + timedelta(days=retry_days)
        lead.automation_state = "protected" if preserve_interest else "assigned"
        lead.last_recycle_reason = f"第{attempts}次未接通，{retry_days}天后重试"
        return lead.next_follow_up_at
    if outcome in {"not_now", "existing_provider"}:
        days = 60 if outcome == "not_now" else 90
        lead.last_assigned_sales_id = lead.assigned_sales_id
        lead.assigned_sales_id = None
        lead.assigned_sales_name = None
        lead.assigned_at = None
        lead.rotation_count = int(lead.rotation_count or 0) + 1
        lead.contact_attempt_count = 0
        lead.cooldown_until = now + timedelta(days=days)
        lead.next_follow_up_at = lead.cooldown_until
        lead.automation_state = "cooling"
        lead.last_recycle_reason = f"{CALL_OUTCOMES[outcome]}，冷却{days}天后跨销售轮换"
        return lead.cooldown_until
    lead.contact_attempt_count = 0
    lead.cooldown_until = None
    lead.next_follow_up_at = next_follow_up_at
    if outcome in {"callback", "interested", "appointment"}:
        lead.automation_state = "protected"
    elif outcome in {"not_interested", "do_not_contact"}:
        lead.automation_state = "closed" if outcome == "not_interested" else "blocked"
    else:
        lead.automation_state = "assigned"
    return next_follow_up_at


async def _apply_contact_outcome(db, lead, outcome, now, next_follow_up_at, user):
    prior = lead.status
    if outcome == "recorded":
        lead.last_contact_at = now
        if prior == "new":
            lead.status = "contacted"
        return _as_utc(lead.next_follow_up_at)
    positive = prior if prior in POSITIVE else None
    if outcome == "no_answer" and not positive:
        positive = await previous_interest(db, lead.id)
    if prior in POSITIVE and outcome not in POSITIVE:
        await retain_legacy_interest(db, lead, user)
    missed_after_interest = outcome == "no_answer" and positive is not None
    lead.status = positive if missed_after_interest else _lead_status_from_outcome(outcome)
    return _apply_automation_outcome(lead, outcome, now, next_follow_up_at, preserve_interest=missed_after_interest)


def _workbench_priority(lead: SalesLeads, target_date: date) -> tuple[str, str]:
    follow_up_date = _business_date(lead.next_follow_up_at)
    if lead.status == "appointment":
        return "urgent", "优先确认预约时间"
    if lead.status == "interested":
        return "high", "优先跟进报价或需求"
    if lead.status == "follow_up" and follow_up_date and follow_up_date <= target_date:
        return "high", "今天应回访"
    if lead.status == "contacted":
        return "normal", "完成本次回拨"
    return "normal", "首次联系并记录结果"


PROTECTED_LEAD_STATUSES = {"follow_up", "interested", "appointment"}
RECOVERY_GRACE_HOURS = 48
OVERDUE_FOLLOW_UP_DAYS = 3


def _as_utc(value: Optional[datetime]) -> Optional[datetime]:
    if value is None:
        return None
    return value.replace(tzinfo=timezone.utc) if value.tzinfo is None else value.astimezone(timezone.utc)


def _recovery_state(
    lead: SalesLeads,
    now: datetime,
    latest_activity: Optional[SalesCallActivities],
    protection_until: Optional[datetime],
) -> tuple[str, str, Optional[datetime]]:
    """Return a transparent recovery state without silently changing ownership."""
    if lead.converted_customer_id or lead.status in {"won", "lost", "blocked"} or lead.do_not_contact or lead.is_blacklisted:
        return "excluded", "已成交、无意向或受保护线索不会进入回收流程", None
    if lead.automation_state == "closing_active":
        return "protected", "主管或老板已接手踢单", None
    if lead.status in PROTECTED_LEAD_STATUSES:
        return "protected", "已约定回访、有意向或已预约，需主管确认并填写原因后才可转交", None
    protection_until = _as_utc(protection_until)
    if protection_until and protection_until > now:
        return "extended", "销售延期已获主管批准，暂不回收", protection_until

    if latest_activity is None:
        assigned_at = _as_utc(lead.updated_at or lead.created_at)
        if assigned_at:
            deadline = assigned_at + timedelta(hours=RECOVERY_GRACE_HOURS)
            if deadline <= now:
                return "recoverable", "分配后 48 小时未开始处理，可由主管回收", deadline
            return "watch", "尚未拨打，达到 48 小时后将进入可回收名单", deadline
        return "watch", "尚未开始处理", None

    follow_up_at = _as_utc(lead.next_follow_up_at)
    if follow_up_at and follow_up_at + timedelta(days=OVERDUE_FOLLOW_UP_DAYS) <= now:
        return "recoverable", "已超过约定回访时间 3 天，可由主管回收", follow_up_at
    if follow_up_at:
        return "active", "已设置下次回访，归属受保护", follow_up_at
    return "active", "已有通话记录，归属受保护", None


async def _append_assignment_log(
    db: AsyncSession,
    lead: SalesLeads,
    action: str,
    user: UserResponse,
    *,
    from_employee_id: Optional[int] = None,
    from_employee_name: Optional[str] = None,
    to_employee_id: Optional[int] = None,
    to_employee_name: Optional[str] = None,
    reason: Optional[str] = None,
    effective_until: Optional[datetime] = None,
) -> SalesLeadAssignmentLogs:
    log = SalesLeadAssignmentLogs(
        lead_id=lead.id,
        action=action,
        from_sales_employee_id=from_employee_id,
        from_sales_employee_name=from_employee_name,
        to_sales_employee_id=to_employee_id,
        to_sales_employee_name=to_employee_name,
        reason=reason,
        effective_until=effective_until,
        operated_by_id=_employee_id(user),
        operated_by_name=user.name,
    )
    db.add(log)
    return log


async def _record_transfer_handoff(db, lead, user, old_id, old_name, note, reason):
    """Initial allocation needs no acknowledgement; a real prior relationship does."""
    if old_id is None:
        old_id = lead.last_assigned_sales_id
        if not old_id or not (await db.scalar(select(func.count(SalesCallActivities.id)).where(
                SalesCallActivities.lead_id == lead.id))):
            return
        previous = await db.get(Employees, old_id)
        old_name = previous.name if previous else None
    if old_id != lead.assigned_sales_id:
        from services.sales_dossiers import record_handoff
        await record_handoff(db, lead, user, from_sales_id=old_id, from_sales_name=old_name, note=note, reason=reason)


async def _load_recovery_snapshot(
    db: AsyncSession, user: UserResponse
) -> list[dict]:
    query = select(SalesLeads).where(SalesLeads.assigned_sales_id.is_not(None))
    scope = await _scope_condition(db, user)
    if scope is not None:
        query = query.where(scope)
    leads = (await db.execute(query.order_by(SalesLeads.updated_at.asc(), SalesLeads.id.asc()))).scalars().all()
    if not leads:
        return []

    lead_ids = [lead.id for lead in leads]
    activities = (await db.execute(
        select(SalesCallActivities)
        .where(SalesCallActivities.lead_id.in_(lead_ids))
        .order_by(SalesCallActivities.lead_id.asc(), SalesCallActivities.called_at.desc(), SalesCallActivities.id.desc())
    )).scalars().all()
    latest_activities: dict[int, SalesCallActivities] = {}
    for activity in activities:
        latest_activities.setdefault(activity.lead_id, activity)

    logs = (await db.execute(
        select(SalesLeadAssignmentLogs)
        .where(SalesLeadAssignmentLogs.lead_id.in_(lead_ids))
        .order_by(SalesLeadAssignmentLogs.lead_id.asc(), SalesLeadAssignmentLogs.created_at.desc(), SalesLeadAssignmentLogs.id.desc())
    )).scalars().all()
    extension_until: dict[int, datetime] = {}
    latest_extension_requests: dict[int, SalesLeadAssignmentLogs] = {}
    latest_extension_approvals: dict[int, SalesLeadAssignmentLogs] = {}
    for log in logs:
        if log.action == "extension_approved" and log.effective_until and log.lead_id not in extension_until:
            extension_until[log.lead_id] = log.effective_until
        if log.action == "extension_approved" and log.lead_id not in latest_extension_approvals:
            latest_extension_approvals[log.lead_id] = log
        if log.action == "extension_requested" and log.lead_id not in latest_extension_requests:
            latest_extension_requests[log.lead_id] = log

    now = datetime.now(timezone.utc)
    snapshot = []
    for lead in leads:
        state, message, deadline = _recovery_state(
            lead, now, latest_activities.get(lead.id), extension_until.get(lead.id)
        )
        request = latest_extension_requests.get(lead.id)
        approval = latest_extension_approvals.get(lead.id)
        if request and approval and request.created_at <= approval.created_at:
            request = None
        snapshot.append({
            "lead_id": lead.id,
            "business_name": lead.business_name,
            "assigned_sales_id": lead.assigned_sales_id,
            "assigned_sales_name": lead.assigned_sales_name,
            "status": lead.status,
            "state": state,
            "message": message,
            "deadline": deadline,
            "last_contact_at": lead.last_contact_at,
            "next_follow_up_at": lead.next_follow_up_at,
            "extension_request": None if not request else {
                "id": request.id,
                "reason": request.reason,
                "requested_until": request.effective_until,
                "requested_by": request.operated_by_name,
                "created_at": request.created_at,
            },
        })
    return snapshot


@router.get("/closing-queue")
async def get_closing_queue(
    stage: ClosingStage = "active",
    source_sales_id: Optional[int] = None, search: str = Query("", max_length=200),
    industry: Literal["", "餐厅", "美业"] = "", mine: bool = False,
    label_id: Optional[int] = Query(None, ge=1), provider_confirmed: bool = False,
    starred: bool = False, priority: bool = False,
    page: int = Query(1, ge=1), page_size: int = Query(20, ge=1, le=100),
    current_user: UserResponse = Depends(get_current_user), db: AsyncSession = Depends(get_db),
):
    actor = await management_actor(db, current_user)
    return await closing_list(db, await _scope_condition(db, actor),
                              stage, source_sales_id, search, page, page_size, industry=industry,
                              only_closer_id=actor.id if mine else None, label_id=label_id,
                              provider_confirmed=provider_confirmed, viewer_user_id=current_user.id,
                              starred=starred, priority=priority)


@router.get("/closing-queue/{lead_id}/dial-target")
async def get_closing_dial_target(
    lead_id: int, response: Response, revision: Optional[int] = Query(None, ge=0),
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    actor = await management_actor(db, current_user)
    response.headers["Cache-Control"] = "no-store"
    return await closing_dial_target(db, lead_id, actor, await _scope_condition(db, actor), revision)


@router.get("/closing-queue/{lead_id}/managers")
async def get_closing_managers(
    lead_id: int, current_user: UserResponse = Depends(get_current_user), db: AsyncSession = Depends(get_db),
):
    return await available_closing_managers(db, lead_id, current_user)


@router.post("/closing-queue/{lead_id}")
async def record_closing_action(
    lead_id: int, payload: ClosingAction,
    current_user: UserResponse = Depends(get_current_user), db: AsyncSession = Depends(get_db),
):
    return await update_closing(db, lead_id, current_user, _scope_condition, payload)


@router.get("/assignees", response_model=List[SalesAssigneeResponse])
async def list_sales_assignees(
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    _ensure_lead_role(current_user)
    role = _role(current_user)
    if role == "sales":
        return []

    query = select(Employees).where(
        Employees.role == "sales",
        Employees.status.in_(["active", "probation"]),
    )
    if role == "sales_manager":
        query = query.where(Employees.supervisor == (current_user.name or ""))
    result = await db.execute(query.order_by(Employees.name.asc()))
    return result.scalars().all()


@router.get("/stats")
async def get_sales_lead_stats(
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    _ensure_lead_role(current_user)
    query = select(
        func.count(SalesLeads.id),
        func.count(SalesLeads.id).filter(SalesLeads.assigned_sales_id.is_not(None)),
        func.count(SalesLeads.id).filter(SalesLeads.assigned_sales_id.is_(None)),
        func.count(SalesLeads.id).filter(SalesLeads.is_blacklisted.is_(True)),
        func.count(SalesLeads.id).filter(SalesLeads.do_not_contact.is_(True)),
    )
    scope = await _scope_condition(db, current_user)
    if scope is not None:
        query = query.where(scope)
    row = (await db.execute(query)).one()
    return {
        "total": row[0] or 0,
        "assigned": row[1] or 0,
        "unassigned": row[2] or 0,
        "blacklisted": row[3] or 0,
        "do_not_contact": row[4] or 0,
    }


@router.get("", response_model=SalesLeadListResponse)
async def list_sales_leads(
    search: Optional[str] = None,
    lead_status: Optional[str] = Query(None, alias="status"),
    contact_rule: Optional[str] = None,
    due_range: Optional[str] = Query(None, pattern="^(today|overdue)$"),
    starred: bool = False,
    priority: bool = False,
    label_id: Optional[int] = Query(None, ge=1),
    skip: int = Query(0, ge=0),
    limit: int = Query(20, ge=1, le=200),
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    _ensure_lead_role(current_user)
    query = select(SalesLeads)
    count_query = select(func.count(SalesLeads.id))
    conditions = marker_conditions(SalesLeads.id, current_user.id, starred=starred, priority=priority)
    if label_id is not None:
        conditions.append(sales_label_filter(label_id, merchant_id=SalesLeads.merchant_pool_id, lead_id=SalesLeads.id))
    scope = await _scope_condition(db, current_user)
    if scope is not None:
        conditions.append(scope)
    if due_range:
        day_start = datetime.now(BUSINESS_TIMEZONE).replace(hour=0, minute=0, second=0, microsecond=0)
        start_utc = day_start.astimezone(timezone.utc).replace(tzinfo=None)
        end_utc = (day_start + timedelta(days=1)).astimezone(timezone.utc).replace(tzinfo=None)
        conditions.extend([
            SalesLeads.do_not_contact.is_(False),
            SalesLeads.is_blacklisted.is_(False),
            SalesLeads.converted_customer_id.is_(None),
            SalesLeads.status.notin_(["lost", "blocked"]),
            SalesLeads.next_follow_up_at < (start_utc if due_range == "overdue" else end_utc),
        ])
        if due_range == "today":
            conditions.append(SalesLeads.next_follow_up_at >= start_utc)
    if search:
        term = f"%{search.strip()}%"
        phone_ids = []
        if re.fullmatch(r"[+0-9 ().-]+", search.strip()):
            digits = re.sub(r"\D", "", search)
            if digits:
                phones = select(SalesLeads.id, SalesLeads.phone, SalesLeads.country)
                if scope is not None:
                    phones = phones.where(scope)
                phone_ids = [lead_id for lead_id, raw, country in (await db.execute(phones)).all()
                    if digits in re.sub(r"\D", "", phone_match_key(raw, country) or "")]

        conditions.append(
            or_(
                SalesLeads.business_name.ilike(term),
                SalesLeads.contact_name.ilike(term),
                SalesLeads.phone.ilike(term),
                SalesLeads.id.in_(phone_ids),
                SalesLeads.city.ilike(term),
            )
        )
    if lead_status:
        conditions.append(SalesLeads.status == lead_status)
    if contact_rule == "blacklisted":
        conditions.append(SalesLeads.is_blacklisted.is_(True))
    elif contact_rule == "do_not_contact":
        conditions.append(SalesLeads.do_not_contact.is_(True))
    elif contact_rule == "contactable":
        conditions.extend([
            SalesLeads.is_blacklisted.is_(False),
            SalesLeads.do_not_contact.is_(False),
        ])
    if conditions:
        query = query.where(*conditions)
        count_query = count_query.where(*conditions)
    total = (await db.execute(count_query)).scalar() or 0
    items = (
        await db.execute(query.order_by(SalesLeads.id.desc()).offset(skip).limit(limit))
    ).scalars().all()
    markers = await markers_for(db, (lead.id for lead in items), current_user.id)
    labels = await lead_labels(db, [(lead.id, lead.merchant_pool_id) for lead in items])
    marked_items = [
        SalesLeadResponse.model_validate(lead).model_copy(update={**markers[lead.id], "labels": labels.get(lead.id, [])})
        for lead in items
    ]
    return {"items": marked_items, "total": total, "skip": skip, "limit": limit}


class SalesLeadMarkerUpdate(BaseModel):
    starred: bool | None = None
    priority: bool | None = None


@router.put("/{lead_id}/markers")
async def change_sales_lead_markers(
    lead_id: int,
    payload: SalesLeadMarkerUpdate,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    _ensure_lead_role(current_user)
    if payload.priority is not None and _role(current_user) not in ADMIN_ROLES | {"sales_manager"}:
        raise HTTPException(status_code=403, detail="只有老板或主管可以调整重点单")
    if payload.starred is None and payload.priority is None:
        raise HTTPException(status_code=422, detail="请选择要修改的标记")
    await lock_sales_workflow(db, lead_ids=[lead_id])
    await _get_scoped_lead(db, lead_id, current_user)
    markers = await update_markers(
        db, lead_id, current_user.id, starred=payload.starred, priority=payload.priority,
    )
    await db.commit()
    return markers


@router.post("/workbench/prepare")
async def prepare_daily_call_workbench(
    sales_employee_id: Optional[int] = None,
    target_date: Optional[date] = None,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Explicitly prepare work; reading the dashboard must not assign/reclaim leads."""
    _ensure_lead_role(current_user)
    target_date = target_date or datetime.now(BUSINESS_TIMEZONE).date()
    if target_date != datetime.now(BUSINESS_TIMEZONE).date():
        raise HTTPException(status_code=400, detail="只能生成今天的任务；历史日期只供查看")
    salesperson = await _resolve_workbench_salesperson(db, current_user, sales_employee_id)
    await lock_sales_workflow(db, employee_ids=[salesperson.id])
    quota = await _daily_quota(db, salesperson.id, target_date)
    result = await ensure_daily_batch(db, salesperson.id, target_date, quota)
    return {"message": f"今日任务已准备，新增 {result['created']} 条", **result}


class SalesIndustryPick(BaseModel):
    preserve_task_ids: list[int] = Field(default_factory=list, max_length=300)


@router.get("/workbench/industry-stock")
async def sales_industry_stock(
    industry: Literal["restaurant", "beauty"],
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    if _role(current_user) != "sales":
        raise HTTPException(403, "仅销售本人可以查看可领取名单")
    return await industry_stock(db, current_user, industry)


@router.post("/workbench/prepare-industry")
async def prepare_sales_industry(
    industry: Literal["restaurant", "beauty"],
    target_date: date,
    payload: Optional[SalesIndustryPick] = None,
    timezone_group: Optional[Literal["eastern", "central", "mountain", "pacific"]] = None,
    window_only: bool = False,
    batch_size: int = Query(default=10, ge=1, le=100),
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    if _role(current_user) != "sales":
        raise HTTPException(403, "仅销售本人可以领取行业名单")
    return await prepare_industry_batch(db, current_user, industry, target_date, _daily_quota,
                                        set(payload.preserve_task_ids) if payload else set(), group=timezone_group,
                                        window_only=window_only, batch_size=batch_size)


@router.post("/workbench/manual-task/{lead_id}")
async def start_assigned_lead_task(
    lead_id: int,
    target_date: date,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Open one owned lead for contact without assigning more leads or recording a call."""
    if _role(current_user) != "sales":
        raise HTTPException(403, "仅销售本人可开始联系名下商家")
    employee_id = _employee_id(current_user)
    await lock_sales_workflow(db, lead_ids=[lead_id], employee_ids=[employee_id])
    from services.sales_dossiers import active_actor
    await active_actor(db, current_user)
    today = datetime.now(BUSINESS_TIMEZONE).date()
    if target_date != today:
        raise HTTPException(409, "日期已变更，请切换至今天再开始联系")
    lead = await _get_scoped_lead(db, lead_id, current_user)
    await ensure_lead_contact_allowed(db, lead)
    ensure_enrichment_editable(lead)
    if lead.status in {"lost", "won", "blocked"}:
        raise HTTPException(409, "该商家已结束电话跟进")
    if await lead_has_active_closer(db, lead.id):
        raise HTTPException(409, "该商家已由主管或老板接手踢单")
    if (await quality_for(db, "lead", lead.id))["status"] in {"invalid_phone", "not_target", "closed"}:
        raise HTTPException(409, "该商家已标记为号码无效、非目标或停业")

    existing = (await db.scalars(select(SalesDailyDialTasks).where(
        SalesDailyDialTasks.lead_id == lead.id, SalesDailyDialTasks.task_date == today,
    ))).all()
    task = next((item for item in existing if item.sales_employee_id == employee_id), None)
    if task is not None and task.status == "cancelled":
        raise HTTPException(409, "今天的联系任务已取消，请核对交接或商家标记")
    if task is None or task.status == DEFERRED:
        if any(item.status in {"pending", "completed"} for item in existing):
            raise HTTPException(409, "这家商家今天已有其他销售的联系任务，请核对交接")
        if task is None:
            task = SalesDailyDialTasks(sales_employee_id=employee_id, lead_id=lead.id,
                                       task_date=today, status="pending", queue_category=queue_category(lead))
            db.add(task)
        else:
            task.status = "pending"
        await db.flush()
    receipt = {"task_id": task.id, "lead_id": lead.id, "sales_employee_id": employee_id,
               "task_date": today, "task_status": task.status}
    await db.commit()
    return receipt


@router.get("/workbench/today")
async def get_daily_call_workbench(
    sales_employee_id: Optional[int] = None,
    target_date: Optional[date] = None,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Read the existing daily batch without changing assignment or task records."""
    _ensure_lead_role(current_user)
    target_date = target_date or datetime.now(BUSINESS_TIMEZONE).date()
    salesperson = await _resolve_workbench_salesperson(db, current_user, sales_employee_id)
    quota = await _daily_quota(db, salesperson.id, target_date)
    tasks = (await db.execute(
        select(SalesDailyDialTasks, SalesLeads)
        .join(SalesLeads, SalesLeads.id == SalesDailyDialTasks.lead_id)
        .where(
            SalesDailyDialTasks.sales_employee_id == salesperson.id,
            SalesDailyDialTasks.task_date == target_date,
            SalesDailyDialTasks.status.in_(["pending", "completed"]),
            # A move can leave an old pending row. Only its current owner may
            # work it; completed calls retain the existing historical scope.
            or_(SalesDailyDialTasks.status == "completed", SalesLeads.assigned_sales_id == salesperson.id),
        )
        .order_by(SalesDailyDialTasks.status.asc(), SalesLeads.next_follow_up_at.is_(None), SalesLeads.next_follow_up_at.asc(), SalesDailyDialTasks.id.asc())
    )).all()
    # Enrichment is restricted to the current lead scope, even when historical
    # completed task rows remain in this employee's performance batch.
    visible_query = select(SalesLeads.id).where(SalesLeads.id.in_([lead.id for _, lead in tasks]))
    scope = await _scope_condition(db, current_user)
    if scope is not None:
        visible_query = visible_query.where(scope)
    visible_ids = set((await db.execute(visible_query)).scalars()) if tasks else set()
    tasks = [(task, lead) for task, lead in tasks if lead.id in visible_ids]
    summaries = await enrichment_summaries(db, [lead for _, lead in tasks if lead.id in visible_ids])
    qualities = await quality_for_many(db, 'lead', [lead.id for _, lead in tasks])
    profiles, contact_start, contact_end = await queue_context(db, [lead for _, lead in tasks], target_date)
    queue_now = datetime.now(timezone.utc)
    contexts = {lead.id: contact_queue_context(lead, now=queue_now, profile=profiles.get(lead.id),
        start=contact_start, end=contact_end) for _, lead in tasks}
    contact_protections = await contact_protection_summaries(db, [lead for _, lead in tasks])
    tasks.sort(key=lambda pair: queue_sort_key(pair[1], contexts[pair[1].id], completed=pair[0].status == "completed"))
    items = []
    categories = {"unfinished": 0, "callback": 0, "interested": 0, "appointment": 0, "new": 0, "retry": 0, "recycled": 0, "follow_up": 0}
    for task, lead in tasks:
        if task.status != "completed":
            categories["unfinished"] += 1
        if lead.status == "follow_up":
            categories["callback"] += 1
        elif lead.status == "interested":
            categories["interested"] += 1
        elif lead.status == "appointment":
            categories["appointment"] += 1
        queue_category = task.queue_category or "new"
        categories[queue_category] = categories.get(queue_category, 0) + 1
        priority, next_action_label = _workbench_priority(lead, target_date)
        items.append({
            "task_id": task.id,
            "task_status": task.status,
            "completed_at": task.completed_at,
            "priority": priority,
            "next_action_label": next_action_label,
            "queue_category": queue_category,
            "contact_queue": contexts[lead.id],
            "lead": {**SalesLeadResponse.model_validate(lead).model_dump(mode="json"),
                     "prospect_quality": qualities[lead.id],
                     "industry_group": workbench_industry_group(lead.industry),
                     "contact_protection": contact_protections[lead.id],
                     **({"enrichment_summary": summaries[lead.id]} if lead.id in summaries else {})},
        })
    completed = sum(1 for task, _lead in tasks if task.status == "completed")
    activities = (await db.execute(
        select(SalesCallActivities).where(SalesCallActivities.sales_employee_id == salesperson.id)
    )).scalars().all()
    day_activities = [item for item in activities if _business_date(item.called_at) == target_date]
    day_start = datetime.combine(target_date, datetime.min.time(), tzinfo=BUSINESS_TIMEZONE).astimezone(timezone.utc)
    # A deferred first call can be restored several times on the same day.
    # Count a salesperson's own claim once per merchant, from its audit event.
    self_claimed_count = await db.scalar(select(func.count(func.distinct(SalesLeadAssignmentLogs.lead_id))).where(
        SalesLeadAssignmentLogs.action == "industry_pick",
        SalesLeadAssignmentLogs.to_sales_employee_id == salesperson.id,
        SalesLeadAssignmentLogs.operated_by_id == salesperson.id,
        SalesLeadAssignmentLogs.created_at >= day_start,
        SalesLeadAssignmentLogs.created_at < day_start + timedelta(days=1),
    ))
    connected = sum(_provider_connected(item) for item in day_activities)
    interested = sum(item.outcome in {"interested", "appointment"} for item in day_activities)
    appointments = sum(item.outcome == "appointment" for item in day_activities)
    due_callbacks = sum(
        lead.status == "follow_up"
        and (_business_date(lead.next_follow_up_at) or target_date) <= target_date
        for _task, lead in tasks
    )
    return {
        "target_date": target_date,
        "queue_policy": {"label": "到期回访优先，再按当地联系时段和资料完整度排序",
            "evaluated_at": queue_now, "contact_start": contact_start, "contact_end": contact_end,
            "unknown_timezone": sum(context['timezone'] is None for context in contexts.values())},
        "salesperson": {"id": salesperson.id, "name": salesperson.name},
        "quota": quota,
        "assigned_count": len(items),
        "self_claimed_count": self_claimed_count,
        "completed_count": completed,
        "remaining_count": max(len(items) - completed, 0),
        "is_target_complete": completed >= quota or (len(items) > 0 and completed >= len(items)),
        "categories": categories,
        "performance": {
            "attempted": len(day_activities),
            "connected": connected,
            "interested": interested,
            "appointments": appointments,
            "callbacks_due": due_callbacks,
            "connection_rate": round(connected / max(len(day_activities), 1) * 100, 1),
        },
        "items": items,
    }


@router.get("/automation/overview")
async def get_sales_automation_overview(
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    _ensure_lead_role(current_user)
    if _role(current_user) not in ADMIN_ROLES | {"sales_manager"}:
        raise HTTPException(status_code=403, detail="只有主管或管理员可以查看公司线索资产")
    return await sales_automation_overview(db)


@router.post("/automation/run")
async def run_sales_automation_now(
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    _ensure_lead_role(current_user)
    if _role(current_user) not in ADMIN_ROLES | {"sales_manager"}:
        raise HTTPException(status_code=403, detail="只有主管或管理员可以执行线索自动扫描")
    await lock_sales_workflow(db)
    result = await run_sales_lead_cycle(db)
    return {"message": "线索自动循环扫描完成；历史记录、成交归属和分润归属均未改动", **result}


@router.get("/workbench/quota")
async def get_daily_call_quota(
    sales_employee_id: Optional[int] = None,
    target_date: Optional[date] = None,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    _ensure_lead_role(current_user)
    target_date = target_date or datetime.now(BUSINESS_TIMEZONE).date()
    salesperson = await _resolve_workbench_salesperson(db, current_user, sales_employee_id)
    return {"sales_employee_id": salesperson.id, "target_date": target_date, "target_count": await _daily_quota(db, salesperson.id, target_date)}


@router.put("/workbench/quota")
async def update_daily_call_quota(
    payload: SalesDailyQuotaUpdate,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    _ensure_lead_role(current_user)
    if _role(current_user) not in ADMIN_ROLES | {"sales_manager"}:
        raise HTTPException(status_code=403, detail="只有主管或管理员可以调整每日任务数量")
    target_date = payload.target_date or datetime.now(BUSINESS_TIMEZONE).date()
    salesperson = await _resolve_workbench_salesperson(db, current_user, payload.sales_employee_id)
    quota = (await db.execute(
        select(SalesDailyQuotas).where(
            SalesDailyQuotas.sales_employee_id == salesperson.id,
            SalesDailyQuotas.target_date == target_date,
        )
    )).scalar_one_or_none()
    if quota is None:
        quota = SalesDailyQuotas(sales_employee_id=salesperson.id, target_date=target_date)
        db.add(quota)
    quota.target_count = payload.target_count
    quota.updated_by_id = _employee_id(current_user)
    quota.updated_by_name = current_user.name
    await db.commit()
    return {"sales_employee_id": salesperson.id, "target_date": target_date, "target_count": quota.target_count}


@router.get("/workbench/tasks/{task_id}/analysis")
async def get_daily_task_analysis(
    task_id: int,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    _ensure_lead_role(current_user)
    task, lead = (await db.execute(
        select(SalesDailyDialTasks, SalesLeads)
        .join(SalesLeads, SalesLeads.id == SalesDailyDialTasks.lead_id)
        .where(SalesDailyDialTasks.id == task_id)
    )).one_or_none() or (None, None)
    if not task or not lead:
        raise HTTPException(status_code=404, detail="每日任务不存在")
    await _resolve_workbench_salesperson(db, current_user, task.sales_employee_id)
    if not lead.analysis_snapshot:
        return {"available": False, "message": "信息不足：该线索尚未附带经主管确认的商家分析资料。"}
    try:
        return {"available": True, "analysis": json.loads(lead.analysis_snapshot)}
    except json.JSONDecodeError:
        return {"available": False, "message": "商家分析资料格式异常，请由主管重新生成后转入线索库。"}


@router.get("/recovery/overview")
async def get_lead_recovery_overview(
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    _ensure_lead_role(current_user)
    if _role(current_user) == "sales":
        raise HTTPException(status_code=403, detail="销售只能查看自己的回收提醒")
    items = await _load_recovery_snapshot(db, current_user)
    return {
        "items": items,
        "summary": {
            "recoverable": sum(item["state"] == "recoverable" for item in items),
            "watch": sum(item["state"] == "watch" for item in items),
            "protected": sum(item["state"] == "protected" for item in items),
            "extended": sum(item["state"] == "extended" for item in items),
            "extension_requests": sum(item["extension_request"] is not None for item in items),
        },
    }


@router.get("/recovery/my-alerts")
async def get_my_recovery_alerts(
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    _ensure_lead_role(current_user)
    if _role(current_user) != "sales":
        raise HTTPException(status_code=403, detail="该提醒仅面向电话销售账号")
    items = await _load_recovery_snapshot(db, current_user)
    return {"items": [item for item in items if item["state"] in {"watch", "recoverable"}]}


@router.post("/recovery/batch")
async def batch_update_lead_recovery(
    payload: RecoveryBatchRequest,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    _ensure_lead_role(current_user)
    if _role(current_user) not in ADMIN_ROLES | {"sales_manager"}:
        raise HTTPException(status_code=403, detail="只有销售主管或系统管理员可以批量处理线索归属")
    lead_ids = list(dict.fromkeys(payload.lead_ids))
    await lock_sales_workflow(db, lead_ids=lead_ids,
        employee_ids=[payload.assigned_sales_id] if payload.assigned_sales_id else [])
    leads = [await _get_scoped_lead(db, lead_id, current_user) for lead_id in lead_ids]
    snapshot = {item["lead_id"]: item for item in await _load_recovery_snapshot(db, current_user)}
    target = None
    if payload.action == "reassign":
        if not payload.assigned_sales_id:
            raise HTTPException(status_code=400, detail="批量重新分配必须选择目标销售")
        target = (await db.execute(select(Employees).where(
            Employees.id == payload.assigned_sales_id,
            Employees.role == "sales",
            Employees.status.in_(["active", "probation"]),
        ))).scalar_one_or_none()
        if not target:
            raise HTTPException(status_code=400, detail="只能重新分配给在职电话销售")
        if _role(current_user) == "sales_manager" and target.supervisor != (current_user.name or ""):
            raise HTTPException(status_code=403, detail="只能重新分配给直属销售")

    invalid = []
    for lead in leads:
        item = snapshot.get(lead.id)
        state = item["state"] if item else "unassigned"
        if lead.converted_customer_id or lead.status in {"won", "lost", "blocked"} or lead_is_blocked(lead):
            invalid.append(f"{lead.business_name}（已结束或禁止联系）")
        if payload.action == "reassign" and target and target.id == lead.assigned_sales_id:
            invalid.append(f"{lead.business_name}（目标已是主要负责人）")
        if payload.action == "reclaim" and state != "recoverable":
            invalid.append(f"{lead.business_name}（{state}）")
        if payload.action == "reassign" and (state in {"protected", "extended", "active"}
                or lead.status in PROTECTED_LEAD_STATUSES) and not payload.confirm_protected_transfer:
            invalid.append(f"{lead.business_name}（受保护）")
    if invalid:
        raise HTTPException(status_code=400, detail=f"以下线索不符合本次批量操作：{'、'.join(invalid[:8])}")

    for lead in leads:
        old_id, old_name = lead.assigned_sales_id, lead.assigned_sales_name
        if payload.action == "reclaim":
            lead.assigned_sales_id = None
            lead.assigned_sales_name = None
            lead.assigned_at = None
            lead.automation_state = "eligible"
            lead.last_assigned_sales_id = old_id
            await _append_assignment_log(
                db, lead, "reclaimed", current_user,
                from_employee_id=old_id, from_employee_name=old_name, reason=payload.reason.strip(),
            )
        else:
            lead.assigned_sales_id = target.id
            lead.assigned_sales_name = target.name
            lead.assigned_at = datetime.now(timezone.utc)
            lead.automation_state = "protected" if lead.status in PROTECTED_LEAD_STATUSES else "assigned"
            if _role(current_user) == "sales_manager":
                lead.team_manager_id = _employee_id(current_user)
            await _append_assignment_log(
                db, lead, "reassigned", current_user,
                from_employee_id=old_id, from_employee_name=old_name,
                to_employee_id=target.id, to_employee_name=target.name, reason=payload.reason.strip(),
            )
        await sync_pending_daily_tasks(db, lead, lead.assigned_sales_id)
        if payload.action == "reassign":
            await _record_transfer_handoff(db, lead, current_user, old_id, old_name,
                payload.handoff_summary.strip() or payload.reason.strip(), payload.reason.strip())
    await db.commit()
    verb = "回收至待分配" if payload.action == "reclaim" else f"重新分配给 {target.name}"
    return {"message": f"已将 {len(leads)} 条线索{verb}", "updated": len(leads)}


@router.post("/{lead_id}/recovery/request-extension")
async def request_lead_recovery_extension(
    lead_id: int,
    payload: RecoveryExtensionRequest,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    _ensure_lead_role(current_user)
    if _role(current_user) != "sales":
        raise HTTPException(status_code=403, detail="只有当前销售可以申请延期")
    lead = await _get_scoped_lead(db, lead_id, current_user)
    if lead.assigned_sales_id != _employee_id(current_user):
        raise HTTPException(status_code=403, detail="只能为本人负责的线索申请延期")
    snapshot = {item["lead_id"]: item for item in await _load_recovery_snapshot(db, current_user)}.get(lead.id)
    if not snapshot or snapshot["state"] not in {"watch", "recoverable"}:
        raise HTTPException(status_code=400, detail="该线索当前不需要申请回收延期")
    requested_until = datetime.now(timezone.utc) + timedelta(days=payload.requested_days)
    await _append_assignment_log(
        db, lead, "extension_requested", current_user,
        from_employee_id=lead.assigned_sales_id, from_employee_name=lead.assigned_sales_name,
        to_employee_id=lead.assigned_sales_id, to_employee_name=lead.assigned_sales_name,
        reason=payload.reason.strip(), effective_until=requested_until,
    )
    await db.commit()
    return {"message": "延期申请已提交，主管确认前线索不会被自动转交", "requested_until": requested_until}


@router.post("/{lead_id}/recovery/approve-extension")
async def approve_lead_recovery_extension(
    lead_id: int,
    payload: RecoveryReasonRequest,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    _ensure_lead_role(current_user)
    if _role(current_user) not in ADMIN_ROLES | {"sales_manager"}:
        raise HTTPException(status_code=403, detail="只有销售主管或系统管理员可以批准延期")
    lead = await _get_scoped_lead(db, lead_id, current_user)
    request = (await db.execute(
        select(SalesLeadAssignmentLogs)
        .where(
            SalesLeadAssignmentLogs.lead_id == lead.id,
            SalesLeadAssignmentLogs.action == "extension_requested",
        )
        .order_by(SalesLeadAssignmentLogs.created_at.desc(), SalesLeadAssignmentLogs.id.desc())
    )).scalars().first()
    if not request or not request.effective_until:
        raise HTTPException(status_code=400, detail="未找到待批准的延期申请")
    await _append_assignment_log(
        db, lead, "extension_approved", current_user,
        from_employee_id=lead.assigned_sales_id, from_employee_name=lead.assigned_sales_name,
        to_employee_id=lead.assigned_sales_id, to_employee_name=lead.assigned_sales_name,
        reason=payload.reason.strip(), effective_until=request.effective_until,
    )
    await db.commit()
    return {"message": "已批准延期，保护期内不会进入回收名单", "effective_until": request.effective_until}


@router.post("/{lead_id}/recovery/reclaim")
async def reclaim_sales_lead(
    lead_id: int,
    payload: RecoveryReasonRequest,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    _ensure_lead_role(current_user)
    if _role(current_user) not in ADMIN_ROLES | {"sales_manager"}:
        raise HTTPException(status_code=403, detail="只有销售主管或系统管理员可以回收线索")
    await lock_sales_workflow(db, lead_ids=[lead_id])
    lead = await _get_scoped_lead(db, lead_id, current_user)
    snapshot = {item["lead_id"]: item for item in await _load_recovery_snapshot(db, current_user)}.get(lead.id)
    if not snapshot or snapshot["state"] != "recoverable":
        raise HTTPException(status_code=400, detail="该线索当前不符合自动回收条件；有意向或已预约线索请使用转交并填写原因")
    old_id, old_name = lead.assigned_sales_id, lead.assigned_sales_name
    lead.assigned_sales_id = None
    lead.assigned_sales_name = None
    lead.assigned_at = None
    lead.automation_state = "eligible"
    lead.last_assigned_sales_id = old_id
    await _append_assignment_log(
        db, lead, "reclaimed", current_user,
        from_employee_id=old_id, from_employee_name=old_name,
        reason=payload.reason.strip(),
    )
    await sync_pending_daily_tasks(db, lead, None)
    await db.commit()
    return {"message": "线索已回收至主管待分配队列", "lead_id": lead.id}


@router.post("/{lead_id}/recovery/reassign")
async def reassign_sales_lead(
    lead_id: int,
    payload: RecoveryReassignRequest,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    _ensure_lead_role(current_user)
    if _role(current_user) not in ADMIN_ROLES | {"sales_manager"}:
        raise HTTPException(status_code=403, detail="只有销售主管或系统管理员可以转交线索")
    await lock_sales_workflow(db, lead_ids=[lead_id], employee_ids=[payload.assigned_sales_id])
    lead = await _get_scoped_lead(db, lead_id, current_user)
    if "expected_owner_id" in payload.model_fields_set and payload.expected_owner_id != lead.assigned_sales_id:
        raise HTTPException(status_code=409, detail="主要负责人已更新，本次没有覆盖；请刷新档案后再转交")
    snapshot = {item["lead_id"]: item for item in await _load_recovery_snapshot(db, current_user)}.get(lead.id)
    if lead.converted_customer_id or lead.status in {"won", "lost", "blocked"} or lead_is_blocked(lead):
        raise HTTPException(status_code=409, detail="已结束或禁止联系的商家不能转交至拨打队列")
    if ((snapshot and snapshot["state"] in {"protected", "extended", "active"})
            or lead.status in PROTECTED_LEAD_STATUSES) and not payload.confirm_protected_transfer:
        raise HTTPException(status_code=400, detail="已有跟进约定的线索受保护，请确认并填写转交原因后再执行")
    target = (await db.execute(
        select(Employees).where(
            Employees.id == payload.assigned_sales_id,
            Employees.role == "sales",
            Employees.status.in_(["active", "probation"]),
        )
    )).scalar_one_or_none()
    if not target:
        raise HTTPException(status_code=400, detail="只能转交给在职电话销售")
    if _role(current_user) == "sales_manager" and target.supervisor != (current_user.name or ""):
        raise HTTPException(status_code=403, detail="只能转交给直属销售")
    if lead.assigned_sales_id == target.id:
        raise HTTPException(status_code=409, detail="该销售已经是主要负责人；无需重复转交")
    old_id, old_name = lead.assigned_sales_id, lead.assigned_sales_name
    lead.assigned_sales_id = target.id
    lead.assigned_sales_name = target.name
    lead.assigned_at = datetime.now(timezone.utc)
    lead.automation_state = "protected" if lead.status in PROTECTED_LEAD_STATUSES else "assigned"
    if _role(current_user) == "sales_manager":
        lead.team_manager_id = _employee_id(current_user)
    await _append_assignment_log(
        db, lead, "reassigned", current_user,
        from_employee_id=old_id, from_employee_name=old_name,
        to_employee_id=target.id, to_employee_name=target.name,
        reason=payload.reason.strip(),
    )
    await sync_pending_daily_tasks(db, lead, target.id)
    await _record_transfer_handoff(db, lead, current_user, old_id, old_name,
        payload.handoff_summary.strip() or payload.reason.strip(), payload.reason.strip())
    await db.commit()
    return {"message": "线索已转交，原负责人及原因已保留在操作日志中", "lead_id": lead.id, "assigned_sales_name": target.name}


@router.get("/{lead_id}/call-history")
async def get_sales_call_history(
    lead_id: int,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    _ensure_lead_role(current_user)
    await _get_scoped_lead(db, lead_id, current_user)
    rows = (await db.execute(
        select(SalesCallActivities)
        .where(SalesCallActivities.lead_id == lead_id)
        .order_by(SalesCallActivities.called_at.desc(), SalesCallActivities.id.desc())
    )).scalars().all()
    return [{
        "id": row.id, "outcome": row.outcome, "outcome_label": CALL_OUTCOMES.get(row.outcome, row.outcome),
        **activity_selections(row),
        "notes": row.notes, "next_follow_up_at": row.next_follow_up_at, "called_at": row.called_at,
        "sales_employee_id": row.sales_employee_id, "sales_employee_name": row.sales_employee_name,
        "call_duration_seconds": row.call_duration_seconds, "sync_status": row.sync_status,
        "ringcentral_connected": row.ringcentral_connected,
        "ringcentral_call_id": row.ringcentral_call_id, "dial_phone": row.dial_phone, "dial_attempt_id": row.dial_attempt_id,
    } for row in rows]


async def _get_scoped_activity(db: AsyncSession, activity_id: int, user: UserResponse) -> SalesCallActivities:
    activity = (await db.execute(select(SalesCallActivities).where(SalesCallActivities.id == activity_id))).scalar_one_or_none()
    if not activity:
        raise HTTPException(status_code=404, detail="通话记录不存在")
    await _get_scoped_lead(db, activity.lead_id, user)
    return activity


@router.post("/call-activities/{activity_id}/ai-analysis")
async def generate_call_ai_analysis(
    activity_id: int,
    payload: SalesCallAiGenerateRequest,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Generate a reviewable post-call analysis from an ASR transcript or a verified manual transcript."""
    _ensure_lead_role(current_user)
    activity = await _get_scoped_activity(db, activity_id, current_user)
    lead = await _get_scoped_lead(db, activity.lead_id, current_user)
    transcript = payload.transcript.strip()
    analysis = _call_ai_fallback(transcript, activity.notes)
    provider = None
    model = None
    try:
        runtime = await resolve_ai_runtime_config(db)
        if runtime.enabled:
            prompt = f"""
你是电话销售质检助手。只能根据给出的通话转写和销售备注填写 JSON，禁止猜测。
返回字段：call_summary、real_needs、rejection_reason、interest_level（高/中/低/未知）、next_contact_time（ISO 时间或 null）、next_conversation_advice、recommended_material、needs_manager_intervention（布尔）、source_notice。
商家：{lead.business_name}。销售备注：{activity.notes or '无'}。
通话转写：{transcript}
"""
            result = await AIHubService(api_key=runtime.api_key, base_url=runtime.base_url).gentxt(GenTxtRequest(
                model=runtime.model,
                temperature=0.1,
                max_tokens=1200,
                messages=[ChatMessage(role="user", content=prompt)],
            ))
            proposed = _extract_ai_json(result.content)
            if proposed:
                analysis.update({key: value for key, value in proposed.items() if key in analysis})
                analysis["source_notice"] = "由 AI 根据本次通话转写生成，必须由销售人工复核后使用。"
                provider, model = runtime.provider, result.model
    except Exception as exc:
        analysis["source_notice"] = f"AI 调用未完成，已保存可编辑保守模板：{humanize_ai_error(exc)}"

    row = SalesCallAiAnalyses(
        call_activity_id=activity.id,
        lead_id=lead.id,
        transcript=transcript,
        transcript_source=payload.transcript_source,
        original_analysis_json=json.dumps(analysis, ensure_ascii=False),
        needs_manager_intervention=bool(analysis.get("needs_manager_intervention")),
        ai_provider=provider,
        ai_model=model,
    )
    db.add(row)
    await db.commit()
    await db.refresh(row)
    return {"id": row.id, "analysis": analysis, "editable": True, "used_ai": bool(provider)}


@router.get("/call-activities/{activity_id}/ai-analysis")
async def get_call_ai_analysis(
    activity_id: int,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    _ensure_lead_role(current_user)
    await _get_scoped_activity(db, activity_id, current_user)
    row = (await db.execute(
        select(SalesCallAiAnalyses)
        .where(SalesCallAiAnalyses.call_activity_id == activity_id)
        .order_by(SalesCallAiAnalyses.id.desc())
    )).scalars().first()
    if not row:
        return {"available": False, "message": "尚未收到录音转写或手动转写，暂不能生成通话后分析。"}
    return {
        "available": True,
        "id": row.id,
        "analysis": _parse_json_dict(row.reviewed_analysis_json) or _parse_json_dict(row.original_analysis_json),
        "original_analysis": _parse_json_dict(row.original_analysis_json),
        "transcript_source": row.transcript_source,
        "reviewed_at": row.reviewed_at,
        "needs_manager_intervention": row.needs_manager_intervention,
    }


@router.put("/call-ai-analyses/{analysis_id}")
async def review_call_ai_analysis(
    analysis_id: int,
    payload: SalesCallAiReviewRequest,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    _ensure_lead_role(current_user)
    row = (await db.execute(select(SalesCallAiAnalyses).where(SalesCallAiAnalyses.id == analysis_id))).scalar_one_or_none()
    if not row:
        raise HTTPException(status_code=404, detail="通话 AI 分析不存在")
    await _get_scoped_lead(db, row.lead_id, current_user)
    row.reviewed_analysis_json = json.dumps(payload.analysis, ensure_ascii=False)
    row.needs_manager_intervention = payload.needs_manager_intervention
    row.reviewed_by_id = _employee_id(current_user)
    row.reviewed_by_name = current_user.name
    row.reviewed_at = datetime.now(timezone.utc)
    await db.commit()
    return {"message": "AI 分析修订已保存，原始 AI 结果和本次修订均已保留", "id": row.id}


def _normalize_identity(value: Optional[str]) -> str:
    return re.sub(r"[^a-z0-9]", "", (value or "").lower())


def _business_date(value: Optional[datetime]) -> Optional[date]:
    if not value:
        return None
    if isinstance(value, str):
        try:
            return date.fromisoformat(value[:10])
        except ValueError:
            return None
    # SQLite strips timezone metadata from timezone-aware UTC columns. Restore UTC
    # before converting to the business timezone so activity counts do not reset
    # incorrectly during the eight hours after China midnight.
    normalized = value if value.tzinfo else value.replace(tzinfo=timezone.utc)
    return normalized.astimezone(BUSINESS_TIMEZONE).date()


async def _find_customer_duplicates(db: AsyncSession, lead: SalesLeads, current_user=None) -> list[dict]:
    customers = (await db.execute(select(Customers))).scalars().all()
    matches = []
    phone = phone_match_key(lead.phone, lead.country) or _normalize_identity(lead.phone)
    website = _normalize_identity(lead.website)
    business = _normalize_identity(lead.business_name)
    address = _normalize_identity(lead.address)
    for customer in customers:
        reasons = []
        if phone and phone == (phone_match_key(customer.phone, customer.country) or _normalize_identity(customer.phone)): reasons.append("电话相同")
        if website and website == _normalize_identity(customer.website): reasons.append("官网相同")
        if business and address and business == _normalize_identity(customer.business_name) and address == _normalize_identity(customer.address): reasons.append("商家名称和地址相同")
        if reasons:
            if current_user is not None:
                from services.customer_permissions import get_customer_permissions
                rights = await get_customer_permissions(db, current_user, customer.id)
                if not rights["modules"]["basic"]["read"]:
                    matches.append({"message": "存在未向你开放的正式客户，请由老板核对", "reasons": reasons})
                    continue
            matches.append({"customer_id": customer.id, "customer_code": customer.customer_code, "business_name": customer.business_name, "reasons": reasons})
    return matches


@router.post("/{lead_id}/convert-to-customer")
async def convert_sales_lead_to_customer(
    lead_id: int,
    payload: SalesLeadConvertRequest,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    _ensure_lead_role(current_user)
    if _role(current_user) not in ADMIN_ROLES | {"sales_manager"}:
        raise HTTPException(status_code=403, detail="只有销售主管或系统管理员可以确认合作并转为正式客户")
    await lock_sales_workflow(db, lead_ids=[lead_id])
    lead = await _get_scoped_lead(db, lead_id, current_user)
    if lead.converted_customer_id:
        raise HTTPException(status_code=409, detail=f"该线索已转为正式客户 #{lead.converted_customer_id}")
    if not lead.contact_name:
        raise HTTPException(status_code=400, detail="转入前请补全联系人姓名")
    quotes = (await db.execute(
        select(SalesQuoteRequests).where(SalesQuoteRequests.lead_id == lead.id).order_by(SalesQuoteRequests.created_at.desc())
    )).scalars().all()
    approved_quote = next((quote for quote in quotes if quote.status == "approved"), None)
    handoff = (await db.execute(
        select(SalesHandoffChecklists).where(SalesHandoffChecklists.lead_id == lead.id)
    )).scalar_one_or_none()
    blockers = []
    if not approved_quote:
        blockers.append("需要一张已审批的报价单")
    if not handoff:
        blockers.append("尚未填写成交交接清单")
    elif approved_quote:
        if handoff.quote_id != approved_quote.id: blockers.append("交接清单需要关联当前已审批报价")
        if not (handoff.customer_goal or "").strip(): blockers.append("请填写客户目标")
        if not (handoff.key_contacts or "").strip(): blockers.append("请填写关键联系人或对接方式")
        if not handoff.operations_owner_employee_id and not (handoff.operations_owner or "").strip(): blockers.append("请选择运营对接负责人")
        if not handoff.operations_group_created: blockers.append("请确认已建立运营对接群")
        payment_status = handoff.payment_status or ("paid" if handoff.finance_payment_confirmed else "pending")
        if payment_status != "paid": blockers.append("等待财务确认全额收款")
        elif abs(float(handoff.amount_received or 0) - float(approved_quote.final_amount or 0)) > 0.005:
            blockers.append("实收金额与已审批报价不一致，请由财务核对后再转客户")
        service_start = handoff.service_start_date or approved_quote.service_start_date
        service_end = handoff.service_end_date or approved_quote.service_end_date
        if approved_quote.billing_cycle != "one_time" and (not service_start or not service_end):
            blockers.append("周期性服务必须填写服务开始和结束日期")
    if blockers:
        raise HTTPException(status_code=400, detail={"message": "成交审核尚未完成", "blockers": blockers})
    duplicates = await _find_customer_duplicates(db, lead, current_user)
    if duplicates:
        raise HTTPException(status_code=409, detail={"message": "发现可能重复的正式客户，请确认后不要重复转入", "duplicates": duplicates})

    customer_code = await allocate_customer_code(db, industry=lead.industry)
    customer = Customers(
        customer_code=customer_code,
        sales_lead_id=lead.id,
        business_name=lead.business_name,
        contact_name=lead.contact_name,
        phone=lead.phone,
        address=lead.address,
        city=lead.city,
        state=lead.state,
        country=lead.country,
        industry=lead.industry,
        website=lead.website,
        source=lead.source,
        sales_person=lead.assigned_sales_name,
        sales_employee_id=lead.assigned_sales_id,
        status="closed",
        notes=f"由电话销售线索 #{lead.id} 转入。确认说明：{payload.confirmation_notes}",
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
    )
    db.add(customer)
    await db.flush()
    db.add(Customer_contacts(customer_id=customer.id, contact_name=lead.contact_name, contact_phone=lead.phone, contact_role="销售线索联系人", notes="由电话销售中心转入"))
    service_start = _parse_optional_datetime(handoff.service_start_date or approved_quote.service_start_date)
    service_end = _parse_optional_datetime(handoff.service_end_date or approved_quote.service_end_date)
    payment_date = _parse_optional_datetime(handoff.payment_date) or handoff.payment_confirmed_at or datetime.now(timezone.utc)
    product_type = _quote_product_type(approved_quote.package_name, approved_quote.selected_platforms)
    billing_cycle = approved_quote.billing_cycle or ("monthly" if approved_quote.billing_mode == "subscription" else "one_time")
    if approved_quote.business_line_id:
        business_line = await db.get(BusinessLine, approved_quote.business_line_id)
        if business_line:
            product_type = business_line.code
    collaborator_ids = []
    try:
        collaborator_ids = [int(item) for item in json.loads(handoff.collaborator_employee_ids or "[]")]
    except (TypeError, ValueError):
        collaborator_ids = []
    engagement = None
    if approved_quote.business_line_id and approved_quote.product_id:
        engagement = CustomerEngagement(
            customer_id=customer.id,
            business_line_id=approved_quote.business_line_id,
            product_id=approved_quote.product_id,
            product_plan_id=approved_quote.product_plan_id,
            engagement_code=f"ENG-{datetime.now(timezone.utc):%Y%m%d}-{uuid4().hex[:8].upper()}",
            package_name=approved_quote.package_name,
            status="active_paid",
            owner_employee_id=handoff.operations_owner_employee_id,
            sales_employee_id=lead.assigned_sales_id,
            billing_cycle=billing_cycle,
            collection_method=(
                "stripe_auto" if approved_quote.billing_mode == "subscription"
                else approved_quote.payment_method if approved_quote.payment_method in {"check", "zelle", "bank_transfer"}
                else "other"
            ),
            currency=approved_quote.currency or "USD",
            selected_platforms=approved_quote.selected_platforms,
            service_scope_json=json.dumps({"collaborator_employee_ids": collaborator_ids}, ensure_ascii=False),
            paid_started_at=payment_date,
            created_at=datetime.now(timezone.utc),
            updated_at=datetime.now(timezone.utc),
        )
        db.add(engagement)
        await db.flush()
    deal = Deals(
        engagement_id=engagement.id if engagement else None,
        business_line_id=approved_quote.business_line_id,
        product_id=approved_quote.product_id,
        product_plan_id=approved_quote.product_plan_id,
        customer_id=customer.id, customer_name=customer.business_name,
        sales_employee_id=lead.assigned_sales_id, sales_name=lead.assigned_sales_name,
        product_type=product_type, package_name=approved_quote.package_name,
        package_platforms=approved_quote.selected_platforms, billing_cycle=billing_cycle,
        deal_amount=float(approved_quote.final_amount or 0), is_paid=True,
        service_start_date=service_start, service_end_date=service_end,
        needs_group=not handoff.operations_group_created, is_handed_over=True, is_transferred_ops=True,
        notes=f"由电话销售成交审核自动生成；报价单 #{approved_quote.id}。{handoff.special_commitments or ''}".strip(),
        deal_date=payment_date, created_at=datetime.now(timezone.utc),
    )
    db.add(deal)
    await db.flush()
    payment = await sync_payment_from_deal(
        db, deal, commit=False,
        amount_paid_override=float(handoff.amount_received or approved_quote.final_amount or 0),
        payment_method_override=approved_quote.payment_method,
        payment_mode_override="subscription_auto" if approved_quote.billing_mode == "subscription" else "manual_collection",
        currency_override=approved_quote.currency or "USD",
        transaction_reference_override=handoff.payment_reference,
        payment_date_override=payment_date,
    )
    payment.engagement_id = engagement.id if engagement else None
    payment.business_line_id = approved_quote.business_line_id
    payment.product_id = approved_quote.product_id
    payment.billing_cycle = billing_cycle
    payment.coverage_start = service_start
    payment.coverage_end = service_end
    subscription = None
    if billing_cycle != "one_time":
        subscription = Subscriptions(
            customer_id=customer.id, customer_name=customer.business_name, deal_id=deal.id,
            engagement_id=engagement.id if engagement else None,
            business_line_id=approved_quote.business_line_id,
            product_id=approved_quote.product_id,
            product_plan_id=approved_quote.product_plan_id,
            package_name=approved_quote.package_name, package_price=float(approved_quote.final_amount or 0),
            list_price_snapshot=float(approved_quote.list_amount or 0), pricing_source="approved_quote",
            selected_platforms=approved_quote.selected_platforms,
            service_scope_json=json.dumps({"collaborator_employee_ids": collaborator_ids}, ensure_ascii=False),
            billing_cycle=billing_cycle, start_date=service_start, end_date=service_end,
            auto_renew=approved_quote.billing_mode == "subscription",
            renewal_person=lead.assigned_sales_name, last_payment_date=payment_date,
            next_payment_date=service_end, status="active", renewal_result="initial_contract_approved",
            created_at=datetime.now(timezone.utc), updated_at=datetime.now(timezone.utc),
        )
        db.add(subscription)
        await db.flush()
    handoff.generated_deal_id = deal.id
    service_progress = None
    generate_service_board = bool(handoff.generate_service_board)
    if generate_service_board:
        service_progress = Service_progresses(
            customer_id=customer.id, customer_name=customer.business_name, service_type=product_type, service_stage="deal_handover",
            progress_percent=10, ops_person=handoff.operations_owner, sales_person=lead.assigned_sales_name, industry=lead.industry, country=lead.country,
            state=lead.state, city=lead.city, last_update_time=datetime.now(BUSINESS_TIMEZONE).strftime("%Y-%m-%d %H:%M"),
            package_name=approved_quote.package_name, package_platforms=approved_quote.selected_platforms,
            service_start_date=service_start.isoformat() if service_start else None, service_end_date=service_end.isoformat() if service_end else None,
            last_update_person=current_user.name, last_work_summary="报价、收款和成交交接已完成，进入运营交接阶段。",
            issue_status="none", issue_resolved=False, user_id=str(current_user.id), created_at=datetime.now(BUSINESS_TIMEZONE).isoformat(),
        )
        db.add(service_progress)
        await db.flush()
    snapshot = {key: getattr(lead, key) for key in ["business_name", "contact_name", "phone", "industry", "country", "state", "city", "address", "website", "source", "assigned_sales_id", "assigned_sales_name", "notes"]}
    snapshot["approved_quote"] = {
        "id": approved_quote.id, "package_name": approved_quote.package_name, "selected_platforms": approved_quote.selected_platforms,
        "currency": approved_quote.currency, "final_amount": approved_quote.final_amount, "payment_method": approved_quote.payment_method,
        "billing_mode": approved_quote.billing_mode, "billing_cycle": billing_cycle,
        "business_line_id": approved_quote.business_line_id, "product_id": approved_quote.product_id,
        "product_plan_id": approved_quote.product_plan_id,
        "service_start_date": approved_quote.service_start_date, "service_end_date": approved_quote.service_end_date,
    }
    snapshot["handoff"] = {
        "customer_goal": handoff.customer_goal, "key_contacts": handoff.key_contacts, "operations_owner": handoff.operations_owner,
        "operations_owner_employee_id": handoff.operations_owner_employee_id,
        "collaborator_employee_ids": collaborator_ids,
        "operations_group_created": handoff.operations_group_created, "finance_payment_confirmed": handoff.finance_payment_confirmed,
        "payment_status": handoff.payment_status, "amount_received": handoff.amount_received,
        "payment_date": handoff.payment_date, "payment_reference": handoff.payment_reference,
        "special_commitments": handoff.special_commitments,
    }
    db.add(SalesLeadConversionLogs(
        lead_id=lead.id, customer_id=customer.id, generated_customer_code=customer_code,
        duplicate_check_json=json.dumps({"checked": True, "matches": []}, ensure_ascii=False),
        lead_snapshot_json=json.dumps(snapshot, ensure_ascii=False, default=str), generate_service_board=generate_service_board,
        service_progress_id=service_progress.id if service_progress else None, converted_by_id=_employee_id(current_user), converted_by_name=current_user.name,
    ))
    await retain_legacy_interest(db, lead, current_user)
    lead.converted_customer_id = customer.id
    lead.converted_at = datetime.now(timezone.utc)
    lead.converted_by_id = _employee_id(current_user)
    lead.converted_by_name = current_user.name
    lead.status = "won"
    owner = await db.get(Employees, handoff.operations_owner_employee_id) if handoff.operations_owner_employee_id else None
    access_status = "pending"
    if owner:
        from services.customer_permissions import get_customer_permissions
        from types import SimpleNamespace
        rights = await get_customer_permissions(db, SimpleNamespace(id=owner.id, role=owner.role, name=owner.name), customer.id)
        if rights["modules"]["delivery"]["read"]:
            access_status = "authorized"
    await db.commit()
    return {
        "operations_owner": handoff.operations_owner, "operations_access_status": access_status,
        "message": "已转为正式客户，并自动生成成交、收款和订阅信息。",
        "customer_id": customer.id, "customer_code": customer_code, "deal_id": deal.id,
        "payment_id": payment.id, "engagement_id": engagement.id if engagement else None,
        "subscription_id": subscription.id if subscription else None,
        "service_progress_id": service_progress.id if service_progress else None,
    }


@router.get("/dashboard/management")
async def sales_management_dashboard(
    target_date: Optional[date] = None,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    _ensure_lead_role(current_user)
    if _role(current_user) == "sales":
        raise HTTPException(status_code=403, detail="销售主管或系统管理员可以查看管理驾驶舱")
    target_date = target_date or datetime.now(BUSINESS_TIMEZONE).date()
    scope = await _scope_condition(db, current_user)
    lead_query = select(SalesLeads)
    if scope is not None: lead_query = lead_query.where(scope)
    leads = (await db.execute(lead_query)).scalars().all()
    lead_ids = [lead.id for lead in leads]
    tasks = [] if not lead_ids else (await db.execute(select(SalesDailyDialTasks).where(SalesDailyDialTasks.task_date == target_date, SalesDailyDialTasks.status.in_(["pending", "completed"]), SalesDailyDialTasks.lead_id.in_(lead_ids)))).scalars().all()
    activities = [] if not lead_ids else (await db.execute(select(SalesCallActivities).where(SalesCallActivities.lead_id.in_(lead_ids)))).scalars().all()
    today_activities = [item for item in activities if _business_date(item.called_at) == target_date]
    completed = sum(item.status == "completed" for item in tasks)
    connected = sum(_provider_connected(item) for item in today_activities)
    interested = sum(item.outcome in {"interested", "appointment"} for item in today_activities)
    appointments = sum(item.outcome == "appointment" for item in today_activities)
    conversions = await sales_conversions(db)
    if scope is not None:
        team_ids = {_employee_id(current_user), *(await _direct_report_ids(db, current_user))}
        visible_leads = set(lead_ids)
        conversions = [r for r in conversions if r.seller_id in team_ids
            or (r.seller_id is None and r.lead_id in visible_leads)]
    converted = len(conversions)
    quotes = [] if not lead_ids else (await db.execute(
        select(SalesQuoteRequests).where(SalesQuoteRequests.lead_id.in_(lead_ids))
    )).scalars().all()
    stale_before = target_date - timedelta(days=1)
    active_follow_up_statuses = {"follow_up", "interested", "appointment"}
    high_intent_stale = sum(
        lead.status in {"interested", "appointment"}
        and (lead.last_contact_at is None or (_business_date(lead.last_contact_at) or target_date) <= stale_before)
        for lead in leads
    )
    overdue_followups = sum(
        lead.status in active_follow_up_statuses
        and lead.next_follow_up_at is not None
        and (_business_date(lead.next_follow_up_at) or target_date) < target_date
        for lead in leads
    )
    due_followups = sum(
        lead.status in active_follow_up_statuses
        and _business_date(lead.next_follow_up_at) == target_date
        for lead in leads
    )
    pending_quotes = [quote for quote in quotes if quote.status == "submitted"]
    approved_quotes = [quote for quote in quotes if quote.status == "approved"]
    # Before conversion the current assignment governs visibility; after conversion use the original seller.
    receipt_leads = {lead.id for lead in leads if not lead.converted_customer_id} | {r.lead_id for r in conversions}
    receipts, unpaid_handoffs, receipt_conflicts = await first_receipts(db, receipt_leads)
    received = currency_totals((r.currency, r.amount) for r in receipts)
    approved = currency_totals((q.currency, q.final_amount) for q in approved_quotes)
    denominator = max(len(today_activities), 1)
    people = {}
    for item in today_activities:
        name = item.sales_employee_name or "未命名销售"
        stat = people.setdefault(name, {"salesperson": name, "calls": 0, "connected": 0, "interested": 0, "appointments": 0})
        stat["calls"] += 1; stat["connected"] += int(_provider_connected(item)); stat["interested"] += int(item.outcome in {"interested", "appointment"}); stat["appointments"] += int(item.outcome == "appointment")
    sources = {}
    for lead in leads:
        label = lead.source or "未标注来源"
        entry = sources.setdefault(label, {"source": label, "total": 0, "usable": 0})
        entry["total"] += 1
        entry["usable"] += int(bool(lead.phone and lead.business_name and (lead.city or lead.address)))
    return {"target_date": target_date, "metrics": {
        "assigned": len(tasks), "completed": completed, "completion_rate": round(completed / max(len(tasks), 1) * 100, 1),
        "calls": len(today_activities), "connected": connected, "connection_rate": round(connected / denominator * 100, 1),
        "interested": interested, "interest_rate": round(interested / denominator * 100, 1),
        "appointments": appointments, "appointment_rate": round(appointments / denominator * 100, 1),
        "converted": converted, "unattributed_conversions": sum(r.seller_id is None for r in conversions),
        "conversion_rate": round(converted / max(len(receipt_leads), 1) * 100, 1),
    }, "owner_attention": {
        "receipt_conflicts": len(receipt_conflicts),
        "high_intent_stale": high_intent_stale,
        "due_followups": due_followups,
        "overdue_followups": overdue_followups,
        "pending_quotes": len(pending_quotes),
        "unpaid_handoffs": len(unpaid_handoffs),
    }, "deal_pipeline": {
        "pending_quotes": len(pending_quotes),
        "approved_quotes": len(approved_quotes),
        "approved_quote_amount": approved.get("USD", 0), "approved_quote_by_currency": approved,
        "confirmed_received_amount": received.get("USD", 0), "confirmed_received_by_currency": received,
        "unpaid_handoffs": len(unpaid_handoffs),
    }, "source_quality": [{**item, "quality_rate": round(item["usable"] / max(item["total"], 1) * 100, 1)} for item in sources.values()], "salespeople": list(people.values())}


@router.get("/dashboard/call-report")
async def sales_call_report(
    days: int = Query(default=7, ge=1, le=90),
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Provider-first sales call report with CRM outcomes kept as a separate layer."""
    _ensure_lead_role(current_user)
    today = datetime.now(BUSINESS_TIMEZONE).date()
    start_date = today - timedelta(days=days - 1)
    role = _role(current_user)
    if role == "sales":
        salesperson_ids = [_employee_id(current_user)]
    elif role == "sales_manager":
        salesperson_ids = await _direct_report_ids(db, current_user)
    else:
        salesperson_ids = [int(value) for value in (await db.execute(
            select(Employees.id).where(
                Employees.role == "sales",
                Employees.status.in_(["active", "probation"]),
            )
        )).scalars().all()]

    if not salesperson_ids:
        return {
            "period": {"days": days, "start_date": start_date, "end_date": today},
            "source": {"status": "no_salespeople", "label": "暂无可统计销售", "provider": "RingCentral",
                       "data_complete": False, "coverage_status": "unknown", "counts_observed": True,
                       "message": "当前范围暂无可统计销售。"},
            "connection_health": {"total": 0, "ready": 0, "attention": 0, "not_connected": 0, "needs_attention": 0, "never_synced": 0, "binding_conflicts": 0},
            "summary": {
                "provider_calls": 0, "connected": 0, "not_connected": 0, "connection_rate": 0,
                "total_talk_seconds": 0, "average_talk_seconds": 0, "crm_records": 0,
                "linked_records": 0, "link_rate": 0, "interested": 0, "appointments": 0,
                "conversions": 0, "assigned": 0, "completed": 0, "completion_rate": 0,
            },
            "industry_breakdown": industry_breakdown([], [], {}),
            "result_breakdown": [], "daily": [], "employees": [], "recent_calls": [],
        }

    employees = (await db.execute(
        select(Employees).where(Employees.id.in_(salesperson_ids))
    )).scalars().all()
    names = {employee.id: employee.name for employee in employees}
    coverage_end = datetime.now(timezone.utc)
    coverage_start = datetime.combine(start_date, datetime.min.time(), tzinfo=BUSINESS_TIMEZONE).astimezone(timezone.utc)
    connection_items = await team_connection_statuses(db, salesperson_ids,
        coverage_start=coverage_start, coverage_end=coverage_end)
    connections_by_sales = {item["employee_id"]: item for item in connection_items}
    connection_health = {
        "total": len(salesperson_ids),
        "ready": sum(item["sync_health"] == "enabled" and bool(item.get("last_synced_at")) for item in connection_items),
        "attention": sum(bool(item["connected"]) and (item["sync_health"] != "enabled" or not item.get("last_synced_at")) for item in connection_items),
        "not_connected": sum(not item["connected"] for item in connection_items),
        "never_synced": sum(not item.get("last_synced_at") for item in connection_items),
        "binding_conflicts": sum(bool(item.get("binding_conflict")) for item in connection_items),
    }
    connection_health["needs_attention"] = connection_health["total"] - connection_health["ready"]

    range_start = coverage_start
    range_end = datetime.combine(today + timedelta(days=1), datetime.min.time(), tzinfo=BUSINESS_TIMEZONE).astimezone(timezone.utc)
    if db.get_bind().dialect.name == "sqlite":
        # Server-default timestamps omit fractions, while ORM writes include them.
        # Both stored representations must agree on the midnight boundary.
        range_start = range_start.replace(tzinfo=None).isoformat(sep=" ", timespec="seconds")
        range_end = range_end.replace(tzinfo=None).isoformat(sep=" ", timespec="seconds")
    provider_data = (await db.execute(
        select(RingCentralCallRecords, SalesLeads.id, SalesLeads.business_name, SalesLeads.industry)
        .outerjoin(SalesLeads, SalesLeads.id == RingCentralCallRecords.lead_id).where(
            RingCentralCallRecords.sales_employee_id.in_(salesperson_ids),
            func.lower(RingCentralCallRecords.direction) == "outbound",
            RingCentralCallRecords.sync_status == "verified",
            or_(RingCentralCallRecords.started_at.is_(None),
                (RingCentralCallRecords.started_at >= range_start) & (RingCentralCallRecords.started_at < range_end)),
        )
    )).all()
    provider_rows = [row[0] for row in provider_data]
    lead_names = {lead_id: name for _, lead_id, name, _ in provider_data if lead_id is not None}
    industry_by_lead = {lead_id: industry for _, lead_id, _, industry in provider_data if lead_id is not None}

    activity_data = (await db.execute(
        select(SalesCallActivities, SalesLeads.id, SalesLeads.industry)
        .outerjoin(SalesLeads, SalesLeads.id == SalesCallActivities.lead_id).where(
            SalesCallActivities.sales_employee_id.in_(salesperson_ids),
            SalesCallActivities.called_at >= range_start,
            SalesCallActivities.called_at < range_end,
        )
    )).all()
    activities = [row[0] for row in activity_data]
    industry_by_lead.update({lead_id: industry for _, lead_id, industry in activity_data if lead_id is not None})
    tasks = (await db.execute(
        select(SalesDailyDialTasks).where(
            SalesDailyDialTasks.sales_employee_id.in_(salesperson_ids),
            SalesDailyDialTasks.status.in_(["pending", "completed"]),
            SalesDailyDialTasks.task_date >= start_date,
            SalesDailyDialTasks.task_date <= today,
        )
    )).scalars().all()

    conversions_by_sales = await conversion_counts(db, salesperson_ids, start_date, today)

    result_counts: dict[str, int] = {}
    daily_map = {
        start_date + timedelta(days=index): {"calls": 0, "connected": 0, "talk_seconds": 0}
        for index in range(days)
    }
    for row in provider_rows:
        label = _ringcentral_result_label(row.provider_result, bool(row.connected))
        result_counts[label] = result_counts.get(label, 0) + 1
        row_day = _business_date(row.started_at)
        if row_day in daily_map:
            daily_map[row_day]["calls"] += 1
            daily_map[row_day]["connected"] += int(bool(row.connected))
            if row.connected:
                daily_map[row_day]["talk_seconds"] += max(0, int(row.duration_seconds or 0))

    employee_items = []
    for sales_id in salesperson_ids:
        employee_provider = [row for row in provider_rows if row.sales_employee_id == sales_id]
        employee_activities = [row for row in activities if row.sales_employee_id == sales_id]
        employee_tasks = [row for row in tasks if row.sales_employee_id == sales_id]
        connected = sum(bool(row.connected) for row in employee_provider)
        total_talk_seconds = sum(max(0, int(row.duration_seconds or 0)) for row in employee_provider if row.connected)
        linked_records = sum(bool(row.activity_id) for row in employee_provider)
        assigned = len(employee_tasks)
        completed = sum(row.status == "completed" for row in employee_tasks)
        connection_status = connections_by_sales.get(sales_id, {})
        employee_items.append({
            "sales_employee_id": sales_id,
            "connection_status": connection_status.get("sync_health", "disconnected"),
            "extension_number": connection_status.get("extension_number"),
            "last_synced_at": connection_status.get("last_synced_at"),
            "needs_attention": connection_status.get("sync_health") != "enabled" or not connection_status.get("last_synced_at"),
            "connection_message": connection_status.get("message", "请销售登录自己的账号连接 RingCentral。"),
            "data_complete": False,
            "coverage_status": "unknown",
            "sync_coverage": connection_status.get("coverage"),
            "industry_breakdown": industry_breakdown(employee_activities, employee_provider, industry_by_lead),
            "salesperson": names.get(sales_id) or next((row.sales_employee_name for row in employee_provider if row.sales_employee_name), "未命名销售"),
            "provider_calls": len(employee_provider),
            "connected": connected,
            "not_connected": len(employee_provider) - connected,
            "connection_rate": round(connected / max(len(employee_provider), 1) * 100, 1),
            "total_talk_seconds": total_talk_seconds,
            "average_talk_seconds": round(total_talk_seconds / max(connected, 1)),
            "crm_records": len(employee_activities),
            "linked_records": linked_records,
            "link_rate": round(linked_records / max(len(employee_provider), 1) * 100, 1),
            "interested": sum(row.outcome in {"interested", "appointment"} for row in employee_activities),
            "appointments": sum(row.outcome == "appointment" for row in employee_activities),
            "no_answer_records": sum(row.outcome == "no_answer" for row in employee_activities),
            "conversions": conversions_by_sales.get(sales_id, 0),
            "assigned": assigned,
            "completed": completed,
            "completion_rate": round(completed / max(assigned, 1) * 100, 1),
        })
    employee_items.sort(key=lambda row: (-row["provider_calls"], -row["connected"], row["salesperson"]))

    provider_calls = len(provider_rows)
    connected = sum(bool(row.connected) for row in provider_rows)
    linked_records = sum(bool(row.activity_id) for row in provider_rows)
    total_talk_seconds = sum(max(0, int(row.duration_seconds or 0)) for row in provider_rows if row.connected)
    assigned = len(tasks)
    completed = sum(row.status == "completed" for row in tasks)
    recent_calls = sorted(
        provider_rows,
        key=lambda row: (row.started_at or row.created_at or datetime.min.replace(tzinfo=timezone.utc)).replace(tzinfo=timezone.utc) if not (row.started_at or row.created_at or datetime.min.replace(tzinfo=timezone.utc)).tzinfo else (row.started_at or row.created_at),
        reverse=True,
    )[:50]
    return {
        "period": {"days": days, "start_date": start_date, "end_date": today},
        "source": {
            "status": "verified" if provider_calls else "waiting_provider_data",
            "label": "RingCentral 官方通话记录" if provider_calls else "统计期内暂无 RingCentral 官方通话记录",
            "provider": "RingCentral",
            # Current authorization or an active webhook cannot prove historical
            # coverage of the selected period. Until completed sync windows are
            # persisted, these are observed records rather than a complete total.
            "data_complete": False,
            "coverage_status": "unknown",
            "counts_observed": True,
            "message": (
                f"{connection_health['needs_attention']} 位销售未连接、尚未同步或连接需处理；当前数字仅为已同步的官方记录，不能据此判断实际拨打总量。"
                if connection_health["needs_attention"]
                else "当前连接可用；所选时段的完整同步覆盖尚未核验，当前数字仅为已同步的官方记录。"
            ),
        },
        "connection_health": connection_health,
        "industry_breakdown": industry_breakdown(activities, provider_rows, industry_by_lead),
        "sync_coverage": {
            "requested_from": coverage_start,
            "requested_to": coverage_end,
            "window_fetched_employees": sum(item.get("coverage", {}).get("status") == "window_fetched" for item in connection_items),
            "unverified_employees": sum(item.get("coverage", {}).get("status") != "window_fetched" for item in connection_items),
            "failed_or_partial_employees": sum(bool(item.get("coverage", {}).get("needs_retry")) for item in connection_items),
            "data_complete": False,
        },
        "summary": {
            "provider_calls": provider_calls,
            "connected": connected,
            "not_connected": provider_calls - connected,
            "connection_rate": round(connected / max(provider_calls, 1) * 100, 1),
            "total_talk_seconds": total_talk_seconds,
            "average_talk_seconds": round(total_talk_seconds / max(connected, 1)),
            "crm_records": len(activities),
            "linked_records": linked_records,
            "link_rate": round(linked_records / max(provider_calls, 1) * 100, 1),
            "interested": sum(row.outcome in {"interested", "appointment"} for row in activities),
            "appointments": sum(row.outcome == "appointment" for row in activities),
            "conversions": sum(conversions_by_sales.values()),
            "assigned": assigned,
            "completed": completed,
            "completion_rate": round(completed / max(assigned, 1) * 100, 1),
        },
        "result_breakdown": [
            {"label": label, "count": count, "rate": round(count / max(provider_calls, 1) * 100, 1)}
            for label, count in sorted(result_counts.items(), key=lambda item: (-item[1], item[0]))
        ],
        "daily": [
            {
                "date": day,
                **values,
                "connection_rate": round(values["connected"] / max(values["calls"], 1) * 100, 1),
            }
            for day, values in daily_map.items()
        ],
        "employees": employee_items,
        "recent_calls": [
            {
                "id": row.id,
                "sales_employee_id": row.sales_employee_id,
                "salesperson": names.get(row.sales_employee_id) or row.sales_employee_name or "未命名销售",
                "lead_id": row.lead_id,
                "business_name": lead_names.get(int(row.lead_id)) if row.lead_id else None,
                "remote_phone": row.remote_phone,
                "started_at": row.started_at,
                "connected": bool(row.connected),
                "duration_seconds": max(0, int(row.duration_seconds or 0)),
                "result": _ringcentral_result_label(row.provider_result, bool(row.connected)),
                "crm_recorded": bool(row.activity_id),
            }
            for row in recent_calls
        ],
    }


def _performance_suggestions(metrics: dict) -> list[str]:
    suggestions: list[str] = []
    if metrics["assigned"] and metrics["completion_rate"] < 80:
        suggestions.append("优先完成已分配任务，减少当天遗留任务。")
    if metrics["calls"] >= 10 and metrics["connection_rate"] < 20:
        suggestions.append("接通率偏低，可调整拨打时段并优先复核号码质量。")
    if metrics["connected"] >= 8 and metrics["interest_rate"] < 10:
        suggestions.append("已有效接通但意向偏低，建议复盘开场话术和切入问题。")
    if metrics["interested"] >= 2 and metrics["appointments"] == 0:
        suggestions.append("已有意向商家，下一步应明确预约时间或报价确认动作。")
    if metrics["overdue_followups"]:
        suggestions.append("存在逾期回访，请先处理约定时间已过的商家。")
    if metrics["calls"] >= 5 and metrics["note_quality_rate"] < 70:
        suggestions.append("通话备注完整度不足，请记录需求、异议和明确的下一步。")
    if not suggestions:
        suggestions.append("执行与跟进节奏稳定，可继续保持并关注高意向线索推进。")
    return suggestions[:3]


@router.get("/dashboard/performance")
async def sales_performance_dashboard(
    days: int = Query(default=30, ge=1, le=90),
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Explainable pre-sales performance score; never reads formal customer finance data."""
    _ensure_lead_role(current_user)
    today = datetime.now(BUSINESS_TIMEZONE).date()
    start_date = today - timedelta(days=days - 1)
    role = _role(current_user)
    if role == "sales":
        salesperson_ids = [_employee_id(current_user)]
    elif role == "sales_manager":
        salesperson_ids = await _direct_report_ids(db, current_user)
    else:
        salesperson_ids = [int(value) for value in (await db.execute(
            select(Employees.id).where(
                Employees.role == "sales",
                Employees.status.in_(["active", "probation"]),
            )
        )).scalars().all()]

    if not salesperson_ids:
        return {"period": {"days": days, "start_date": start_date, "end_date": today}, "items": []}

    employees = (await db.execute(select(Employees).where(Employees.id.in_(salesperson_ids)))).scalars().all()
    names = {employee.id: employee.name for employee in employees}
    tasks = (await db.execute(
        select(SalesDailyDialTasks).where(
            SalesDailyDialTasks.sales_employee_id.in_(salesperson_ids),
            SalesDailyDialTasks.status.in_(["pending", "completed"]),
            SalesDailyDialTasks.task_date >= start_date,
            SalesDailyDialTasks.task_date <= today,
        )
    )).scalars().all()
    activities = (await db.execute(
        select(SalesCallActivities).where(SalesCallActivities.sales_employee_id.in_(salesperson_ids))
    )).scalars().all()
    activities = [item for item in activities if start_date <= (_business_date(item.called_at) or today) <= today]

    lead_rows = (await db.execute(
        select(SalesLeads).where(SalesLeads.assigned_sales_id.in_(salesperson_ids))
    )).scalars().all()
    overdue_by_sales = {sales_id: 0 for sales_id in salesperson_ids}
    for lead in lead_rows:
        follow_up_day = _business_date(lead.next_follow_up_at)
        if lead.status == "follow_up" and follow_up_day and follow_up_day < today:
            overdue_by_sales[lead.assigned_sales_id] = overdue_by_sales.get(lead.assigned_sales_id, 0) + 1

    conversions_by_sales = await conversion_counts(db, salesperson_ids, start_date, today)

    items = []
    for sales_id in salesperson_ids:
        employee_tasks = [item for item in tasks if item.sales_employee_id == sales_id]
        employee_activities = [item for item in activities if item.sales_employee_id == sales_id]
        assigned = len(employee_tasks)
        completed = sum(item.status == "completed" for item in employee_tasks)
        calls = len(employee_activities)
        connected = sum(_provider_connected(item) for item in employee_activities)
        interested = sum(item.outcome in {"interested", "appointment"} for item in employee_activities)
        appointments = sum(item.outcome == "appointment" for item in employee_activities)
        documented = sum(bool((item.notes or "").strip()) and len((item.notes or "").strip()) >= 12 for item in employee_activities)
        compliant = sum(
            item.outcome in NO_CONVERSATION_EVIDENCE
            or (item.outcome in {"callback", "interested", "appointment"} and bool(item.next_follow_up_at) and bool((item.notes or "").strip()))
            or (item.outcome in {"not_interested", "do_not_contact"} and bool((item.notes or "").strip()))
            for item in employee_activities
        )
        completion_rate = round(completed / max(assigned, 1) * 100, 1)
        connection_rate = round(connected / max(calls, 1) * 100, 1)
        interest_rate = round(interested / max(connected, 1) * 100, 1)
        note_quality_rate = round(documented / max(calls, 1) * 100, 1)
        overdue_followups = overdue_by_sales.get(sales_id, 0)
        conversions = conversions_by_sales.get(sales_id, 0)

        execution_score = min(25, completion_rate * 0.25)
        discipline_score = max(0, 20 - min(20, overdue_followups * 5))
        opportunity_score = min(8, connection_rate * 0.08) + min(8, interest_rate * 0.08) + min(4, appointments * 2)
        result_score = min(10, appointments * 5) + min(15, conversions * 15)
        compliance_rate = round(compliant / max(calls, 1) * 100, 1)
        documentation_score = min(7, note_quality_rate * 0.07) + min(3, compliance_rate * 0.03)
        total_score = round(execution_score + discipline_score + opportunity_score + result_score + documentation_score, 1)
        confidence = "数据不足" if calls < 10 else ("参考可靠" if calls >= 30 else "可参考")
        metrics = {
            "assigned": assigned, "completed": completed, "calls": calls, "connected": connected,
            "interested": interested, "appointments": appointments, "conversions": conversions,
            "completion_rate": completion_rate, "connection_rate": connection_rate,
            "interest_rate": interest_rate, "note_quality_rate": note_quality_rate,
            "overdue_followups": overdue_followups, "compliance_rate": compliance_rate,
        }
        items.append({
            "sales_employee_id": sales_id,
            "salesperson": names.get(sales_id, "未命名销售"),
            "score": total_score,
            "confidence": confidence,
            "score_breakdown": {
                "execution": round(execution_score, 1), "discipline": round(discipline_score, 1),
                "opportunity": round(opportunity_score, 1), "results": round(result_score, 1),
                "documentation": round(documentation_score, 1),
            },
            "metrics": metrics,
            "suggestions": _performance_suggestions(metrics),
        })
    items.sort(key=lambda item: (-item["score"], -item["metrics"]["conversions"], -item["metrics"]["appointments"], item["salesperson"]))
    for index, item in enumerate(items, start=1):
        item["rank"] = index
    return {"period": {"days": days, "start_date": start_date, "end_date": today}, "items": items}


async def _save_contact_details(db, activity, payload, user):
    details = payload.contact_details
    if not details:
        return
    if payload.outcome == "no_answer" and details.reached_person != "unknown":
        raise HTTPException(status_code=422, detail="未接通不能标记为已与决策人沟通")
    await db.flush()
    db.add(SalesContactDetails(activity_id=activity.id, lead_id=activity.lead_id,
        recorded_by_id=_employee_id(user), **details.model_dump()))


async def _result_dial_attempt(db, lead, user, attempt_id, *, task=None):
    if attempt_id is None and task is not None:
        attempt_id = (await db.execute(select(SalesDialAttempt.id).where(
            SalesDialAttempt.task_id == task.id, SalesDialAttempt.lead_id == lead.id,
            SalesDialAttempt.sales_employee_id == task.sales_employee_id,
        ).order_by(SalesDialAttempt.id.desc()).limit(1))).scalar_one_or_none()
    if attempt_id is None:
        return None
    attempt = await db.get(SalesDialAttempt, attempt_id)
    if not attempt or attempt.lead_id != lead.id:
        raise HTTPException(status_code=409, detail="拨号记录不属于本次线索，请重新拨打后记录")
    target_task = task or await db.get(SalesDailyDialTasks, attempt.task_id)
    if not target_task or attempt.task_id != target_task.id or target_task.lead_id != lead.id \
            or target_task.sales_employee_id != attempt.sales_employee_id \
            or lead.assigned_sales_id != attempt.sales_employee_id:
        raise HTTPException(status_code=409, detail="拨号记录或线索归属已改变，请刷新后核对")
    if (task is None and target_task.status != "completed") or (task is not None and target_task.status != "pending"):
        raise HTTPException(status_code=409, detail="拨号对应任务的状态已改变，请刷新后核对")
    await _resolve_workbench_salesperson(db, user, attempt.sales_employee_id)
    age = datetime.now(timezone.utc) - _as_utc(attempt.started_at)
    if age < -timedelta(minutes=5) or age > timedelta(hours=12):
        raise HTTPException(status_code=409, detail="拨号记录已超时，请重新拨打；历史记录继续保留")
    if (await db.execute(select(SalesCallActivities.id).where(SalesCallActivities.dial_attempt_id == attempt.id))).first():
        raise HTTPException(status_code=409, detail="本次拨号结果已经保存，请勿重复提交")
    return attempt


async def _attach_result_provider_call(db, lead, activity, task, dial_started_at):
    provider_candidates = (await db.execute(select(RingCentralCallRecords).where(
        RingCentralCallRecords.task_id == task.id, RingCentralCallRecords.lead_id == lead.id,
        RingCentralCallRecords.sales_employee_id == activity.sales_employee_id,
        RingCentralCallRecords.activity_id.is_(None),
    ).order_by(RingCentralCallRecords.started_at.desc(), RingCentralCallRecords.id.desc()))).scalars().all()
    dial_key = phone_match_key(activity.dial_phone or lead.phone, lead.country)
    provider_call = None
    for record in provider_candidates:
        if not (dial_key and phone_match_key(record.remote_phone, lead.country) == dial_key
                and record.started_at and dial_started_at
                and -timedelta(minutes=5) <= _as_utc(record.started_at) - _as_utc(dial_started_at) <= timedelta(hours=12)):
            continue
        if activity.dial_attempt_id is not None:
            # Share the provider sync's attempt-level association rule. An old
            # same-number call, or an ambiguous repeated dial, cannot fill this
            # new result just because the task IDs match.
            from services.ringcentral_sync import _linked_activity
            linked = await _linked_activity(db, activity.sales_employee_id, lead.id, task,
                remote_phone=record.remote_phone, call_started_at=record.started_at)
            if linked is None or linked.id != activity.id:
                continue
        provider_call = record
        break
    if provider_call:
        activity.dial_phone = activity.dial_phone or dial_key
        provider_call.activity_id = activity.id
        activity.call_duration_seconds = provider_call.duration_seconds
        activity.ringcentral_connected = provider_call.connected
        activity.ringcentral_call_id = provider_call.ringcentral_call_id
        activity.ringcentral_session_id = provider_call.ringcentral_session_id or provider_call.telephony_session_id
        activity.recording_uri = provider_call.recording_uri
        activity.sync_status = provider_call.sync_status


@router.post("/workbench/tasks/{task_id}/result")
async def record_daily_call_result(
    task_id: int,
    payload: SalesCallResultCreate,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    _ensure_lead_role(current_user)
    task = (await db.execute(select(SalesDailyDialTasks).where(SalesDailyDialTasks.id == task_id))).scalar_one_or_none()
    if not task:
        raise HTTPException(status_code=404, detail="每日任务不存在")
    await _resolve_workbench_salesperson(db, current_user, task.sales_employee_id)
    await lock_sales_workflow(db, lead_ids=[task.lead_id], employee_ids=[task.sales_employee_id])
    task = (await db.execute(select(SalesDailyDialTasks).where(SalesDailyDialTasks.id == task_id).execution_options(populate_existing=True))).scalar_one_or_none()
    if task is None:
        raise HTTPException(status_code=404, detail="每日任务不存在")
    if task.status != "pending":
        raise HTTPException(status_code=400, detail="该任务已完成或已转交，请刷新当前队列")
    lead = await _get_scoped_lead(db, task.lead_id, current_user)
    await ensure_lead_contact_allowed(db, lead)
    ensure_enrichment_editable(lead)
    if lead.assigned_sales_id != task.sales_employee_id:
        raise HTTPException(status_code=409, detail="线索归属已变更，请刷新任务队列")

    await _validate_manual_call_result(db, payload)
    dial_attempt = await _result_dial_attempt(db, lead, current_user, payload.dial_attempt_id, task=task)
    if dial_attempt:
        await ensure_phone_contact_allowed(db, dial_attempt.dial_phone, lead.country)

    if payload.enrichment is not None:
        await apply_enrichment(db, lead, payload.enrichment.model_copy(update={"source": "call"}), current_user)
        await ensure_lead_contact_allowed(db, lead)

    now = datetime.now(timezone.utc)
    suggested_follow_up_at, next_action_label = _suggest_follow_up(payload.outcome, now)
    next_follow_up_at = payload.next_follow_up_at or suggested_follow_up_at
    activity = SalesCallActivities(
        lead_id=lead.id,
        sales_employee_id=task.sales_employee_id,
        sales_employee_name=(await db.execute(select(Employees.name).where(Employees.id == task.sales_employee_id))).scalar_one_or_none(),
        dial_phone=dial_attempt.dial_phone if dial_attempt else task.dial_phone,
        dial_attempt_id=dial_attempt.id if dial_attempt else None,
        outcome=payload.outcome,
        communication_record=payload.selection_snapshot(),
        notes=payload.notes,
        next_follow_up_at=next_follow_up_at,
        called_at=now,
    )
    db.add(activity)
    await _save_contact_details(db, activity, payload, current_user)
    await db.flush()
    await _attach_result_provider_call(db, lead, activity, task,
        dial_attempt.started_at if dial_attempt else task.dial_started_at)
    old_assignment = (lead.assigned_sales_id, lead.assigned_sales_name)
    next_follow_up_at = await _apply_contact_outcome(db, lead, payload.outcome, now, next_follow_up_at, current_user)
    activity.next_follow_up_at = next_follow_up_at
    if old_assignment[0] and lead.assigned_sales_id is None:
        await sync_pending_daily_tasks(db, lead, None)
        db.add(SalesLeadAssignmentLogs(
            lead_id=lead.id, action="auto_cooling_released",
            from_sales_employee_id=old_assignment[0], from_sales_employee_name=old_assignment[1],
            reason=lead.last_recycle_reason, operated_by_name="系统自动循环",
            effective_until=lead.cooldown_until,
        ))
    if payload.notes:
        lead.notes = payload.notes
    if payload.outcome == "do_not_contact":
        lead.do_not_contact = True
        lead.do_not_contact_reason = payload.notes or "商家在通话中明确要求不再联系"
        await persist_lead_suppression(db, lead, current_user, extra_phones=[activity.dial_phone])
        await sync_pending_daily_tasks(db, lead, None)
    task.status = "completed"
    task.completed_activity_id = activity.id
    task.completed_at = now
    await db.commit()
    await db.refresh(lead)
    return {
        "message": "通话结果已记录",
        "task_id": task.id,
        "lead_id": lead.id,
        "lead": SalesLeadResponse.model_validate(lead).model_dump(mode="json"),
        "enrichment": await get_enrichment(db, lead) if payload.enrichment is not None else None,
        "status": lead.status,
        "next_follow_up_at": next_follow_up_at,
        "next_action_label": next_action_label,
        "used_suggested_follow_up": payload.next_follow_up_at is None and suggested_follow_up_at is not None,
    }


@router.post("/{lead_id}/follow-up")
async def record_supplemental_follow_up(
    lead_id: int,
    payload: SalesCallResultCreate,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Record another valid call without reopening or inflating a completed daily task."""
    _ensure_lead_role(current_user)
    await lock_sales_workflow(db, lead_ids=[lead_id])
    selection = payload.selection_snapshot()
    if payload.submission_id:
        # The per-lead sales workflow lock serializes attempts, including
        # supplemental notes made without a provider dial-attempt ID.
        submission_id = str(payload.submission_id)
        actor_id = _employee_id(current_user)
        normalized = json.dumps(payload.model_dump(mode="json"), sort_keys=True, ensure_ascii=False, separators=(",", ":"))
        fingerprint = hashlib.sha256(normalized.encode()).hexdigest()
        previous = await db.scalar(select(SalesCallActivities).where(
            SalesCallActivities.lead_id == lead_id,
            SalesCallActivities.communication_record["submission_id"].as_string() == submission_id,
            SalesCallActivities.communication_record["actor_id"].as_integer() == actor_id))
        if previous is not None:
            if previous.communication_record.get("request_hash") != fingerprint:
                raise HTTPException(409, "这条记录已保存，提交内容有变化，请核对沟通历史")
            # Cooldown can release ownership during the original write. A replay
            # may confirm the actor's own submission, but cannot expose a dossier.
            return {"message": "这条追加跟进已保存", "lead_id": lead_id,
                    "next_follow_up_at": _as_utc(previous.next_follow_up_at), "replayed": True}
        selection = {**(selection or {}), "submission_id": submission_id, "actor_id": actor_id,
                     "request_hash": fingerprint}
    lead = await _get_scoped_lead(db, lead_id, current_user)
    if _role(current_user) == "sales" and lead.assigned_sales_id != _employee_id(current_user):
        raise HTTPException(status_code=403, detail="只能追加本人负责线索的跟进")
    if payload.outcome != "do_not_contact" and await lead_has_active_closer(db, lead.id):
        raise HTTPException(409, "该商家已由主管或老板接手，请在踢单名单记录进展")
    await ensure_lead_contact_allowed(db, lead)
    ensure_enrichment_editable(lead)
    if lead.status not in {"contacted", "follow_up", "interested", "appointment"}:
        raise HTTPException(status_code=400, detail="请先通过每日任务完成首次联系，再追加跟进")

    await _validate_manual_call_result(db, payload)
    dial_attempt = await _result_dial_attempt(db, lead, current_user, payload.dial_attempt_id)
    if dial_attempt:
        await ensure_phone_contact_allowed(db, dial_attempt.dial_phone, lead.country)

    if payload.enrichment is not None:
        await apply_enrichment(db, lead, payload.enrichment.model_copy(update={"source": "call"}), current_user)
        await ensure_lead_contact_allowed(db, lead)

    now = datetime.now(timezone.utc)
    suggested_follow_up_at, next_action_label = _suggest_follow_up(payload.outcome, now)
    next_follow_up_at = payload.next_follow_up_at or suggested_follow_up_at
    activity = SalesCallActivities(
        lead_id=lead.id,
        sales_employee_id=dial_attempt.sales_employee_id if dial_attempt else _employee_id(current_user),
        sales_employee_name=(await db.get(Employees, dial_attempt.sales_employee_id)).name if dial_attempt else current_user.name,
        dial_phone=dial_attempt.dial_phone if dial_attempt else None,
        dial_attempt_id=dial_attempt.id if dial_attempt else None,
        outcome=payload.outcome,
        communication_record=selection,
        notes=payload.notes,
        next_follow_up_at=next_follow_up_at,
        called_at=now,
    )
    db.add(activity)
    await _save_contact_details(db, activity, payload, current_user)
    if dial_attempt:
        await db.flush()
        await _attach_result_provider_call(db, lead, activity,
            await db.get(SalesDailyDialTasks, dial_attempt.task_id), dial_attempt.started_at)
    old_assignment = (lead.assigned_sales_id, lead.assigned_sales_name)
    next_follow_up_at = await _apply_contact_outcome(db, lead, payload.outcome, now, next_follow_up_at, current_user)
    activity.next_follow_up_at = next_follow_up_at
    if old_assignment[0] and lead.assigned_sales_id is None:
        await sync_pending_daily_tasks(db, lead, None)
        db.add(SalesLeadAssignmentLogs(
            lead_id=lead.id, action="auto_cooling_released",
            from_sales_employee_id=old_assignment[0], from_sales_employee_name=old_assignment[1],
            reason=lead.last_recycle_reason, operated_by_name="系统自动循环",
            effective_until=lead.cooldown_until,
        ))
    if payload.notes:
        lead.notes = payload.notes
    if payload.outcome == "do_not_contact":
        lead.do_not_contact = True
        lead.do_not_contact_reason = payload.notes or "商家在追加跟进中明确要求不再联系"
        await persist_lead_suppression(db, lead, current_user, extra_phones=[activity.dial_phone])
        await sync_pending_daily_tasks(db, lead, None)
    await db.commit()
    await db.refresh(lead)
    return {
        "message": "追加跟进已记录并加入时间线，不会覆盖历史记录，也不会重复增加今日任务完成数",
        "lead_id": lead.id,
        "lead": SalesLeadResponse.model_validate(lead).model_dump(mode="json"),
        "enrichment": await get_enrichment(db, lead) if payload.enrichment is not None else None,
        "status": lead.status,
        "next_follow_up_at": next_follow_up_at,
        "next_action_label": next_action_label,
        "used_suggested_follow_up": payload.next_follow_up_at is None and suggested_follow_up_at is not None,
    }


@router.post("/workbench/tasks/{task_id}/dial-started")
async def record_ringcentral_dial_started(
    task_id: int,
    payload: Optional[SalesDialStartedInput] = Body(default=None),
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Record the local RingCentral deep-link action before API syncing is configured."""
    _ensure_lead_role(current_user)
    task = (await db.execute(select(SalesDailyDialTasks).where(SalesDailyDialTasks.id == task_id))).scalar_one_or_none()
    if not task:
        raise HTTPException(status_code=404, detail="每日任务不存在")
    await _resolve_workbench_salesperson(db, current_user, task.sales_employee_id)
    await lock_sales_workflow(db, lead_ids=[task.lead_id], employee_ids=[task.sales_employee_id])
    task = (await db.execute(select(SalesDailyDialTasks).where(SalesDailyDialTasks.id == task_id).execution_options(populate_existing=True))).scalar_one_or_none()
    if task is None:
        raise HTTPException(status_code=404, detail="每日任务不存在")
    if task.status not in {"pending", "completed"}:
        raise HTTPException(status_code=400, detail="该任务已转交或取消，请刷新当前队列")
    lead = await _get_scoped_lead(db, task.lead_id, current_user)
    if await lead_has_active_closer(db, lead.id):
        raise HTTPException(409, "该商家已由主管或老板接手踢单")
    await ensure_lead_contact_allowed(db, lead)
    if (await quality_for(db, 'lead', lead.id))['status'] in {'invalid_phone', 'not_target', 'closed'}:
        raise HTTPException(409, "该商家核验为无效或非目标，请核实资料并更新核验状态后再拨打")
    ensure_enrichment_editable(lead)
    if lead.assigned_sales_id != task.sales_employee_id:
        raise HTTPException(status_code=409, detail="线索归属已变更，请刷新任务队列")
    if task.status == "completed":
        if lead.status not in {"contacted", "follow_up", "interested", "appointment"}:
            raise HTTPException(status_code=409, detail="此线索当前不允许追加联系")
        original_activity = await db.get(SalesCallActivities, task.completed_activity_id) if task.completed_activity_id else None
        if not original_activity or original_activity.lead_id != lead.id or original_activity.sales_employee_id != task.sales_employee_id:
            raise HTTPException(status_code=409, detail="原通话记录不完整，请刷新后核对")
    task.dial_phone = await saved_dial_phone(db, lead, payload.phone if payload else None)
    task.dial_started_at = datetime.now(timezone.utc)
    attempt = SalesDialAttempt(task_id=task.id, lead_id=lead.id, sales_employee_id=task.sales_employee_id,
                               dial_phone=task.dial_phone, started_at=task.dial_started_at)
    db.add(attempt)
    await db.commit()
    return {"task_id": task.id, "dial_attempt_id": attempt.id, "dial_started_at": task.dial_started_at, "phone": task.dial_phone}


@router.get("/enrichment/catalog")
async def get_sales_enrichment_catalog(
    current_user: UserResponse = Depends(get_current_user), db: AsyncSession = Depends(get_db),
):
    _ensure_lead_role(current_user)
    return {"items": await enrichment_catalog(db)}


@router.get("/{lead_id}/enrichment")
async def get_sales_lead_enrichment(
    lead_id: int, current_user: UserResponse = Depends(get_current_user), db: AsyncSession = Depends(get_db),
):
    _ensure_lead_role(current_user)
    lead = await _get_scoped_lead(db, lead_id, current_user)
    return await get_enrichment(db, lead)


@router.put("/{lead_id}/enrichment")
async def update_sales_lead_enrichment(
    lead_id: int, payload: SalesEnrichmentUpdate,
    current_user: UserResponse = Depends(get_current_user), db: AsyncSession = Depends(get_db),
):
    _ensure_lead_role(current_user)
    await lock_sales_workflow(db, lead_ids=[lead_id])
    lead = await _get_scoped_lead(db, lead_id, current_user)
    await apply_enrichment(db, lead, payload, current_user)
    await db.commit()
    await db.refresh(lead)
    return await get_enrichment(db, lead)


@router.get("/{lead_id}/enrichment/history")
async def get_sales_lead_enrichment_history(
    lead_id: int, skip: int = Query(0, ge=0), limit: int = Query(20, ge=1, le=100),
    current_user: UserResponse = Depends(get_current_user), db: AsyncSession = Depends(get_db),
):
    _ensure_lead_role(current_user)
    await _get_scoped_lead(db, lead_id, current_user)
    query = select(SalesLeadEnrichmentAudit).where(SalesLeadEnrichmentAudit.lead_id == lead_id)
    rows = (await db.execute(query.order_by(SalesLeadEnrichmentAudit.revision.desc()).offset(skip).limit(limit))).scalars().all()
    total = (await db.execute(select(func.count()).select_from(SalesLeadEnrichmentAudit)
                             .where(SalesLeadEnrichmentAudit.lead_id == lead_id))).scalar_one()
    return {"items": [{"id": row.id, "revision": row.revision, "source": row.source,
        "changed_fields": row.changed_fields, "before": row.before, "after": row.after,
        "actor_name": row.actor_name, "created_at": row.created_at} for row in rows],
        "total": total, "skip": skip, "limit": limit}


@router.get("/{lead_id}", response_model=SalesLeadResponse)
async def get_sales_lead(
    lead_id: int,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    _ensure_lead_role(current_user)
    lead = await _get_scoped_lead(db, lead_id, current_user)
    markers = await markers_for(db, [lead_id], current_user.id)
    labels = await lead_labels(db, [(lead_id, lead.merchant_pool_id)])
    return SalesLeadResponse.model_validate(lead).model_copy(update={
        **markers[lead_id], "labels": labels.get(lead_id, []),
    })


@router.post("", response_model=SalesLeadResponse, status_code=status.HTTP_201_CREATED)
async def create_sales_lead(
    payload: SalesLeadCreate,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    _ensure_lead_role(current_user)
    if _role(current_user) not in ADMIN_ROLES | {"sales_manager"}:
        raise HTTPException(status_code=403, detail="销售人员不能创建或导入线索")

    await lock_sales_workflow(db)
    parsed = parse_phone_number(payload.phone, payload.country)
    if not parsed.is_valid:
        raise HTTPException(status_code=422, detail=parsed.reason)
    await ensure_phone_contact_allowed(db, parsed.e164, payload.country)
    existing = await db.execute(select(SalesLeads.id, SalesLeads.phone, SalesLeads.country))
    for existing_id, existing_phone, existing_country in existing.all():
        if phone_match_key(existing_phone, existing_country) == parsed.e164:
            raise HTTPException(status_code=409, detail="该电话号码可能已有档案，请由主管核实；本次没有创建或合并商家")

    assigned_id, assigned_name, manager_id = await _resolve_assignee(
        db, payload.assigned_sales_id, current_user
    )
    current_id = _employee_id(current_user)
    from services.sales_dossiers import next_sales_lead_id
    lead = SalesLeads(
        id=await next_sales_lead_id(db),
        **payload.model_dump(exclude={"assigned_sales_id"}),
        assigned_sales_id=assigned_id,
        assigned_sales_name=assigned_name,
        team_manager_id=manager_id,
        created_by_id=current_id,
        created_by_name=current_user.name,
        assigned_at=datetime.now(timezone.utc) if assigned_id else None,
        automation_state="assigned" if assigned_id else "eligible",
    )
    db.add(lead)
    await db.flush()
    if lead.status in POSITIVE:
        record_manual_interest(db, lead, current_user)
    if lead_is_blocked(lead):
        await persist_lead_suppression(db, lead, current_user)
    await db.commit()
    await db.refresh(lead)
    return lead


@router.put("/{lead_id}", response_model=SalesLeadResponse)
async def update_sales_lead(
    lead_id: int,
    payload: SalesLeadUpdate,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    _ensure_lead_role(current_user)
    await lock_sales_workflow(db, lead_ids=[lead_id])
    lead = await _get_scoped_lead(db, lead_id, current_user)
    role = _role(current_user)
    updates = payload.model_dump(exclude_unset=True)
    old_id, old_name = lead.assigned_sales_id, lead.assigned_sales_name
    if role == "sales":
        forbidden = set(updates) - SALES_EDITABLE_FIELDS
        if forbidden:
            raise HTTPException(status_code=403, detail="销售只能更新跟进状态、备注和禁止联系标记")
    if "assigned_sales_id" in updates:
        if updates["assigned_sales_id"] != lead.assigned_sales_id:
            raise HTTPException(status_code=409, detail="更换主要负责人请使用转交功能，并填写原因和交接摘要")
        updates.pop("assigned_sales_id")
    was_blocked = lead_is_blocked(lead)
    if (lead.status in PROTECTED_LEAD_STATUSES and "status" in updates
            and updates["status"] != lead.status and updates["status"] not in {"blocked"}):
        raise HTTPException(status_code=409, detail="已有回访或意向记录，请通过本次通话结果更新状态；资料修改不能取消跟进保护")
    if was_blocked and (("do_not_contact" in updates and not updates["do_not_contact"] and lead.do_not_contact)
            or ("is_blacklisted" in updates and not updates["is_blacklisted"] and lead.is_blacklisted)
            or ("status" in updates and updates["status"] != "blocked")):
        raise HTTPException(status_code=403, detail="联系保护只能由老板通过专用解除功能核实并记录原因，普通资料修改不能解除")
    if was_blocked:
        await persist_lead_suppression(db, lead, current_user, preserve_releases=True)
    if "phone" in updates or "country" in updates:
        changed_phone = updates.get("phone", lead.phone)
        changed_country = updates.get("country", lead.country)
        if changed_phone != lead.phone or changed_country != lead.country:
            parsed = parse_phone_number(changed_phone, changed_country)
            if not parsed.is_valid:
                raise HTTPException(status_code=422, detail=parsed.reason)
            others = (await db.execute(select(SalesLeads.id, SalesLeads.phone, SalesLeads.country).where(SalesLeads.id != lead.id))).all()
            if any(phone_match_key(phone, country) == parsed.e164 for _, phone, country in others):
                raise HTTPException(status_code=409, detail="该电话号码已存在于线索库")

    if updates.get("is_blacklisted") or updates.get("do_not_contact"):
        updates["status"] = "blocked"

    if "status" in updates or "notes" in updates:
        await retain_legacy_interest(db, lead, current_user)
    changing_closing_schedule = (
        ("next_follow_up_at" in updates and _as_utc(updates["next_follow_up_at"]) != _as_utc(lead.next_follow_up_at))
        or ("status" in updates and updates["status"] != lead.status)
    )
    if updates.get("status") != "blocked" and changing_closing_schedule and await lead_has_active_closer(db, lead.id):
        raise HTTPException(409, "主管或老板已接手，回访时间和进展请在踢单名单更新")
    new_interest = updates.get("status") in POSITIVE and lead.status != updates.get("status")
    for key, value in updates.items():
        if hasattr(lead, key):
            setattr(lead, key, value)
    lead.updated_at = datetime.now(timezone.utc)
    if new_interest:
        record_manual_interest(db, lead, current_user)
    if lead_is_blocked(lead):
        await persist_lead_suppression(db, lead, current_user, preserve_releases=was_blocked)
        await sync_pending_daily_tasks(db, lead, None)
    await db.commit()
    await db.refresh(lead)
    return lead


@router.post("/{lead_id}/contact-protection/release")
async def release_sales_contact_protection(
    lead_id: int, payload: ContactProtectionReleaseRequest,
    current_user: UserResponse = Depends(get_current_user), db: AsyncSession = Depends(get_db),
):
    if _role(current_user) != "super_admin":
        raise HTTPException(status_code=403, detail="只有老板可以核实并解除联系保护")
    from services.sales_dossiers import active_actor
    actor = await active_actor(db, current_user)
    if actor.role != "super_admin":
        raise HTTPException(status_code=403, detail="只有老板可以核实并解除联系保护")
    if len(payload.reason.strip()) < 3:
        raise HTTPException(status_code=422, detail="请填写核实并解除保护的原因")
    await lock_sales_workflow(db, lead_ids=[lead_id])
    lead = await _get_scoped_lead(db, lead_id, current_user)
    key = await release_phone_suppression(db, lead, payload.phone, current_user,
        payload.reason.strip(), resume_lead=payload.resume_lead)
    if payload.resume_lead:
        await sync_pending_daily_tasks(db, lead, lead.assigned_sales_id)
    await db.commit()
    return {"message": "指定号码的解除记录已保存；其他商家的保护不变", "lead_id": lead.id,
        "phone": key, "resumed": payload.resume_lead}


@router.delete("/{lead_id}")
async def delete_sales_lead(
    lead_id: int,
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    _ensure_lead_role(current_user)
    if _role(current_user) not in ADMIN_ROLES:
        raise HTTPException(status_code=403, detail="仅管理员可以删除线索")
    await lock_sales_workflow(db, lead_ids=[lead_id])
    lead = await _get_scoped_lead(db, lead_id, current_user)
    from services.sales_dossiers import ensure_dossier_deletable
    await ensure_dossier_deletable(db, lead)
    from services.prospect_verification import ensure_quality_history_retained
    await ensure_quality_history_retained(db, 'lead', [lead_id])
    if lead_is_blocked(lead):
        await persist_lead_suppression(db, lead, current_user, preserve_releases=True)
    await db.delete(lead)
    await db.commit()
    return {"message": "线索已删除", "id": lead_id}

import json
import logging
from typing import List, Optional, Literal

from datetime import datetime, date

from fastapi import APIRouter, Body, Depends, HTTPException, Query
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from core.database import get_db
from dependencies.auth import get_current_user, get_finance_user
from services.customer_permissions import get_customer_permissions, shared_platform_names
from schemas.auth import UserResponse
from services.subscriptions import SubscriptionsService

# Set up logging
logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/entities/subscriptions", tags=["subscriptions"], dependencies=[Depends(get_current_user)])


# ---------- Pydantic Schemas ----------
class SubscriptionsData(BaseModel):
    """Entity data schema (for create/update)"""
    customer_id: int
    customer_name: Optional[str] = None
    deal_id: Optional[int] = None
    opportunity_id: Optional[int] = None
    engagement_id: Optional[int] = None
    business_line_id: Optional[int] = None
    product_id: Optional[int] = None
    product_plan_id: Optional[int] = None
    package_name: Optional[str] = None
    package_price: Optional[float] = None
    list_price_snapshot: Optional[float] = None
    pricing_source: Optional[str] = None
    selected_platforms: Optional[str] = None
    service_scope_json: Optional[str] = None
    billing_cycle: Optional[str] = None
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None
    auto_renew: Optional[bool] = None
    renewal_person: Optional[str] = None
    last_payment_date: Optional[datetime] = None
    next_payment_date: Optional[datetime] = None
    status: Optional[str] = None
    renewal_result: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None


class SubscriptionsUpdateData(BaseModel):
    """Update entity data (partial updates allowed)"""
    customer_id: Optional[int] = None
    customer_name: Optional[str] = None
    deal_id: Optional[int] = None
    opportunity_id: Optional[int] = None
    engagement_id: Optional[int] = None
    business_line_id: Optional[int] = None
    product_id: Optional[int] = None
    product_plan_id: Optional[int] = None
    package_name: Optional[str] = None
    package_price: Optional[float] = None
    list_price_snapshot: Optional[float] = None
    pricing_source: Optional[str] = None
    selected_platforms: Optional[str] = None
    service_scope_json: Optional[str] = None
    billing_cycle: Optional[str] = None
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None
    auto_renew: Optional[bool] = None
    renewal_person: Optional[str] = None
    last_payment_date: Optional[datetime] = None
    next_payment_date: Optional[datetime] = None
    status: Optional[str] = None
    renewal_result: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None


class SubscriptionsResponse(BaseModel):
    """Entity response schema"""
    id: int
    customer_id: Optional[int] = None
    customer_name: Optional[str] = None
    deal_id: Optional[int] = None
    opportunity_id: Optional[int] = None
    engagement_id: Optional[int] = None
    business_line_id: Optional[int] = None
    product_id: Optional[int] = None
    product_plan_id: Optional[int] = None
    package_name: Optional[str] = None
    package_price: Optional[float] = None
    list_price_snapshot: Optional[float] = None
    pricing_source: Optional[str] = None
    selected_platforms: Optional[str] = None
    service_scope_json: Optional[str] = None
    billing_cycle: Optional[str] = None
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None
    auto_renew: Optional[bool] = None
    renewal_person: Optional[str] = None
    last_payment_date: Optional[datetime] = None
    next_payment_date: Optional[datetime] = None
    status: Optional[str] = None
    renewal_result: Optional[str] = None
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class SubscriptionsListResponse(BaseModel):
    """List response schema"""
    items: List[SubscriptionsResponse]
    total: int
    skip: int
    limit: int


class SubscriptionsBatchCreateRequest(BaseModel):
    """Batch create request"""
    items: List[SubscriptionsData]


class SubscriptionsBatchUpdateItem(BaseModel):
    """Batch update item"""
    id: int
    updates: SubscriptionsUpdateData


class SubscriptionsBatchUpdateRequest(BaseModel):
    """Batch update request"""
    items: List[SubscriptionsBatchUpdateItem]


class SubscriptionsBatchDeleteRequest(BaseModel):
    """Batch delete request"""
    ids: List[int]


SUBSCRIPTION_DELIVERY_FIELDS = frozenset({
    "id", "customer_id", "customer_name", "engagement_id", "business_line_id", "product_id",
    "product_plan_id", "package_name", "selected_platforms", "billing_cycle",
    "start_date", "end_date", "status", "created_at", "updated_at",
})
SUBSCRIPTION_RENEWAL_FIELDS = SUBSCRIPTION_DELIVERY_FIELDS | {"auto_renew", "renewal_person", "next_payment_date"}


def _check_visible_query(user, query, sort, access_module="renewals"):
    if query is not None and not isinstance(query, dict):
        raise HTTPException(status_code=400, detail="Query must be a JSON object")
    fields = set(query or {}) | ({str(sort).strip().lstrip("+-")} if sort else set())
    allowed = SUBSCRIPTION_DELIVERY_FIELDS if access_module == "delivery" else SUBSCRIPTION_RENEWAL_FIELDS
    if user.role != "super_admin" and not fields.issubset(allowed - {"selected_platforms"}):
        raise HTTPException(status_code=403, detail="此列表不支持按未授权模块或财务字段筛选")


async def _subscription_for_user(item, user: UserResponse, db: AsyncSession, access_module="renewals") -> SubscriptionsResponse:
    response = SubscriptionsResponse.model_validate(item)
    if user.role == "super_admin":
        return response
    permissions = await get_customer_permissions(db, user, item.customer_id)
    allowed = set(SUBSCRIPTION_DELIVERY_FIELDS if access_module == "delivery" else SUBSCRIPTION_RENEWAL_FIELDS)
    if access_module == "renewals" and permissions.get("finance_access") in {"receipts", "profit"}:
        allowed.update({"package_price", "list_price_snapshot", "pricing_source", "last_payment_date", "renewal_result"})
    if permissions.get("modules", {}).get("deals", {}).get("read"):
        allowed.add("deal_id")
    if permissions.get("modules", {}).get("opportunities", {}).get("read"):
        allowed.add("opportunity_id")
    payload = {key: value for key, value in response.model_dump().items() if key in allowed}
    payload["selected_platforms"] = shared_platform_names(payload.get("selected_platforms"))
    return SubscriptionsResponse.model_validate(payload)


class SubscriptionPackageChangeRequest(BaseModel):
    """Archive an old package and link it to existing replacement packages."""
    replacement_subscription_ids: List[int]
    effective_date: date
    reason: Optional[str] = None


class SubscriptionPackageChangeResponse(BaseModel):
    old_subscription: SubscriptionsResponse
    replacement_subscriptions: List[SubscriptionsResponse]


# ---------- Routes ----------
@router.get("", response_model=SubscriptionsListResponse, response_model_exclude_none=True)
async def query_subscriptionss(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    access_module: Literal["delivery", "renewals"] = Query("renewals"),
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Query subscriptionss with filtering, sorting, and pagination"""
    logger.debug(f"Querying subscriptionss: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")
    
    service = SubscriptionsService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")
        
        _check_visible_query(current_user, query_dict, sort, access_module)
        result = await service.get_list(
            skip=skip, 
            limit=limit,
            query_dict=query_dict,
            sort=sort,
            scope_user=current_user,
            access_module=access_module,
        )
        result["items"] = [await _subscription_for_user(item, current_user, db, access_module) for item in result["items"]]
        logger.debug(f"Found {result['total']} subscriptionss")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying subscriptionss: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/all", response_model=SubscriptionsListResponse, response_model_exclude_none=True)
async def query_subscriptionss_all(
    query: str = Query(None, description="Query conditions (JSON string)"),
    sort: str = Query(None, description="Sort field (prefix with '-' for descending)"),
    skip: int = Query(0, ge=0, description="Number of records to skip"),
    limit: int = Query(20, ge=1, le=2000, description="Max number of records to return"),
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    access_module: Literal["delivery", "renewals"] = Query("renewals"),
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    # Query subscriptionss with filtering, sorting, and pagination without user limitation
    logger.debug(f"Querying subscriptionss: query={query}, sort={sort}, skip={skip}, limit={limit}, fields={fields}")

    service = SubscriptionsService(db)
    try:
        # Parse query JSON if provided
        query_dict = None
        if query:
            try:
                query_dict = json.loads(query)
            except json.JSONDecodeError:
                raise HTTPException(status_code=400, detail="Invalid query JSON format")

        _check_visible_query(current_user, query_dict, sort, access_module)
        result = await service.get_list(
            skip=skip,
            limit=limit,
            query_dict=query_dict,
            sort=sort,
            scope_user=current_user,
            access_module=access_module,
        )
        result["items"] = [await _subscription_for_user(item, current_user, db, access_module) for item in result["items"]]
        logger.debug(f"Found {result['total']} subscriptionss")
        return result
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error querying subscriptionss: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.get("/{id}", response_model=SubscriptionsResponse, response_model_exclude_none=True)
async def get_subscriptions(
    id: int,
    fields: str = Query(None, description="Comma-separated list of fields to return"),
    access_module: Literal["delivery", "renewals"] = Query("renewals"),
    current_user: UserResponse = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Get a single subscriptions by ID"""
    logger.debug(f"Fetching subscriptions with id: {id}, fields={fields}")
    
    service = SubscriptionsService(db)
    try:
        result = await service.get_by_id(id, scope_user=current_user, access_module=access_module)
        if not result:
            logger.warning(f"Subscriptions with id {id} not found")
            raise HTTPException(status_code=404, detail="Subscriptions not found")
        
        return await _subscription_for_user(result, current_user, db, access_module)
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error fetching subscriptions {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("", response_model=SubscriptionsResponse, status_code=201)
async def create_subscriptions(
    data: SubscriptionsData,
    _finance_user: UserResponse = Depends(get_finance_user),
    db: AsyncSession = Depends(get_db),
):
    """Create a new subscriptions"""
    logger.debug(f"Creating new subscriptions with data: {data}")
    
    service = SubscriptionsService(db)
    try:
        result = await service.create(data.model_dump())
        if not result:
            raise HTTPException(status_code=400, detail="Failed to create subscriptions")
        
        logger.info(f"Subscriptions created successfully with id: {result.id}")
        return result
    except ValueError as e:
        logger.error(f"Validation error creating subscriptions: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error creating subscriptions: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.post("/batch", response_model=List[SubscriptionsResponse], status_code=201)
async def create_subscriptionss_batch(
    request: SubscriptionsBatchCreateRequest,
    _finance_user: UserResponse = Depends(get_finance_user),
    db: AsyncSession = Depends(get_db),
):
    """Create multiple subscriptionss in a single request"""
    logger.debug(f"Batch creating {len(request.items)} subscriptionss")
    
    service = SubscriptionsService(db)
    results = []
    
    try:
        for item_data in request.items:
            result = await service.create(item_data.model_dump())
            if result:
                results.append(result)
        
        logger.info(f"Batch created {len(results)} subscriptionss successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch create: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch create failed: {str(e)}")


@router.put("/batch", response_model=List[SubscriptionsResponse])
async def update_subscriptionss_batch(
    request: SubscriptionsBatchUpdateRequest,
    _finance_user: UserResponse = Depends(get_finance_user),
    db: AsyncSession = Depends(get_db),
):
    """Update multiple subscriptionss in a single request"""
    logger.debug(f"Batch updating {len(request.items)} subscriptionss")
    
    service = SubscriptionsService(db)
    results = []
    
    try:
        for item in request.items:
            # Only include non-None values for partial updates
            update_dict = {k: v for k, v in item.updates.model_dump().items() if v is not None}
            result = await service.update(item.id, update_dict)
            if result:
                results.append(result)
        
        logger.info(f"Batch updated {len(results)} subscriptionss successfully")
        return results
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch update: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch update failed: {str(e)}")


@router.post("/{id}/package-change", response_model=SubscriptionPackageChangeResponse)
async def change_subscription_package(
    id: int,
    request: SubscriptionPackageChangeRequest,
    _finance_user: UserResponse = Depends(get_finance_user),
    db: AsyncSession = Depends(get_db),
):
    """Archive an old package while preserving history and linking replacement packages."""
    if not request.replacement_subscription_ids:
        raise HTTPException(status_code=400, detail="请至少选择一个替代套餐")
    if len(request.replacement_subscription_ids) > 10:
        raise HTTPException(status_code=400, detail="一次最多关联 10 个替代套餐")
    if request.reason and len(request.reason.strip()) > 200:
        raise HTTPException(status_code=400, detail="变更原因最多 200 个字符")

    service = SubscriptionsService(db)
    try:
        old_subscription, replacements = await service.mark_package_changed(
            id,
            request.replacement_subscription_ids,
            request.effective_date,
            request.reason,
        )
        return {
            "old_subscription": old_subscription,
            "replacement_subscriptions": replacements,
        }
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error("Error changing package for subscription %s: %s", id, str(e), exc_info=True)
        raise HTTPException(status_code=500, detail=f"套餐变更失败: {str(e)}")


@router.put("/{id}", response_model=SubscriptionsResponse)
async def update_subscriptions(
    id: int,
    data: SubscriptionsUpdateData,
    _finance_user: UserResponse = Depends(get_finance_user),
    db: AsyncSession = Depends(get_db),
):
    """Update an existing subscriptions"""
    logger.debug(f"Updating subscriptions {id} with data: {data}")

    service = SubscriptionsService(db)
    try:
        # Only include non-None values for partial updates
        update_dict = {k: v for k, v in data.model_dump().items() if v is not None}
        result = await service.update(id, update_dict)
        if not result:
            logger.warning(f"Subscriptions with id {id} not found for update")
            raise HTTPException(status_code=404, detail="Subscriptions not found")
        
        logger.info(f"Subscriptions {id} updated successfully")
        return result
    except HTTPException:
        raise
    except ValueError as e:
        logger.error(f"Validation error updating subscriptions {id}: {str(e)}")
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        logger.error(f"Error updating subscriptions {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")


@router.delete("/batch")
async def delete_subscriptionss_batch(
    request: SubscriptionsBatchDeleteRequest,
    _finance_user: UserResponse = Depends(get_finance_user),
    db: AsyncSession = Depends(get_db),
):
    """Delete multiple subscriptionss by their IDs"""
    logger.debug(f"Batch deleting {len(request.ids)} subscriptionss")
    
    service = SubscriptionsService(db)
    deleted_count = 0
    
    try:
        for item_id in request.ids:
            success = await service.delete(item_id)
            if success:
                deleted_count += 1
        
        logger.info(f"Batch deleted {deleted_count} subscriptionss successfully")
        return {"message": f"Successfully deleted {deleted_count} subscriptionss", "deleted_count": deleted_count}
    except Exception as e:
        await db.rollback()
        logger.error(f"Error in batch delete: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Batch delete failed: {str(e)}")


@router.delete("/{id}")
async def delete_subscriptions(
    id: int,
    _finance_user: UserResponse = Depends(get_finance_user),
    db: AsyncSession = Depends(get_db),
):
    """Delete a single subscriptions by ID"""
    logger.debug(f"Deleting subscriptions with id: {id}")
    
    service = SubscriptionsService(db)
    try:
        success = await service.delete(id)
        if not success:
            logger.warning(f"Subscriptions with id {id} not found for deletion")
            raise HTTPException(status_code=404, detail="Subscriptions not found")
        
        logger.info(f"Subscriptions {id} deleted successfully")
        return {"message": "Subscriptions deleted successfully", "id": id}
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error deleting subscriptions {id}: {str(e)}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"Internal server error: {str(e)}")

import"./ui-vendor-BkAVVwrI.js";

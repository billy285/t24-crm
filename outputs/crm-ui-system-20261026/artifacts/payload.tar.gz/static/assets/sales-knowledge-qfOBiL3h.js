const i=new RegExp("(?<=[。！？!?])\\s*");function l(e,t=140){const n=e.replace(/\s+/g," ").trim();if(n.length<=t)return n;const o=n.split(i).filter(Boolean);let s="";for(const r of o)if(`${s}${r}`.length>t||(s+=r,s.length>=72))break;return s?s.trim():`${n.slice(0,t).trim()}…`}function a(e){return`${e.title}

标准答复：
${e.standard_answer}${e.action_steps.length?`

建议步骤：
${e.action_steps.map((t,n)=>`${n+1}. ${t}`).join(`
`)}`:""}`}export{a,l as g};
